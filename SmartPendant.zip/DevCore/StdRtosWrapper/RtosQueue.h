// *****************************************************************************
// @file RtosQueue.h
// @author Nicolai Shlapunov
//
// @details DevCore: C++ standard library Queue Wrapper Class, header
//
// @section COPYRIGHT
//
//  Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

#ifndef RtosQueue_h
#define RtosQueue_h

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "DevCfg.h"

#include <mutex>
#include <condition_variable>
#include <vector>

// *****************************************************************************
// ***   RtosQueue   ***********************************************************
// *****************************************************************************
// Queue of fixed-size items copied in and out, as a FreeRTOS queue
class RtosQueue
{
  public:
    // *************************************************************************
    // ***   RtosQueue   *******************************************************
    // *************************************************************************
    RtosQueue(uint32_t q_len, uint32_t itm_size, const char* queue_name = nullptr);

    // *************************************************************************
    // ***   SetName   *********************************************************
    // *************************************************************************
    void SetName(const char* q_name, const char* t_name = nullptr);

    // *************************************************************************
    // ***   Create   **********************************************************
    // *************************************************************************
    Result Create();

    // *************************************************************************
    // ***   Reset   ***********************************************************
    // *************************************************************************
    Result Reset();

    // *************************************************************************
    // ***   IsEmpty   *********************************************************
    // *************************************************************************
    bool IsEmpty() const;

    // *************************************************************************
    // ***   IsFull   **********************************************************
    // *************************************************************************
    bool IsFull() const;

    // *************************************************************************
    // ***   GetMessagesWaiting   **********************************************
    // *************************************************************************
    Result GetMessagesWaiting(uint32_t& msg_cnt) const;

    // *************************************************************************
    // ***   SendToBack   ******************************************************
    // *************************************************************************
    Result SendToBack(const void* item, uint32_t timeout_ms = 0u);

    // *************************************************************************
    // ***   SendToFront   *****************************************************
    // *************************************************************************
    Result SendToFront(const void* item, uint32_t timeout_ms = 0u);

    // *************************************************************************
    // ***   Receive   *********************************************************
    // *************************************************************************
    // * timeout_ms: UINT32_MAX waits forever
    Result Receive(void* item, uint32_t timeout_ms);

    // *************************************************************************
    // ***   Peek   ************************************************************
    // *************************************************************************
    // * timeout_ms: UINT32_MAX waits forever
    Result Peek(void* item, uint32_t timeout_ms) const;

    // *************************************************************************
    // ***   GetQueueLen   *****************************************************
    // *************************************************************************
    inline uint16_t GetQueueLen(void) const {return queue_len;}

    // *************************************************************************
    // ***   GetItemSize   *****************************************************
    // *************************************************************************
    inline uint16_t GetItemSize(void) const {return item_size;}

  private:
    // Ring buffer of items, allocated by Create()
    std::vector<uint8_t> buf;
    // Index of the first item and number of items
    uint32_t head = 0u;
    uint32_t cnt = 0u;
    // Queue is created
    bool created = false;
    // Synchronisation
    mutable std::mutex mutex;
    mutable std::condition_variable cv;

    // Number of items in the queue
    uint16_t queue_len = 0u;
    // Size of item
    uint16_t item_size = 0u;
    // Queue name
    const char* queue_name = nullptr;
    const char* task_name = nullptr;

    // Send an item to the back or to the front
    Result Send(const void* item, uint32_t timeout_ms, bool to_front);
    // Wait while predicate is false, up to timeout_ms (UINT32_MAX - forever)
    template<typename P> bool Wait(std::unique_lock<std::mutex>& lock, uint32_t timeout_ms, P pred) const;

    // Prevent copying and assigning
    RtosQueue();
    RtosQueue(const RtosQueue&);
    RtosQueue& operator=(const RtosQueue&);
};

#endif
