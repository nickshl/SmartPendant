// *****************************************************************************
// @file RtosQueue.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: C++ standard library Queue Wrapper Class, implementation
//
// @section COPYRIGHT
//
//  Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "DevCfg.h"

// This wrapper is compiled only when DevCfgUsr.h selects it
#if defined(STD_RTOS_WRAPPER)

#include "RtosQueue.h"

#include <chrono>
#include <cstring>

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
RtosQueue::RtosQueue(uint32_t q_len, uint32_t itm_size, const char* queue_name)
   : queue_len(q_len), item_size(itm_size)
{
  SetName(queue_name);
}

// *****************************************************************************
// ***   SetName   *************************************************************
// *****************************************************************************
void RtosQueue::SetName(const char* q_name, const char* t_name)
{
  queue_name = q_name;
  task_name = t_name;
}

// *****************************************************************************
// ***   Wait   ****************************************************************
// *****************************************************************************
template<typename P> bool RtosQueue::Wait(std::unique_lock<std::mutex>& lock, uint32_t timeout_ms, P pred) const
{
  bool res = true;
  if(timeout_ms == UINT32_MAX)
  {
    cv.wait(lock, pred);
  }
  else
  {
    res = cv.wait_for(lock, std::chrono::milliseconds(timeout_ms), pred);
  }
  return res;
}

// *****************************************************************************
// ***   Create   **************************************************************
// *****************************************************************************
Result RtosQueue::Create()
{
  Result result = Result::ERR_QUEUE_CREATE;
  std::lock_guard<std::mutex> lock(mutex);
  if(!created && (queue_len != 0u) && (item_size != 0u))
  {
    buf.assign((size_t)queue_len * item_size, 0u);
    head = 0u;
    cnt = 0u;
    created = true;
    result = Result::RESULT_OK;
  }
  return result;
}

// *****************************************************************************
// ***   Reset   ***************************************************************
// *****************************************************************************
Result RtosQueue::Reset()
{
  Result result = Result::ERR_QUEUE_RESET;
  {
    std::lock_guard<std::mutex> lock(mutex);
    if(created)
    {
      head = 0u;
      cnt = 0u;
      result = Result::RESULT_OK;
    }
  }
  cv.notify_all();
  return result;
}

// *****************************************************************************
// ***   IsEmpty   *************************************************************
// *****************************************************************************
bool RtosQueue::IsEmpty() const
{
  std::lock_guard<std::mutex> lock(mutex);
  return created && (cnt == 0u);
}

// *****************************************************************************
// ***   IsFull   **************************************************************
// *****************************************************************************
bool RtosQueue::IsFull() const
{
  std::lock_guard<std::mutex> lock(mutex);
  return created && (cnt >= queue_len);
}

// *****************************************************************************
// ***   GetMessagesWaiting   **************************************************
// *****************************************************************************
Result RtosQueue::GetMessagesWaiting(uint32_t& msg_cnt) const
{
  Result result = Result::ERR_QUEUE_GENERAL;
  std::lock_guard<std::mutex> lock(mutex);
  if(created)
  {
    msg_cnt = cnt;
    result = Result::RESULT_OK;
  }
  return result;
}

// *****************************************************************************
// ***   Send   ****************************************************************
// *****************************************************************************
Result RtosQueue::Send(const void* item, uint32_t timeout_ms, bool to_front)
{
  Result result = Result::ERR_QUEUE_WRITE;
  if(item != nullptr)
  {
    std::unique_lock<std::mutex> lock(mutex);
    if(created && Wait(lock, timeout_ms, [this]{return cnt < queue_len;}))
    {
      uint32_t idx;
      if(to_front)
      {
        head = (head + queue_len - 1u) % queue_len;
        idx = head;
      }
      else
      {
        idx = (head + cnt) % queue_len;
      }
      memcpy(&buf[(size_t)idx * item_size], item, item_size);
      cnt++;
      result = Result::RESULT_OK;
    }
  }
  cv.notify_all();
  return result;
}

// *****************************************************************************
// ***   SendToBack   **********************************************************
// *****************************************************************************
Result RtosQueue::SendToBack(const void* item, uint32_t timeout_ms)
{
  return Send(item, timeout_ms, false);
}

// *****************************************************************************
// ***   SendToFront   *********************************************************
// *****************************************************************************
Result RtosQueue::SendToFront(const void* item, uint32_t timeout_ms)
{
  return Send(item, timeout_ms, true);
}

// *****************************************************************************
// ***   Receive   *************************************************************
// *****************************************************************************
Result RtosQueue::Receive(void* item, uint32_t timeout_ms)
{
  Result result = Result::ERR_NULL_PTR;
  if(item != nullptr)
  {
    result = Result::ERR_QUEUE_READ;
    std::unique_lock<std::mutex> lock(mutex);
    if(created)
    {
      if(Wait(lock, timeout_ms, [this]{return cnt > 0u;}))
      {
        memcpy(item, &buf[(size_t)head * item_size], item_size);
        head = (head + 1u) % queue_len;
        cnt--;
        result = Result::RESULT_OK;
      }
      else
      {
        result = Result::ERR_QUEUE_EMPTY;
      }
    }
  }
  cv.notify_all();
  return result;
}

// *****************************************************************************
// ***   Peek   ****************************************************************
// *****************************************************************************
Result RtosQueue::Peek(void* item, uint32_t timeout_ms) const
{
  Result result = Result::ERR_QUEUE_READ;
  if(item != nullptr)
  {
    std::unique_lock<std::mutex> lock(mutex);
    if(created)
    {
      if(Wait(lock, timeout_ms, [this]{return cnt > 0u;}))
      {
        memcpy(item, &buf[(size_t)head * item_size], item_size);
        result = Result::RESULT_OK;
      }
      else
      {
        result = Result::ERR_QUEUE_EMPTY;
      }
    }
  }
  return result;
}

#endif
