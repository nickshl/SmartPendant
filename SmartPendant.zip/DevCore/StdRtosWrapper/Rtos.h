// *****************************************************************************
// @file Rtos.h
// @author Nicolai Shlapunov
//
// @details DevCore: C++ standard library RTOS Wrapper Class, header
//
// @section COPYRIGHT
//
//  Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

#ifndef Rtos_h
#define Rtos_h

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "DevCfg.h"
#include "RtosTick.h"
#include "RtosTimer.h"

#include <cstdlib>
#include "RtosQueue.h"
#include "RtosMutex.h"
#include "RtosSemaphore.h"

// *****************************************************************************
// ***   Rtos   ****************************************************************
// *****************************************************************************
// This wrapper runs DevCore on any system whose C++ standard library has
// threads (Linux, Windows, macOS): every task is a std::thread. It is meant for
// running and testing an application on a PC. Differences from FreeRTOS:
//  - task priorities and stack sizes are ignored, the system schedules threads;
//  - tasks created before StartScheduler() wait for it, as in FreeRTOS;
//  - critical sections, interrupts disable and scheduler suspend are one global
//    recursive mutex: they keep other tasks out of the same section only;
//  - there are no interrupts: IsInHandlerMode() is always false.
class Rtos
{
  public:
    // Definition of callback function
    typedef void (TaskFunction)(void* ptr);

    // *************************************************************************
    // ***   TaskCreate   ******************************************************
    // *************************************************************************
    static Result TaskCreate(TaskFunction& function, const char* task_name,
                             const uint16_t stack_depth, void* param_ptr,
                             uint8_t priority);

    // *************************************************************************
    // ***   TaskDelete   ******************************************************
    // *************************************************************************
    // * Only the current task can be deleted (task == nullptr): it ends at once
    // * if C++ exceptions are enabled, otherwise when its function returns.
    static void TaskDelete(void* task = nullptr);

    // *************************************************************************
    // ***   GetCurrentTaskParam   *********************************************
    // *************************************************************************
    static void* GetCurrentTaskParam();

    // *************************************************************************
    // ***   Alloc   ***********************************************************
    // *************************************************************************
    static inline void* Alloc(uint32_t size) {return malloc(size);}

    // *************************************************************************
    // ***   Free   ************************************************************
    // *************************************************************************
    static inline void Free(void* ptr) {free(ptr);}

    // *************************************************************************
    // ***   IsInHandlerMode   *************************************************
    // *************************************************************************
    static inline bool IsInHandlerMode() {return false;}

    // *************************************************************************
    // ***   StartScheduler   **************************************************
    // *************************************************************************
    // * Starts tasks created so far and every task created later. Unlike
    // * vTaskStartScheduler() it returns, so main() can go on (for example to
    // * drive a test); it must not return from main() while tasks run.
    static void StartScheduler();

    // *************************************************************************
    // ***   IsSchedulerNotRunning   *******************************************
    // *************************************************************************
    static bool IsSchedulerNotRunning();

    // *************************************************************************
    // ***   IsSchedulerRunning   **********************************************
    // *************************************************************************
    static bool IsSchedulerRunning();

    // *************************************************************************
    // ***   IsSchedulerSuspended   ********************************************
    // *************************************************************************
    static bool IsSchedulerSuspended();

    // *************************************************************************
    // ***   SuspendScheduler   ************************************************
    // *************************************************************************
    static void SuspendScheduler();

    // *************************************************************************
    // ***   ResumeScheduler   *************************************************
    // *************************************************************************
    static void ResumeScheduler();

    // *************************************************************************
    // ***   EnterCriticalSection   ********************************************
    // *************************************************************************
    static void EnterCriticalSection();

    // *************************************************************************
    // ***   ExitCriticalSection   *********************************************
    // *************************************************************************
    static void ExitCriticalSection();

    // *************************************************************************
    // ***   DisableInterrupts   ***********************************************
    // *************************************************************************
    static inline void DisableInterrupts() {EnterCriticalSection();}

    // *************************************************************************
    // ***   EnableInterrupts   ************************************************
    // *************************************************************************
    static inline void EnableInterrupts() {ExitCriticalSection();}

 private:
    // None
};

#endif
