// *****************************************************************************
// @file RtosTimer.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: C++ standard library Timer Wrapper Class, implementation
//
// @section COPYRIGHT
//
//  Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "DevCfg.h"

// This wrapper is compiled only when DevCfgUsr.h selects it
#if defined(STD_RTOS_WRAPPER)

#include "RtosTimer.h"
#include "Rtos.h"

#include <thread>
#include <mutex>
#include <condition_variable>
#include <chrono>
#include <set>

// *****************************************************************************
// ***   Local data   **********************************************************
// *****************************************************************************
namespace
{
  // Created timers, the mutex for timer data and the timer thread signal
  std::set<RtosTimer*>& Timers() {static std::set<RtosTimer*> timers; return timers;}
  std::recursive_mutex& TimerMutex() {static std::recursive_mutex m; return m;}
  std::condition_variable_any& TimerCv() {static std::condition_variable_any cv; return cv;}
  std::once_flag thread_started;
}

// *****************************************************************************
// ***   ~RtosTimer   **********************************************************
// *****************************************************************************
RtosTimer::~RtosTimer()
{
  (void)Delete();
}

// *****************************************************************************
// ***   Create   **************************************************************
// *****************************************************************************
Result RtosTimer::Create()
{
  Result result = Result::ERR_TIMER_CREATE;
  std::lock_guard<std::recursive_mutex> lock(TimerMutex());
  if(!created && (timer_period_ms != 0u))
  {
    created = true;
    active = false;
    Timers().insert(this);
    // One timer thread for all timers, as the FreeRTOS timer task
    std::call_once(thread_started, []{std::thread(TimerThread).detach();});
    result = Result::RESULT_OK;
  }
  return result;
}

// *****************************************************************************
// ***   Delete   **************************************************************
// *****************************************************************************
Result RtosTimer::Delete()
{
  Result result = Result::ERR_NULL_PTR;
  std::lock_guard<std::recursive_mutex> lock(TimerMutex());
  if(created)
  {
    created = false;
    active = false;
    Timers().erase(this);
    result = Result::RESULT_OK;
  }
  return result;
}

// *****************************************************************************
// ***   IsActive   ************************************************************
// *****************************************************************************
bool RtosTimer::IsActive() const
{
  std::lock_guard<std::recursive_mutex> lock(TimerMutex());
  return created && active;
}

// *****************************************************************************
// ***   Start   ***************************************************************
// *****************************************************************************
Result RtosTimer::Start(uint32_t timeout_ms)
{
  Result result = Result::ERR_TIMER_START;
  (void)timeout_ms;
  {
    std::lock_guard<std::recursive_mutex> lock(TimerMutex());
    if(created)
    {
      // Start or restart: expires one period from now, as xTimerStart()
      expiry = RtosTick::GetTickCount() + RtosTick::MsToTicks(timer_period_ms);
      active = true;
      result = Result::RESULT_OK;
    }
  }
  TimerCv().notify_all();
  return result;
}

// *****************************************************************************
// ***   Stop   ****************************************************************
// *****************************************************************************
Result RtosTimer::Stop(uint32_t timeout_ms)
{
  Result result = Result::ERR_TIMER_STOP;
  (void)timeout_ms;
  std::lock_guard<std::recursive_mutex> lock(TimerMutex());
  if(created)
  {
    active = false;
    result = Result::RESULT_OK;
  }
  return result;
}

// *****************************************************************************
// ***   UpdatePeriod   ********************************************************
// *****************************************************************************
Result RtosTimer::UpdatePeriod(uint32_t new_period_ms, uint32_t timeout_ms)
{
  Result result = Result::ERR_TIMER_UPDATE;
  std::lock_guard<std::recursive_mutex> lock(TimerMutex());
  if(created)
  {
    // Get current timer state
    bool is_active = IsActive();
    // Start timer with new period
    result = StartWithNewPeriod(new_period_ms, timeout_ms);
    // Keep it stopped if it wasn't active
    if(result.IsGood() && (is_active == false))
    {
      result = Stop(timeout_ms);
    }
  }
  return result;
}

// *****************************************************************************
// ***   StartWithNewPeriod   **************************************************
// *****************************************************************************
Result RtosTimer::StartWithNewPeriod(uint32_t new_period_ms, uint32_t timeout_ms)
{
  Result result = Result::ERR_TIMER_UPDATE;
  {
    std::lock_guard<std::recursive_mutex> lock(TimerMutex());
    if(created)
    {
      timer_period_ms = new_period_ms;
      result = Start(timeout_ms);
    }
  }
  return result;
}

// *****************************************************************************
// ***   Reset   ***************************************************************
// *****************************************************************************
Result RtosTimer::Reset(uint32_t timeout_ms)
{
  Result result = Result::ERR_TIMER_STOP;
  std::lock_guard<std::recursive_mutex> lock(TimerMutex());
  if(created)
  {
    result = Start(timeout_ms);
  }
  return result;
}

// *****************************************************************************
// ***   TimerThread   *********************************************************
// *****************************************************************************
void RtosTimer::TimerThread()
{
  // Timers run only when scheduler runs
  while(Rtos::IsSchedulerNotRunning()) RtosTick::DelayTicks(1u);
  std::unique_lock<std::recursive_mutex> lock(TimerMutex());
  while(true)
  {
    uint32_t now = RtosTick::GetTickCount();
    // Find the active timer that expires first
    RtosTimer* next = nullptr;
    for(RtosTimer* t : Timers())
    {
      if(t->active && ((next == nullptr) || ((int32_t)(t->expiry - next->expiry) < 0))) next = t;
    }
    if(next == nullptr)
    {
      // Nothing to do - wait for a timer start
      TimerCv().wait_for(lock, std::chrono::milliseconds(100));
    }
    else if((int32_t)(next->expiry - now) > 0)
    {
      // Wait until it expires or timers change
      TimerCv().wait_for(lock, std::chrono::milliseconds(next->expiry - now));
    }
    else
    {
      // Expired: a repeating timer reloads from its expiry time, a one-shot
      // timer stops. Callback is called with the timer data unlocked.
      if(next->timer_type == REPEATING) next->expiry += RtosTick::MsToTicks(next->timer_period_ms);
      else                              next->active = false;
      Callback* clbk = next->callback;
      void* param = next->callback_param;
      lock.unlock();
      if(clbk != nullptr) clbk(param);
      lock.lock();
    }
  }
}

#endif
