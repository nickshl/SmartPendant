// *****************************************************************************
// @file Rtos.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: C++ standard library RTOS Wrapper Class, implementation
//
// @section COPYRIGHT
//
//  Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "DevCfg.h"

// This wrapper is compiled only when DevCfgUsr.h selects it
#if defined(STD_RTOS_WRAPPER)

#include "Rtos.h"

#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>

// *****************************************************************************
// ***   Local data   **********************************************************
// *****************************************************************************
namespace
{
  // Scheduler state: tasks wait until it is started
  std::mutex sched_mutex;
  std::condition_variable sched_cv;
  bool sched_started = false;
  std::atomic<int> suspend_cnt(0);
  // One mutex for critical sections, interrupt disable and scheduler suspend
  std::recursive_mutex critical_mutex;
  // Parameter of the task running in this thread
  thread_local void* current_param = nullptr;
  // Thrown by TaskDelete() to end the task
  struct TaskDeleted {};
}

// *****************************************************************************
// ***   TaskCreate   **********************************************************
// *****************************************************************************
Result Rtos::TaskCreate(TaskFunction& function, const char* task_name,
                        const uint16_t stack_depth, void* param_ptr,
                        uint8_t priority)
{
  Result result = Result::ERR_TASK_CREATE;
  // Name, stack depth and priority are not used by this wrapper
  (void)task_name; (void)stack_depth; (void)priority;
#if defined(__cpp_exceptions)
  try
#endif
  {
    TaskFunction* fn = &function;
    std::thread([fn, param_ptr]()
    {
      // Tasks start when scheduler starts
      {
        std::unique_lock<std::mutex> lock(sched_mutex);
        sched_cv.wait(lock, []{return sched_started;});
      }
      // Parameter is used as current task identifier, as in FreeRTOS wrapper
      current_param = param_ptr;
#if defined(__cpp_exceptions)
      try
      {
        fn(param_ptr);
      }
      catch(const TaskDeleted&)
      {
        ; // Task deleted itself
      }
#else
      fn(param_ptr);
#endif
    }).detach();
    result = Result::RESULT_OK;
  }
#if defined(__cpp_exceptions)
  catch(...)
  {
    result = Result::ERR_TASK_CREATE;
  }
#endif
  return result;
}

// *****************************************************************************
// ***   TaskDelete   **********************************************************
// *****************************************************************************
void Rtos::TaskDelete(void* task)
{
  if(task == nullptr)
  {
#if defined(__cpp_exceptions)
    // End current task right away, as vTaskDelete(NULL) does
    throw TaskDeleted();
#endif
  }
  else
  {
    // Deleting another task isn't supported by this wrapper
    Break();
  }
}

// *****************************************************************************
// ***   GetCurrentTaskParam   *************************************************
// *****************************************************************************
void* Rtos::GetCurrentTaskParam()
{
  return current_param;
}

// *****************************************************************************
// ***   StartScheduler   ******************************************************
// *****************************************************************************
void Rtos::StartScheduler()
{
  {
    std::lock_guard<std::mutex> lock(sched_mutex);
    sched_started = true;
  }
  sched_cv.notify_all();
}

// *****************************************************************************
// ***   IsSchedulerNotRunning   ***********************************************
// *****************************************************************************
bool Rtos::IsSchedulerNotRunning()
{
  std::lock_guard<std::mutex> lock(sched_mutex);
  return !sched_started;
}

// *****************************************************************************
// ***   IsSchedulerRunning   **************************************************
// *****************************************************************************
bool Rtos::IsSchedulerRunning()
{
  return !IsSchedulerNotRunning() && (suspend_cnt.load() == 0);
}

// *****************************************************************************
// ***   IsSchedulerSuspended   ************************************************
// *****************************************************************************
bool Rtos::IsSchedulerSuspended()
{
  return !IsSchedulerNotRunning() && (suspend_cnt.load() != 0);
}

// *****************************************************************************
// ***   SuspendScheduler   ****************************************************
// *****************************************************************************
void Rtos::SuspendScheduler()
{
  critical_mutex.lock();
  suspend_cnt++;
}

// *****************************************************************************
// ***   ResumeScheduler   *****************************************************
// *****************************************************************************
void Rtos::ResumeScheduler()
{
  suspend_cnt--;
  critical_mutex.unlock();
}

// *****************************************************************************
// ***   EnterCriticalSection   ************************************************
// *****************************************************************************
void Rtos::EnterCriticalSection()
{
  critical_mutex.lock();
}

// *****************************************************************************
// ***   ExitCriticalSection   *************************************************
// *****************************************************************************
void Rtos::ExitCriticalSection()
{
  critical_mutex.unlock();
}

#endif
