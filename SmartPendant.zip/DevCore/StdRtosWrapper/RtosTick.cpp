// *****************************************************************************
// @file RtosTick.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: C++ standard library Tick Wrapper Class, implementation
//
// @section COPYRIGHT
//
//  Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "DevCfg.h"

// This wrapper is compiled only when DevCfgUsr.h selects it
#if defined(STD_RTOS_WRAPPER)

#include "RtosTick.h"

#include <chrono>
#include <thread>

// *****************************************************************************
// ***   Local data   **********************************************************
// *****************************************************************************
namespace
{
  // Time of the first tick
  const std::chrono::steady_clock::time_point start_time = std::chrono::steady_clock::now();
}

// *****************************************************************************
// ***   GetTickCount   ********************************************************
// *****************************************************************************
uint32_t RtosTick::GetTickCount()
{
  return (uint32_t)std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - start_time).count();
}

// *****************************************************************************
// ***   GetTickDifference   ***************************************************
// *****************************************************************************
uint32_t RtosTick::GetTickDifference(uint32_t start_val, uint32_t cur_val)
{
  return(cur_val - start_val);
}

// *****************************************************************************
// ***   CheckTickDifference   *************************************************
// *****************************************************************************
bool RtosTick::CheckTickDifference(uint32_t start_val, uint32_t check_value)
{
  return (GetTickDifference(start_val, GetTickCount()) >= check_value);
}

// *****************************************************************************
// ***   GetTimeMs   ***********************************************************
// *****************************************************************************
uint32_t RtosTick::GetTimeMs()
{
  return TicksToMs(GetTickCount());
}

// *****************************************************************************
// ***   CheckTimeDifferenceMs   ***********************************************
// *****************************************************************************
bool RtosTick::CheckTimeDifferenceMs(uint32_t start_val_ms, uint32_t check_value_ms)
{
  return (TicksToMs(GetTickDifference(MsToTicks(start_val_ms), GetTickCount())) >= check_value_ms);
}

// *****************************************************************************
// ***   Yield   ***************************************************************
// *****************************************************************************
void RtosTick::Yield()
{
  std::this_thread::yield();
}

// *****************************************************************************
// ***   DelayTicks   **********************************************************
// *****************************************************************************
void RtosTick::DelayTicks(uint32_t ticks)
{
  std::this_thread::sleep_for(std::chrono::milliseconds(ticks));
}

// *****************************************************************************
// ***   DelayMs   *************************************************************
// *****************************************************************************
void RtosTick::DelayMs(uint32_t time_ms)
{
  DelayTicks(MsToTicks(time_ms));
}

// *****************************************************************************
// ***   DelayUntilTicks   *****************************************************
// *****************************************************************************
void RtosTick::DelayUntilTicks(uint32_t& last_wake_ticks, uint32_t ticks)
{
  // Next wake time, as vTaskDelayUntil() counts it
  last_wake_ticks += ticks;
  // Time left to it (wrap safe); none if it is already passed
  int32_t left = (int32_t)(last_wake_ticks - GetTickCount());
  if(left > 0) DelayTicks((uint32_t)left);
}

// *****************************************************************************
// ***   DelayUntilMs   ********************************************************
// *****************************************************************************
void RtosTick::DelayUntilMs(uint32_t& last_wake_ticks, uint32_t time_ms)
{
  DelayUntilTicks(last_wake_ticks, MsToTicks(time_ms));
}

#endif
