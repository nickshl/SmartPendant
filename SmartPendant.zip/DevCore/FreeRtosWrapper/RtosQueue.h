// *****************************************************************************
// @file RtosMutex.h
// @author Nicolai Shlapunov
//
// @details DevCore: FreeRTOS Queue Wrapper Class, header
//
// @section COPYRIGHT
//
//  Copyright (c) 2016-2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

#ifndef RtosQueue_h
#define RtosQueue_h

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "DevCfg.h"
#include "Rtos.h"
#include "queue.h"

// *****************************************************************************
// ***   RtosQueue   ***********************************************************
// *****************************************************************************
class RtosQueue
{
  public:

    // *************************************************************************
    // ***   Public: RtosQueue   ***********************************************
    // *************************************************************************
    RtosQueue(uint32_t q_len, uint32_t itm_size, const char* queue_name = nullptr);

    // *************************************************************************
    // ***   Public: ~RtosQueue   **********************************************
    // *************************************************************************
    ~RtosQueue();

    // *************************************************************************
    // ***   Public: SetName   *************************************************
    // *************************************************************************
    void SetName(const char* q_name, const char* t_name = nullptr);

    // *************************************************************************
    // ***   Public: Create   **************************************************
    // *************************************************************************
    Result Create();

    // *************************************************************************
    // ***   Public: Reset   ***************************************************
    // *************************************************************************
    Result Reset();

    // *************************************************************************
    // ***   Public: IsEmpty   *************************************************
    // *************************************************************************
    bool IsEmpty() const;

    // *************************************************************************
    // ***   Public: IsFull   **************************************************
    // *************************************************************************
    bool IsFull() const;

    // *************************************************************************
    // ***   Public: GetMessagesWaiting   **************************************
    // *************************************************************************
    Result GetMessagesWaiting(uint32_t& msg_cnt) const;

    // *************************************************************************
    // ***   Public: SendToBack   ***********************************************
    // *************************************************************************
    Result SendToBack(const void* item, uint32_t timeout_ms = 0u);

    // *************************************************************************
    // ***   Public: SendToFront   *********************************************
    // *************************************************************************
    Result SendToFront(const void* item, uint32_t timeout_ms = 0u);

    // *************************************************************************
    // ***   Public: Receive   *************************************************
    // *************************************************************************
    Result Receive(void* item, uint32_t timeout_ms);

    // *************************************************************************
    // ***   Public: Peek   ****************************************************
    // *************************************************************************
    Result Peek(void* item, uint32_t timeout_ms) const;

    // *************************************************************************
    // ***   Public: GetQueueLen   *********************************************
    // *************************************************************************
    inline uint16_t GetQueueLen(void) const {return queue_len;}

    // *************************************************************************
    // ***   Public: GetItemSize   *********************************************
    // *************************************************************************
    inline uint16_t GetItemSize(void) const {return item_size;}

  private:
    // Queue handle
    QueueHandle_t queue;

    // Number of items in the queue
    uint16_t queue_len = 0u;

    // Size of item
    uint16_t item_size = 0u;

    // Queue name
    const char* queue_name = nullptr;
    const char* task_name = nullptr;

    // Prevent copying and assigning
    RtosQueue();
    RtosQueue(const RtosQueue&);
    RtosQueue& operator=(const RtosQueue&);
};


#endif // FREE_RTOS_QUEUE_H
