// *****************************************************************************
// @file Image.h
// @author Nicolai Shlapunov
//
// @details DevCore: Image Visual Object Class, header
//
// @section COPYRIGHT
//
//  Copyright (c) 2016-2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

#ifndef Images_h
#define Images_h

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "DevCfg.h"
#include "Display/VisObject.h"

// *****************************************************************************
// ***   Palettes external   ***************************************************
// *****************************************************************************
extern const color_t PALETTE_884[256];
extern const color_t PALETTE_775[256];
extern const color_t PALETTE_676[256];

// *****************************************************************************
// ***   Image description structure   *****************************************
// *****************************************************************************
typedef struct typeImageDesc
{
  // Image width
  uint16_t width = 0u;
  // Image height
  uint16_t height = 0u;
  // Bits per pixel
  uint8_t bits_per_pixel = 0u;
  // Pointer to image data
  union
  {
    const void*    img  = nullptr;
    const uint8_t* imgp;
    const color_t* imgb;
  };
  // Pointer to palette
  const color_t* palette = nullptr;
  // Transparent color (-1 no transparent colors)
  int32_t transparent_color = -1;
} ImageDesc;

// *****************************************************************************
// ***   Universal Image Class   ***********************************************
// *****************************************************************************
class Image : public VisObject
{
  public:
    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    Image() {};

    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    Image(int32_t x, int32_t y, const ImageDesc& img_dsc);

    // *************************************************************************
    // ***   Set Image function   **********************************************
    // *************************************************************************
    void SetImage(const ImageDesc& img_dsc);

    // *************************************************************************
    // ***   Set Horizontal Flip function   ************************************
    // *************************************************************************
    inline void SetHorizontalFlip(bool flip) {if(hor_mirror != flip) {hor_mirror = flip; InvalidateObjArea();}}

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
    virtual void DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x = 0);
#endif

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
    virtual void DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y = 0);
#endif

  protected:
    // Pointer to the image
    const void* img = nullptr;
    // Pointer to the palette
    const color_t* palette = nullptr;
    // Transparent color (-1 no transparent colors)
    int32_t transparent_color = -1;
    // Bits per pixel
    uint8_t bits_per_pixel = 0u;
    // Horizontal mirror
    bool hor_mirror = false;
};

// *****************************************************************************
// ***   Palette Image Class   *************************************************
// *****************************************************************************
class ImagePalette : public VisObject
{
  public:
    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    ImagePalette() {};

    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    ImagePalette(int32_t x, int32_t y, int32_t w, int32_t h, const uint8_t* p_img, const color_t* p_palette);

    // *************************************************************************
    // ***   Set Image function   **********************************************
    // *************************************************************************
    Result SetImage(const ImageDesc& img_dsc);

    // *************************************************************************
    // ***   Set Image function   **********************************************
    // *************************************************************************
    void SetImage(const uint8_t* p_img, int32_t w, int32_t h, const color_t* p_palette);

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
    virtual void DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x = 0);
#endif

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
    virtual void DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y = 0);
#endif

  private:
    // Pointer to the image
    const uint8_t* img = nullptr;
    // Pointer to the palette
    const color_t* palette = nullptr;
};

// *****************************************************************************
// ***   Bitmap Image Class   **************************************************
// *****************************************************************************
class ImageBitmap : public VisObject
{
  public:
    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    ImageBitmap() {};

    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    ImageBitmap(int32_t x, int32_t y, int32_t w, int32_t h, const color_t* p_img);

    // *************************************************************************
    // ***   Set Image function   **********************************************
    // *************************************************************************
    Result SetImage(const ImageDesc& img_dsc);

    // *************************************************************************
    // ***   Set Image function   **********************************************
    // *************************************************************************
    void SetImage(const color_t* p_img, int32_t w, int32_t h);

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
    virtual void DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x = 0);
#endif

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
    virtual void DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y = 0);
#endif

  private:
    // Pointer to the image
    const color_t* img = nullptr;
};

// *****************************************************************************
// ***   Binary Image Class   **************************************************
// *****************************************************************************
class ImageBinary : public VisObject
{
  public:
    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    ImageBinary() {};

    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    ImageBinary(int32_t x, int32_t y, int32_t w, int32_t h, const uint8_t* p_img);

    // *************************************************************************
    // ***   Set Image function   **********************************************
    // *************************************************************************
    Result SetImage(const ImageDesc& img_dsc);

    // *************************************************************************
    // ***   Set Image function   **********************************************
    // *************************************************************************
    void SetImage(const uint8_t* p_img, int32_t w, int32_t h);

    // *************************************************************************
    // ***   SetColor   ********************************************************
    // *************************************************************************
    void SetColor(color_t c) {if(color != c) {color = c; InvalidateObjArea();}}

    // *************************************************************************
    // ***   SetBackgroundColor   **********************************************
    // *************************************************************************
    void SetBackgroundColor(color_t c) {if(bg_color != c) {bg_color = c; InvalidateObjArea();}}

    // *************************************************************************
    // ***   SetTransparentColor   *********************************************
    // *************************************************************************
    void SetTransparentColor(color_t c) {if(transparent_color != c) {transparent_color = c; InvalidateObjArea();}}

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
    virtual void DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x = 0);
#endif

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
    virtual void DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y = 0);
#endif

  private:
    // Pointer to the image
    const uint8_t* img = nullptr;
    // Transparent color (-1 no transparent colors)
    color_t color = COLOR_WHITE;
    // Transparent color (-1 no transparent colors)
    color_t bg_color = COLOR_BLACK;
    // Transparent color(shouldn't match any above if no transparency needed)
    color_t transparent_color = COLOR_MAGENTA;
};

#endif
