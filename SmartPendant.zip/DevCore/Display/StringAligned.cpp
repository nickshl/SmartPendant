// *****************************************************************************
// @file StringAligned.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: StringAligned Visual Object Class, implementation
//
// @copyright Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//            All rights reserved.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include <cstring>
#include <stdio.h>

#include "Display/StringAligned.h"

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
StringAligned::StringAligned(const char* str, alignment_t algnmnt, int32_t x, int32_t y, uint32_t w, color_t tc, Font& font)
{
  SetParams(str, algnmnt, x, y, w, tc, font);
}

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
StringAligned::StringAligned(const char* str, alignment_t algnmnt, int32_t x, int32_t y, uint32_t w, color_t tc, color_t bgc, Font& font)
{
  SetParams(str, algnmnt, x, y, w, tc, bgc, font);
}

// *****************************************************************************
// ***   SetParams   ***********************************************************
// *****************************************************************************
void StringAligned::SetParams(const char* str, alignment_t algnmnt, int32_t x, int32_t y, uint32_t w, color_t tc, Font& font)
{
  // Lock object for changes
  LockVisObject();
  // Invalidate area for old string(needed if old string longer than new)
  InvalidateObjArea();
  // Do changes
  string = str;
  x_start = x;
  y_start = y;
  width = w;
  txt_color = tc;
  bg_color = 0;
  font_ptr = &font;
  transpatent_bg = true;
  alignment = algnmnt;
  // Recalculate size based on font and scale
  RecalculateSize();
  // Invalidate area for new string(needed if new string longer than old)
  InvalidateObjArea();
  // Unlock object after changes
  UnlockVisObject();
}

// *****************************************************************************
// ***   SetParams   ***********************************************************
// *****************************************************************************
void StringAligned::SetParams(const char* str, alignment_t algnmnt, int32_t x, int32_t y, uint32_t w, color_t tc, color_t bgc, Font& font)
{
  // Lock object for changes
  LockVisObject();
  // Invalidate area for old string(needed if old string longer than new)
  InvalidateObjArea();
  // Do changes
  string = str;
  x_start = x;
  y_start = y;
  width = w;
  txt_color = tc;
  bg_color = bgc;
  font_ptr = &font;
  transpatent_bg = false;
  alignment = algnmnt;
  // Recalculate size based on font and scale
  RecalculateSize();
  // Invalidate area for new string(needed if new string longer than old)
  InvalidateObjArea();
  // Unlock object after changes
  UnlockVisObject();
}

// *****************************************************************************
// ***   SetAlignment   ********************************************************
// *****************************************************************************
void StringAligned::SetAlignment(alignment_t algnmnt)
{
  // Lock object for changes
  LockVisObject();
  // Save alignment
  alignment = algnmnt;
  // Invalidate area for new string(needed if new string longer than old)
  InvalidateObjArea();
  // Unlock object after changes
  UnlockVisObject();
}

// *****************************************************************************
// ***   SetColor   ************************************************************
// *****************************************************************************
void StringAligned::SetColor(color_t tc, color_t bgc, bool is_trnsp)
{
  // Check if parameters changed
  if((tc != txt_color) || (bgc != bg_color) || (is_trnsp != transpatent_bg))
  {
    // No Lock/Unlock since it will not break anything
    txt_color = tc;
    bg_color = bgc;
    transpatent_bg = is_trnsp;
    // Invalidate area
    InvalidateObjArea();
  }
}

// *****************************************************************************
// ***   Public: SetFont   *****************************************************
// *****************************************************************************
void StringAligned::SetFont(Font& font)
{
  // Check if font changed
  if(&font != font_ptr)
  {
    // Lock object for changes
    LockVisObject();
    // Invalidate area for old string(needed if old string font bigger than new one)
    InvalidateObjArea();
    // Do changes
    font_ptr = &font;
    // Recalculate size based on font and scale
    RecalculateSize();
    // Invalidate area for new string(needed if new string font bigger than old one)
    InvalidateObjArea();
    // Unlock object after changes
    UnlockVisObject();
  }
}

// *****************************************************************************
// ***   SetParams   ***********************************************************
// *****************************************************************************
void StringAligned::SetScale(uint8_t s)
{
  // Scale have to be positive number
  if(s > 0u)
  {
    // Lock object for changes
    LockVisObject();
    // Invalidate area for old string(needed if old string scale bigger than new one)
    InvalidateObjArea();
    // Do changes
    scale = s;
    // Recalculate size based on font and scale
    RecalculateSize();
    // Invalidate area for new string(needed if new string scale bigger than old one)
    InvalidateObjArea();
    // Unlock object after changes
    UnlockVisObject();
  }
}

// *****************************************************************************
// ***   SetString   ***********************************************************
// *****************************************************************************
void StringAligned::SetString(const char* str, bool force)
{
  // Lock object for changes
  LockVisObject();
  // Ignore if same string set again
  if((string != str) || force)
  {
    // Invalidate area for old string(needed if old string longer than new)
    InvalidateObjArea();
    // Set new pointer to string
    string = str;
    // Since this function accept only pointer to constant string - clear length
    length = 0u;
    // Recalculate size based on font and scale
    RecalculateSize();
    // Invalidate area for new string(needed if new string longer than old)
    InvalidateObjArea();
  }
  // Unlock object after changes
  UnlockVisObject();
}

// *****************************************************************************
// ***   SetString   ***********************************************************
// *****************************************************************************
void StringAligned::SetString(char* buf, uint32_t len, const char* format, ...)
{
  // Argument list
  va_list arglist;
  va_start(arglist, format);
  // Lock object for changes
  LockVisObject();
  // Create string
  SetString((char*)buf, len, format, arglist);
  // Unlock object after changes
  UnlockVisObject();
  // End argument list
  va_end(arglist);
}

// *****************************************************************************
// ***   Printf   **************************************************************
// *****************************************************************************
void StringAligned::Printf(const char* format, ...)
{
  // If we don't have valid buffer - don't do anything
  if((string != nullptr) && (length != 0u))
  {
    // Argument list
    va_list arglist;
    va_start(arglist, format);
    // Lock object for changes
    LockVisObject();
    // Create string
    SetString((char*)string, length, format, arglist);
    // Unlock object after changes
    UnlockVisObject();
    // End argument list
    va_end(arglist);
  }
}

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
void StringAligned::DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x)
{
  // Pointer to string. Will increment for get characters. Placed there because
  // of SetStringPtr() function existence.
  const char* str = string;

  // Draw only if needed
  if((line >= y_start) && (line <= y_end) && (str != nullptr) && (font_ptr != nullptr))
  {
    // Current symbol X position
    int32_t x = x_start - start_x;
    // Number of bytes need skipped for draw line
    uint32_t skip_bytes = ((line - y_start) / scale) * GetFontBytePerChar() / GetFontH();

    // Calculate alignment
    if(alignment == CENTER)
    {
      x += (width - length_pixels) / 2;
    }
    else if(alignment == RIGHT)
    {
      x += width - length_pixels;
    }
    else
    {
      ; // Do nothing
    }

    // Find valid visible boundary
    int32_t visible_x_start = x_start - start_x;
    int32_t visible_x_end = x_end - start_x;
    if(visible_x_start < 0) visible_x_start = 0;
    if(visible_x_end >= n) visible_x_end = n - 1;

    // Background fills whole object width, not only the text
    if(transpatent_bg == false)
    {
      for(int32_t i = visible_x_start; i <= visible_x_end; i++) buf[i] = bg_color;
    }

    // While we have symbols and still didn't pass object end. Symbol that
    // starts in the last visible column have to be drawn too.
    while((*str != '\0') && (x <= visible_x_end))
    {
      // Skip symbols before visible area
      if(x + (int32_t)(GetFontW() * scale) <= visible_x_start)
      {
        x += GetFontW() * scale;
        str++;
        continue;
      }
      uint32_t b = 0;
      uint32_t w = 0;
      // Get pointer to character data
      const uint8_t* char_ptr = font_ptr->GetCharGataPtr(*str);
      // Get all symbol line
      for(uint32_t i = 0; i < GetFontBytePerChar() / GetFontH(); i++)
      {
        b |= char_ptr[skip_bytes + i] << (i*8);
      }
      // Output symbol line
      while(w < GetFontW())
      {
        for(uint8_t i = 0u; i < scale; i++)
        {
          // Put color in buffer only if visible (background is already there)
          if((x >= visible_x_start) && (x <= visible_x_end) && ((b&1) == 1))
          {
            buf[x] = txt_color;
          }
          x++;
        }
        b >>= 1;
        w++;
      }
      str++;
    }
  }
}
#endif

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
void StringAligned::DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y)
{
  // Pointer to string
  const char* str = string;

  // Draw only if needed
  if((column >= x_start) && (column <= x_end) && (str != nullptr) && (font_ptr != nullptr))
  {
    // Background fills whole object, not only the text
    if(transpatent_bg == false)
    {
      int32_t from = y_start - start_y;
      int32_t to = y_end - start_y;
      if(from < 0) from = 0;
      if(to >= n) to = n - 1;
      for(int32_t i = from; i <= to; i++) buf[i] = bg_color;
    }
    // Width of one symbol in pixels
    int32_t char_w = GetFontW() * scale;
    // Column inside the text: the same alignment as in DrawInBufW()
    int32_t col = column - x_start;
    if(alignment == CENTER)
    {
      col -= (width - length_pixels) / 2;
    }
    else if(alignment == RIGHT)
    {
      col -= width - length_pixels;
    }
    else
    {
      ; // Do nothing
    }
    // Column before the text - nothing to draw
    if(col >= 0)
    {
      // Find symbol, but don't go after the end of string
      for(int32_t i = col / char_w; (i > 0) && (*str != '\0'); i--) str++;
      // Draw only if symbol exist
      if(*str != '\0')
      {
        // Get pointer to character data
        const uint8_t* char_ptr = font_ptr->GetCharGataPtr(*str);
        // Column inside the symbol
        uint32_t cx = (col % char_w) / scale;
        // Bytes per one symbol line
        uint32_t bytes_per_line = GetFontBytePerChar() / GetFontH();
        // Current Y position in buffer
        int32_t y = y_start - start_y;
        // Get symbols lines
        for(uint32_t i = 0u; i < GetFontH(); i++)
        {
          // Find bit of this column in the symbol line
          bool dot = ((char_ptr[i * bytes_per_line + cx / 8u] >> (cx % 8u)) & 1u) != 0u;
          for(uint8_t k = 0u; k < scale; k++)
          {
            // Put color in buffer only if visible
            if(dot && (y >= 0) && (y < n)) buf[y] = txt_color;
            y++;
          }
        }
      }
    }
  }
}
#endif

// *****************************************************************************
// ***   Private:  SetString   *************************************************
// *****************************************************************************
void StringAligned::SetString(char* buf, uint32_t len, const char* format, va_list& arglist)
{
  if((buf != nullptr) && (len != 0u))
  {
    // Invalidate area for old string(needed if old string longer than new)
    InvalidateObjArea();
    // Create string
    vsnprintf(buf, len, format, arglist);
    // Set new pointer to string
    string = buf;
    // Set length to use PrintString() function later
    length = len;
    // Recalculate size based on font and scale
    RecalculateSize();
    // Invalidate area for new string(needed if new string longer than old)
    InvalidateObjArea();
  }
}

// *****************************************************************************
// ***   Private: RecalculateSize   ********************************************
// *****************************************************************************
void StringAligned::RecalculateSize()
{
  // Calculated string full length in pixels
  length_pixels = strlen(string) * GetFontW() * scale;
  // Calculate height
  height = GetFontH() * scale;
  // Calculate end X and Y
  x_end = x_start + width - 1;
  y_end = y_start + height - 1;
}
