// *****************************************************************************
// @file TiledMap.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: Tiled Map Class, implementation
//
// @copyright Copyright (c) 2017, Devtronic & Nicolai Shlapunov
//            All rights reserved.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "TiledMap.h"

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
TiledMap::TiledMap(int32_t x, int32_t y, int32_t w, int32_t h,
                   uint8_t* map, uint32_t map_w, uint32_t map_h, uint8_t bitmask,
                   const ImageDesc* tiles, uint32_t n, int32_t def_color)
{
  x_start = x;
  y_start = y;
  width = w;
  height = h;
  x_end = x_start + width - 1;
  y_end = y_start + height - 1;
  tiles_map = map;
  map_width = map_w;
  map_height = map_h;
  tile_bitmask = bitmask;
  tiles_img = tiles;
  tiles_cnt = n;
  tile_width = tiles->width;
  tile_height = tiles->height;
  bg_color = def_color;
}

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
void TiledMap::DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x)
{
  // Draw only if needed
  if((line >= y_start) && (line <= y_end) && (tiles_map != nullptr) && (tiles_img != nullptr))
  {
    // Find start x position
    int32_t start = x_start - start_x;
    // Prevent write in memory before buffer
    if(start < 0) start = 0;
    // Find end x position
    int32_t end = x_end - start_x;
    // Prevent buffer overflow
    if(end >= n) end = n - 1;
    // Have sense draw only if part of object is in the buffer
    if(end >= start)
    {
      // If default color is 0 or greater
      if(bg_color >= 0)
      {
        // Fill buffer by default color
        for(int32_t i = start; i <= end; i++)
        {
          buf[i] = bg_color;
        }
      }
      // Pixel of the map that is shown at this screen line. Screen pixel
      // (x_start, y_start) shows map pixel (x_pos, y_pos).
      int32_t my = y_pos + line - y_start;
      // Map have pixels at this line only if it inside the map
      if((my >= 0) && (my < (int32_t)(map_height * tile_height)))
      {
        // Pointer to the line of tiles
        const uint8_t* map_line = &tiles_map[(my / tile_height) * map_width];
        // Offset of the line inside tile image
        int32_t y_tile_offset = (my % tile_height) * tile_width;
        // Map width in pixels
        int32_t map_pix_w = map_width * tile_width;
        // Map pixel of the first drawn pixel
        int32_t mx = x_pos + start + start_x - x_start;
        // Pixel index in the buffer
        int32_t pix_idx = start;
        // Skip part before the map
        if(mx < 0)
        {
          pix_idx -= mx;
          mx = 0;
        }
        // Draw line tile by tile until end of buffer or end of the map
        while((pix_idx <= end) && (mx < map_pix_w))
        {
          // Pixel inside tile
          int32_t tile_pix_idx = mx % tile_width;
          // Number of pixels of this tile in the buffer
          int32_t cnt = tile_width - tile_pix_idx;
          if(cnt > end - pix_idx + 1) cnt = end - pix_idx + 1;
          // Get tile value
          uint8_t tile_val = map_line[mx / tile_width] & tile_bitmask;
          // Skip empty tiles
          if(tile_val < tiles_cnt)
          {
            // Get pointer to the current tile image line
            const uint8_t* tile_ptr = &tiles_img[tile_val].imgp[y_tile_offset + tile_pix_idx];
            // Get pointer to the current tile palette
            const color_t* palette_ptr = tiles_img[tile_val].palette;
            // Get transparent color
            const int32_t transparent_color = tiles_img[tile_val].transparent_color;
            // Draw tile
            for(int32_t i = 0; i < cnt; i++)
            {
              // Get pixel data
              color_t data = palette_ptr[tile_ptr[i]];
              // If not transparent - output to buffer
              if((int32_t)data != transparent_color) buf[pix_idx + i] = data;
            }
          }
          // Next tile
          pix_idx += cnt;
          mx += cnt;
        }
      }
    }
  }
}
#endif

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
void TiledMap::DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y)
{
  // Draw only if needed
  if((column >= x_start) && (column <= x_end) && (tiles_map != nullptr) && (tiles_img != nullptr))
  {
    // Find start y position
    int32_t start = y_start - start_y;
    // Prevent write in memory before buffer
    if(start < 0) start = 0;
    // Find end y position
    int32_t end = y_end - start_y;
    // Prevent buffer overflow
    if(end >= n) end = n - 1;
    // Have sense draw only if part of object is in the buffer
    if(end >= start)
    {
      // If default color is 0 or greater
      if(bg_color >= 0)
      {
        // Fill buffer by default color
        for(int32_t i = start; i <= end; i++)
        {
          buf[i] = bg_color;
        }
      }
      // Pixel of the map that is shown in this screen column
      int32_t mx = x_pos + column - x_start;
      // Map have pixels in this column only if it inside the map
      if((mx >= 0) && (mx < (int32_t)(map_width * tile_width)))
      {
        // Column of tiles
        int32_t tile_col = mx / tile_width;
        // Column inside tile image
        int32_t tile_pix_col = mx % tile_width;
        // Map height in pixels
        int32_t map_pix_h = map_height * tile_height;
        // Map pixel of the first drawn pixel
        int32_t my = y_pos + start + start_y - y_start;
        // Pixel index in the buffer
        int32_t pix_idx = start;
        // Skip part before the map
        if(my < 0)
        {
          pix_idx -= my;
          my = 0;
        }
        // Draw column tile by tile until end of buffer or end of the map
        while((pix_idx <= end) && (my < map_pix_h))
        {
          // Line inside tile
          int32_t tile_line = my % tile_height;
          // Number of pixels of this tile in the buffer
          int32_t cnt = tile_height - tile_line;
          if(cnt > end - pix_idx + 1) cnt = end - pix_idx + 1;
          // Get tile value
          uint8_t tile_val = tiles_map[(my / tile_height) * map_width + tile_col] & tile_bitmask;
          // Skip empty tiles
          if(tile_val < tiles_cnt)
          {
            // Get pointer to the current tile image pixel
            const uint8_t* tile_ptr = &tiles_img[tile_val].imgp[tile_line * tile_width + tile_pix_col];
            // Get pointer to the current tile palette
            const color_t* palette_ptr = tiles_img[tile_val].palette;
            // Get transparent color
            const int32_t transparent_color = tiles_img[tile_val].transparent_color;
            // Draw tile
            for(int32_t i = 0; i < cnt; i++)
            {
              // Get pixel data
              color_t data = palette_ptr[tile_ptr[i * tile_width]];
              // If not transparent - output to buffer
              if((int32_t)data != transparent_color) buf[pix_idx + i] = data;
            }
          }
          // Next tile
          pix_idx += cnt;
          my += cnt;
        }
      }
    }
  }
}
#endif

// *****************************************************************************
// ***   Scroll tiled map   ****************************************************
// *****************************************************************************
void TiledMap::ScrollView(int32_t dx, int32_t dy)
{
  // Lock object for changes
  LockVisObject();
  // Do changes
  x_pos += dx;
  if(x_pos < 0) x_pos = 0;
  y_pos += dy;
  if(y_pos < 0) y_pos = 0;
  // Invalidate area after move to redraw area object move to
  InvalidateObjArea();
  // Unlock object after changes
  UnlockVisObject();
}

// *****************************************************************************
// ***   GetLvlIdxByXY   *******************************************************
// *****************************************************************************
int32_t TiledMap::GetLvlIdxByXY(uint32_t x, uint32_t y)
{
  uint32_t result = -1;
  // Calculate tiles indexes
  uint32_t x_tile = x/tile_width;
  uint32_t y_tile = y/tile_height;
  // Set result only if x & y valid values
  if(x_tile < map_width && y_tile < map_height)
  {
    result = y_tile*map_width + x_tile;
  }
  // Return result
  return result;
}

// *****************************************************************************
// ***   GetLvlDataByXY   ******************************************************
// *****************************************************************************
int8_t TiledMap::GetLvlDataByXY(uint32_t x, uint32_t y)
{
  uint32_t result = 0u;
  // Calculate tiles indexes
  uint32_t x_tile = x/tile_width;
  uint32_t y_tile = y/tile_height;
  // Set result only if x & y valid values
  if(x_tile < map_width && y_tile < map_height)
  {
    result = tiles_map[y_tile*map_width + x_tile];
  }
  // Return result
  return result;
}
