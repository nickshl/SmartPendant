// *****************************************************************************
// @file Primitives.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: Primitives Visual Object Classes(Box, Line, Circle), implementation
//
// @copyright Copyright (c) 2016, Devtronic & Nicolai Shlapunov
//            All rights reserved.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "Primitives.h"

#include <cstdlib> // for abs()

// *****************************************************************************
// ***   Fill part of the buffer   *********************************************
// *****************************************************************************
// Fills cells from..to (both included) of a buffer of n cells. Parts outside
// the buffer are skipped.
static inline void FillBuf(color_t* buf, int32_t n, int32_t from, int32_t to, color_t c)
{
  // Prevent write in memory before buffer
  if(from < 0) from = 0;
  // Prevent buffer overflow
  if(to >= n) to = n - 1;
  // Fill the cells
  for(int32_t i = from; i <= to; i++) buf[i] = c;
}

// *****************************************************************************
// *****************************************************************************
// ***   Box   *****************************************************************
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
Box::Box(int32_t x, int32_t y, int32_t w, int32_t h, color_t c, bool is_fill)
{
  SetParams(x, y, w, h, c, is_fill);
}

// *****************************************************************************
// ***   SetParams   ***********************************************************
// *****************************************************************************
void Box::SetParams(int32_t x, int32_t y, int32_t w, int32_t h, color_t c, bool is_fill)
{
  // Lock object for changes
  LockVisObject();
  // Invalidate area for old position/size
  InvalidateObjArea();
  // Do changes
  color = c;
  bg_color = c;
  x_start = x;
  y_start = y;
  x_end = x + w - 1;
  y_end = y + h - 1;
  width = w;
  height = h;
  fill = is_fill;
  border_width = is_fill ? 0 : 1; // Set border 1 pixel if border isn't fill
  // Invalidate area for new position/size
  InvalidateObjArea();
  // Unlock object after changes
  UnlockVisObject();
}

// *****************************************************************************
// ***   SetBorderWidth   ******************************************************
// *****************************************************************************
void Box::SetBorderWidth(int32_t width)
{
  // Update box only if border width changed
  if(width != border_width)
  {
    // Lock object for changes
    LockVisObject();
    // Set new border width
    border_width = width;
    // Set background color the same if border width is zero
    if(border_width == 0) bg_color = color;
    // Invalidate area
    InvalidateObjArea();
    // Unlock object after changes
    UnlockVisObject();
  }
}

// *****************************************************************************
// ***   SetFill   *************************************************************
// *****************************************************************************
void Box::SetFill(bool f)
{
  // Update box only if color changed
  if(f != fill)
  {
    // Lock object for changes
    LockVisObject();
    // Do changes
    fill = f;
    // Update border width
    border_width = fill ? 0 : 1; // Set border 1 pixel if border isn't fill
    // Invalidate area
    InvalidateObjArea();
    // Unlock object after changes
    UnlockVisObject();
  }
}

// *****************************************************************************
// ***   SetColor   ************************************************************
// *****************************************************************************
void Box::SetColor(color_t c)
{
  // Update box only if color changed
  if(c != color)
  {
    // Lock object for changes
    LockVisObject();
    // Do changes
    color = c;
    // Set background color the same if border width is zero
    if(border_width == 0) bg_color = c;
    // Invalidate area
    InvalidateObjArea();
    // Unlock object after changes
    UnlockVisObject();
  }
}

// *****************************************************************************
// ***   SetBackgroundColor   **************************************************
// *****************************************************************************
void Box::SetBackgroundColor(color_t bgc)
{
  // Update box only if background color changed
  if(bgc != bg_color)
  {
    // Lock object for changes
    LockVisObject();
    // Do changes
    bg_color = bgc;
    // Invalidate area
    InvalidateObjArea();
    // Unlock object after changes
    UnlockVisObject();
  }
}

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
void Box::DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x)
{
  // Draw only if needed
  if((line >= y_start) && (line <= y_end))
  {
    // Find start x position
    int32_t start = x_start - start_x;
    // Find end x position
    int32_t end = x_end - start_x;
    // Have sense draw only if end pointer in buffer (index 0 is in the buffer)
    if(end >= 0)
    {
      // If fill - fill the line with background color
      if(fill)
      {
        FillBuf(buf, n, start, end, bg_color);
      }
      // Top and bottom border lines (if border exist) are solid
      if((line < y_start + border_width) || (line > y_end - border_width))
      {
        FillBuf(buf, n, start, end, color);
      }
      else if(border_width > 0)
      {
        // Left and right borders. Each one is limited by the box: a border
        // wider than half of the box makes the line solid, never wider.
        FillBuf(buf, n, start, ((start + border_width - 1) < end) ? (start + border_width - 1) : end, color);
        FillBuf(buf, n, ((end - border_width + 1) > start) ? (end - border_width + 1) : start, end, color);
      }
    }
  }
}
#endif

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
void Box::DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y)
{
  // Draw only if needed
  if((column >= x_start) && (column <= x_end))
  {
    // Find start y position
    int32_t start = y_start - start_y;
    // Find end y position
    int32_t end = y_end - start_y;
    // Have sense draw only if end pointer in buffer (index 0 is in the buffer)
    if(end >= 0)
    {
      // If fill - fill the column with background color
      if(fill)
      {
        FillBuf(buf, n, start, end, bg_color);
      }
      // Left and right border columns (if border exist) are solid
      if((column < x_start + border_width) || (column > x_end - border_width))
      {
        FillBuf(buf, n, start, end, color);
      }
      else if(border_width > 0)
      {
        // Top and bottom borders. Each one is limited by the box: a border
        // higher than half of the box makes the column solid, never higher.
        FillBuf(buf, n, start, ((start + border_width - 1) < end) ? (start + border_width - 1) : end, color);
        FillBuf(buf, n, ((end - border_width + 1) > start) ? (end - border_width + 1) : start, end, color);
      }
    }
  }
}
#endif

// *****************************************************************************
// *****************************************************************************
// ***   Shadow Box   **********************************************************
// *****************************************************************************
// *****************************************************************************

#if defined(COLOR_24BIT) || defined(COLOR_16BIT) // Shadow box available only for 24 bit or 16 bit color

// *****************************************************************************
// ***   Halve brightness of cells from..to   **********************************
// *****************************************************************************
static inline void ShadowBuf(color_t* buf, int32_t n, int32_t from, int32_t to)
{
  // Prevent write in memory before buffer
  if(from < 0) from = 0;
  // Prevent buffer overflow
  if(to >= n) to = n - 1;
  // Process the cells
  for(int32_t i = from; i <= to; i++)
  {
#if defined(COLOR_24BIT)
    // Convert pointer to uint8_t to process color components individually
    uint8_t* color = reinterpret_cast<uint8_t*>(&buf[i]);
    // Process shadow
    color[0u] /= 2;
    color[1u] /= 2;
    color[2u] /= 2;
#elif defined(COLOR_16BIT)
    // RGB565 with swapped bytes: swap them back, halve each of the three
    // components (the mask clears the bit each one gets from its neighbour)
    // and swap the bytes again
    uint16_t c = static_cast<uint16_t>((buf[i] >> 8) | (buf[i] << 8));
    c = (c >> 1) & 0x7BEFu;
    buf[i] = static_cast<color_t>((c >> 8) | (c << 8));
#endif
  }
}

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
ShadowBox::ShadowBox(int32_t x, int32_t y, int32_t w, int32_t h)
{
  SetParams(x, y, w, h);
}

// *****************************************************************************
// ***   SetParams   ***********************************************************
// *****************************************************************************
void ShadowBox::SetParams(int32_t x, int32_t y, int32_t w, int32_t h)
{
  // Lock object for changes
  LockVisObject();
  // Invalidate area for old position/size
  InvalidateObjArea();
  // Do changes
  x_start = x;
  y_start = y;
  x_end = x + w - 1;
  y_end = y + h - 1;
  width = w;
  height = h;
  // Invalidate area for new position/size
  InvalidateObjArea();
  // Unlock object after changes
  UnlockVisObject();
}

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
void ShadowBox::DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x)
{
  // Draw only if needed
  if((line >= y_start) && (line <= y_end))
  {
    ShadowBuf(buf, n, x_start - start_x, x_end - start_x);
  }
}
#endif

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
void ShadowBox::DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y)
{
  // Draw only if needed
  if((column >= x_start) && (column <= x_end))
  {
    ShadowBuf(buf, n, y_start - start_y, y_end - start_y);
  }
}
#endif

#endif

// *****************************************************************************
// *****************************************************************************
// ***   Line   ****************************************************************
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
Line::Line(int32_t x1, int32_t y1, int32_t x2, int32_t y2, color_t c)
{
  SetParams(x1, y1, x2, y2, c);
}

// *****************************************************************************
// ***   SetParams   ***********************************************************
// *****************************************************************************
void Line::SetParams(int32_t x1, int32_t y1, int32_t x2, int32_t y2, color_t c)
{
  // Lock object for changes
  LockVisObject();
  // Invalidate area for old position/size
  InvalidateObjArea();
  // Do changes
  color = c;
  x_start = x1;
  y_start = y1;
  x_end = x2;
  y_end = y2;
  width  = ((x1 < x2) ? (x2 - x1) : (x1 - x2)) + 1; // Width is one more than coordinates difference
  height = ((y1 < y2) ? (y2 - y1) : (y1 - y2)) + 1; // Height is one more than coordinates difference
  // Invalidate area for new position/size
  InvalidateObjArea();
  // Unlock object after changes
  UnlockVisObject();
}

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
void Line::DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x)
{
  // Draw only if needed
  if(((line >= y_start) && (line <= y_end)) || ((line >= y_end) && (line <= y_start)))
  {
    const int32_t deltaX = abs(x_end - x_start);
    const int32_t deltaY = abs(y_end - y_start);
    const int32_t signX = x_start < x_end ? 1 : -1;
    const int32_t signY = y_start < y_end ? 1 : -1;

    int32_t error = deltaX - deltaY;

    int32_t x = x_start - start_x;
    int32_t y = y_start;

    int32_t end_x = x_end - start_x;
    while((x != end_x || y != y_end) && (y != line))
    {
      const int32_t error2 = error * 2;
      if(error2 > -deltaY) 
      {
        error -= deltaY;
        x += signX;
      }
      if(error2 < deltaX) 
      {
        error += deltaX;
        y += signY;
      }
    }

    // If we found current line
    if(y == line)
    {
      // Go and draw line
      while(true)
      {
        // Draw dot only if it inside buffer
        if((x >= 0) && (x < n)) buf[x] = color;
        // Last dot of the line - nothing to draw anymore
        if((x == end_x) && (y == y_end)) break;
        const int32_t error2 = error * 2;
        if(error2 > -deltaY)
        {
          error -= deltaY;
          x += signX;
        }
        // Next dot belongs to the next screen line - done with this one
        if(error2 < deltaX)
        {
          break;
        }
      }
    }
  }
}
#endif

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
void Line::DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y)
{
  // Draw only if needed
  if(((column >= x_start) && (column <= x_end)) || ((column >= x_end) && (column <= x_start)))
  {
    // The same steps as DrawInBufW() makes, so both draw the same dots
    const int32_t deltaX = abs(x_end - x_start);
    const int32_t deltaY = abs(y_end - y_start);
    const int32_t signX = x_start < x_end ? 1 : -1;
    const int32_t signY = y_start < y_end ? 1 : -1;

    int32_t error = deltaX - deltaY;

    int32_t x = x_start;
    int32_t y = y_start - start_y;

    int32_t end_y = y_end - start_y;
    // Go through cycle until reach end of line or current column
    while((x != x_end || y != end_y) && (x != column))
    {
      const int32_t error2 = error * 2;
      if(error2 > -deltaY)
      {
        error -= deltaY;
        x += signX;
      }
      if(error2 < deltaX)
      {
        error += deltaX;
        y += signY;
      }
    }

    // If we found current column
    if(x == column)
    {
      // Go and draw line
      while(true)
      {
        // Draw dot only if it inside buffer
        if((y >= 0) && (y < n)) buf[y] = color;
        // Last dot of the line - nothing to draw anymore
        if((x == x_end) && (y == end_y)) break;
        const int32_t error2 = error * 2;
        // Next dot belongs to the next column - done with this one
        if(error2 > -deltaY) break;
        if(error2 < deltaX)
        {
          error += deltaX;
          y += signY;
        }
      }
    }
  }
}
#endif

// *****************************************************************************
// *****************************************************************************
// ***   Circle   **************************************************************
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
Circle::Circle(int32_t x, int32_t y, int32_t r, color_t c, bool is_fill, bool is_even)
{
  SetParams(x, y, r, c, is_fill, is_even);
}

// *****************************************************************************
// ***   SetParams   ***********************************************************
// *****************************************************************************
void Circle::SetParams(int32_t x, int32_t y, int32_t r, color_t c, bool is_fill, bool is_even)
{
  // Lock object for changes
  LockVisObject();
  // Invalidate area for old position/size
  InvalidateObjArea();
  // Do changes
  color = c;
  radius = r;
  x_start = x - r;
  y_start = y - r;
  x_end = x + r;
  y_end = y + r;
  width = r*2;
  height = r*2;
  fill = is_fill;
  even = is_even;
  // Invalidate area for new position/size
  InvalidateObjArea();
  // Unlock object after changes
  UnlockVisObject();
}

// *************************************************************************
// ***   SetColor   **************************************II****************
// *************************************************************************
void Circle::SetColor(color_t c)
{
  if(c != color)
  {
    // Lock object for changes
    LockVisObject();
    // Do changes
    color = c;
    // Invalidate area
    InvalidateObjArea();
    // Unlock object after changes
    UnlockVisObject();
  }
}

// *****************************************************************************
// ***   Put one line of circle in buffer   ************************************
// *****************************************************************************
void Circle::DrawCircleLine(color_t* buf, int32_t n, int32_t line, int32_t start_x)
{
  // Draw only if needed
  if((line >= y_start) && (line <= y_end))
  {
    // We draw circle with center in 0,0 coordinates, those two variables to
    // calculate actual position
    int32_t x0 = x_start + radius - start_x;
    int32_t y0 = y_start + radius;
    // Circle with zero radius is one dot in the center, filled or not, even or not
    if(radius == 0)
    {
      if((line == y0) && (x0 >= 0) && (x0 < n)) buf[x0] = color;
      return;
    }
    // Variable for calculations, both for two branches
    int32_t t1 = radius >> 4;

    // Calculate point to chose algorithm. In this point X equal Y(if circle
    // center in 0,0 point). To calculate it we can use formula: Y = R / sqrt(2);
    // To avoid square root calculations we can precalculate it: Y = R / 1.4142;
    // We can replace division by multiplication on 1 / 1.4142: Y = R * 0.7071;
    // We also need point coordinate from the top of the circle, not from center,
    // so we need multiply R by 1 - 0.7071: Y = R * 0.2929;
    // Integer operations calculates faster than float point one, so we can
    // multiply radius by 2929 instead and then divide it by 10000:
    // int32_t shift = (radius * 2928) / 10000;
    // However, we can do better than that. We don't need to use base 10, we can
    // use base 2. In this case we can multiply radius by 0.2929 * 16384,
    // or ~4799, then we can divide result by 16384. But because it is power
    // of 2 number, we can replace division operation by shift operation:
    int32_t shift = (radius * 4799) >> 14;

    // Top and bottom half of circle(on Y axis)
    if((line <= y_start + shift) || (line >= y_end - shift - (even ? 1 : 0)))
    {
      // X and Y variables
      int32_t x = 0;
      int32_t y = radius;
      // Flag to break the cycle when no more new dots draw
      bool line_drawed = false;
      // Calculate cycle
      while(y >= x)
      {
        if((y0 + y == (even ? line + 1 : line)) || (y0 - y == line))
        {
          // Update buffer
          UpdateBuffer(buf, n, x0 - x, x0 + x);
          // We need this flag because for non-filled circle we draw one pixel
          // at a time and we may enter this section again and again until we
          // move to the next line ...
          line_drawed = true;
        }
        else
        {
          // ... at which point we have to break the cycle
          if(line_drawed == true) break;
        }
        // Circle calculation: Jesko's Method
        x++;
        t1 += x;
        int32_t t2 = t1 - y;
        if(t2 >= 0)
        {
          t1 = t2;
          y--;
        }
      }
    }
    else // Two middle half of circle(on Y axis)
    {
      int32_t x = radius;
      int32_t y = 0;
      // Calculate cycle
      while(x >= y)
      {
        if((y0 + y == (even ? line + 1 : line)) || (y0 - y == line))
        {
          // Update buffer
          UpdateBuffer(buf, n, x0 - x, x0 + x);
          // We know for sure, that Y will change at this point, so just break the cycle
          break;
        }
        // Circle calculation: Jesko's Method
        y++;
        t1 += y;
        int32_t t2 = t1 - x;
        if(t2 >= 0)
        {
          t1 = t2;
          x--;
        }
      }
    }
  }
}

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
void Circle::DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x)
{
  DrawCircleLine(buf, n, line, start_x);
}
#endif

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
void Circle::DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y)
{
  // Circle is symmetric about its diagonal: screen column "column", read from
  // the top, is the same as line "column - x_start" of the circle, read from
  // the left. So the column is drawn by DrawCircleLine() with x and y swapped.
  DrawCircleLine(buf, n, y_start + (column - x_start), start_y + (x_start - y_start));
}
#endif

// *****************************************************************************
// ***   Place line or two dots in buffer   ************************************
// *****************************************************************************
void Circle::UpdateBuffer(color_t* buf, int32_t n, int32_t xl, int32_t xr)
{
  if(fill)
  {
    // Column of the right dot: one to the left for an even circle
    int32_t xr_idx = even ? xr - 1 : xr;
    // On the top and the bottom lines of an even circle the right dot is on
    // the left side of the left one. Filled line have to cover both of them,
    // as outline does.
    if(xr_idx < xl)
    {
      int32_t tmp = xl;
      xl = xr_idx;
      xr_idx = tmp;
    }
    // Prevent write in memory before buffer
    if(xl < 0) xl = 0;
    // Prevent buffer overflow
    if(xr_idx >= n) xr_idx = n - 1;
    // We have to draw line from xl to xr_idx including both coordinates
    for(;xl <= xr_idx; xl++)
    {
      buf[xl] = color;
    }
  }
  else
  {
    // Column of the right dot: one to the left for an even circle
    int32_t xr_idx = even ? xr - 1 : xr;
    // Index 0 is the first column of the buffer and must be drawn too
    if((xl >= 0) && (xl < n)) buf[xl] = color;
    if((xr_idx >= 0) && (xr_idx < n)) buf[xr_idx] = color;
  }
}

// *****************************************************************************
// *****************************************************************************
// ***   Triangle   ************************************************************
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
Triangle::Triangle(int32_t x1, int32_t y1, int32_t x2, int32_t y2, int32_t x3, int32_t y3, color_t c, bool is_fill)
{
  SetParams(x1, y1, x2, y2, x3, y3, c, is_fill);
}

// *****************************************************************************
// ***   SetParams   ***********************************************************
// *****************************************************************************
void Triangle::SetParams(int32_t x1, int32_t y1, int32_t x2, int32_t y2, int32_t x3, int32_t y3, color_t c, bool is_fill)
{
  // Lock object for changes
  LockVisObject();
  // Invalidate area for old position/size
  InvalidateObjArea();
  // Do changes
  color = c;
  fill = is_fill;
  x_start = (x1 < x2) ? (x1 < x3 ? x1 : x3) : (x2 < x3 ? x2 : x3);
  y_start = (y1 < y2) ? (y1 < y3 ? y1 : y3) : (y2 < y3 ? y2 : y3);
  x_end = (x1 > x2) ? (x1 > x3 ? x1 : x3) : (x2 > x3 ? x2 : x3);
  y_end = (y1 > y2) ? (y1 > y3 ? y1 : y3) : (y2 > y3 ? y2 : y3);
  width  = x_end - x_start;
  height = y_end - y_start;
  // Lines for draw
  lines[0].x1 = x1;
  lines[0].y1 = y1;
  lines[0].x2 = x2;
  lines[0].y2 = y2;
  lines[1].x1 = x1;
  lines[1].y1 = y1;
  lines[1].x2 = x3;
  lines[1].y2 = y3;
  lines[2].x1 = x2;
  lines[2].y1 = y2;
  lines[2].x2 = x3;
  lines[2].y2 = y3;
  // Invalidate area for new position/size
  InvalidateObjArea();
  // Unlock object after changes
  UnlockVisObject();
}

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
void Triangle::DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x)
{
  // Draw only if needed
  if((line >= y_start) && (line <= y_end))
  {
    // Minimum and maximum x of triangle sides on given screen line. They are
    // found before clipping: filled line must not depend on which part of
    // triangle is inside the buffer.
    int32_t x_min = INT32_MAX;
    int32_t x_max = INT32_MIN;
    // Find minimum and maximum x for given screen line
    for(uint8_t i = 0u; i < 3u; i++)
    {
      // Draw only if needed
      if(((line >= lines[i].y1) && (line <= lines[i].y2)) || ((line >= lines[i].y2) && (line <= lines[i].y1)))
      {
        const int32_t deltaX = abs(lines[i].x2 - lines[i].x1);
        const int32_t deltaY = abs(lines[i].y2 - lines[i].y1);
        const int32_t signX = lines[i].x1 < lines[i].x2 ? 1 : -1;
        const int32_t signY = lines[i].y1 < lines[i].y2 ? 1 : -1;

        int32_t error = deltaX - deltaY;

        int32_t x = lines[i].x1 - start_x;
        int32_t y = lines[i].y1;

        int32_t end_x = lines[i].x2 - start_x;
        // Go through cycle until reach end of line or current line
        while((x != end_x || y != lines[i].y2) && (y != line))
        {
          const int32_t error2 = error * 2;
          if(error2 > -deltaY) 
          {
            error -= deltaY;
            x += signX;
          }
          if(error2 < deltaX) 
          {
            error += deltaX;
            y += signY;
          }
        }
        // If we found current line
        if(y == line)
        {
          // Go along the line
          while(true)
          {
            if(fill == false)
            {
              // Put dot in buffer only if visible
              if((x >= 0) && (x < n)) buf[x] = color;
            }
            else
            {
              x_min = x_min > x ? x : x_min;
              x_max = x_max < x ? x : x_max;
            }
            // Last dot of the side is processed - nothing to do anymore
            if((x == end_x) && (y == lines[i].y2)) break;
            const int32_t error2 = error * 2;
            if(error2 > -deltaY) 
            {
              error -= deltaY;
              x += signX;
            }
            // Side continues on the next line
            if(error2 < deltaX) break;
          }
        }
      }
    }
    if(fill && (x_max >= x_min))
    {
      // Prevent write in memory before buffer
      if(x_min < 0) x_min = 0;
      // Prevent buffer overflow
      if(x_max >= n) x_max = n - 1;
      // Fill the line
      for(int32_t i = x_min; i <= x_max; i++)
      {
        buf[i] = color;
      }
    }
  }
}
#endif

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
void Triangle::DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y)
{
  // Draw only if needed
  if((column >= x_start) && (column <= x_end))
  {
    // Minimum and maximum y of triangle sides in given column. They are
    // found before clipping: filled column must not depend on which part of
    // triangle is inside the buffer.
    int32_t y_min = INT32_MAX;
    int32_t y_max = INT32_MIN;
    // Find minimum and maximum y for given column
    for(uint8_t i = 0u; i < 3u; i++)
    {
      // Draw only if needed
      if(((column >= lines[i].x1) && (column <= lines[i].x2)) || ((column >= lines[i].x2) && (column <= lines[i].x1)))
      {
        // The same steps as DrawInBufW() makes, so both draw the same dots
        const int32_t deltaX = abs(lines[i].x2 - lines[i].x1);
        const int32_t deltaY = abs(lines[i].y2 - lines[i].y1);
        const int32_t signX = lines[i].x1 < lines[i].x2 ? 1 : -1;
        const int32_t signY = lines[i].y1 < lines[i].y2 ? 1 : -1;

        int32_t error = deltaX - deltaY;

        int32_t x = lines[i].x1;
        int32_t y = lines[i].y1 - start_y;

        int32_t end_y = lines[i].y2 - start_y;
        // Go through cycle until reach end of side or current column
        while((x != lines[i].x2 || y != end_y) && (x != column))
        {
          const int32_t error2 = error * 2;
          if(error2 > -deltaY)
          {
            error -= deltaY;
            x += signX;
          }
          if(error2 < deltaX)
          {
            error += deltaX;
            y += signY;
          }
        }
        // If we found current column
        if(x == column)
        {
          // Go along the side
          while(true)
          {
            if(fill == false)
            {
              // Put dot in buffer only if visible
              if((y >= 0) && (y < n)) buf[y] = color;
            }
            else
            {
              y_min = y_min > y ? y : y_min;
              y_max = y_max < y ? y : y_max;
            }
            // Last dot of the side is processed - nothing to do anymore
            if((x == lines[i].x2) && (y == end_y)) break;
            const int32_t error2 = error * 2;
            // Side continues in the next column
            if(error2 > -deltaY) break;
            if(error2 < deltaX)
            {
              error += deltaX;
              y += signY;
            }
          }
        }
      }
    }
    // A filled column of the triangle is the same as the dots of its sides
    // in this column and everything between them
    if(fill && (y_max >= y_min))
    {
      FillBuf(buf, n, y_min, y_max, color);
    }
  }
}
#endif
