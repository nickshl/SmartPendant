// *****************************************************************************
// @file VisList.h
// @author Nicolai Shlapunov
//
// @details DevCore: Visual Object Base Class, header
//
// @section COPYRIGHT
//
//  Copyright (c) 2016-2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

#ifndef VisList_h
#define VisList_h

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "DevCfg.h"
#include "Display/VisObject.h"
#include "Framework/AppTask.h"

// *****************************************************************************
// ***   Forward declaration   *************************************************
// *****************************************************************************
class DisplayDrv;

// *****************************************************************************
// ***   VisList class   *******************************************************
// *****************************************************************************
class VisList : public VisObject
{
  public:
    // *************************************************************************
    // ***   Public constructor: VisList   *************************************
    // ************************************************************************* 
    VisList(DisplayDrv& drv);

    // *************************************************************************
    // ***   Public constructor: VisList   *************************************
    // *************************************************************************
    VisList();

    // *************************************************************************
    // ***   SetDisplayDriver   ************************************************
    // *************************************************************************
    Result SetDisplayDriver(DisplayDrv& drv);

    // *************************************************************************
    // ***   SetList   *********************************************************
    // *************************************************************************
    virtual Result SetList(VisList& l);

    // *************************************************************************
    // ***   SetParams   *******************************************************
    // *************************************************************************
    void SetParams(int32_t x, int32_t y, int32_t w, int32_t h);

    // *************************************************************************
    // ***   Add Visual Object to object list   ********************************
    // *************************************************************************
    Result AddVisObjectToList(VisObject* obj, uint32_t z);

    // *************************************************************************
    // ***   Delete Visual Object from object list   ***************************
    // *************************************************************************
    Result DelVisObjectFromList(VisObject* obj);

    // *************************************************************************
    // ***   DrawInBufW   ******************************************************
    // *************************************************************************
    // * DrawInBufW: Draw In Buffer along Width. The buffer is one screen
    // * line (y = line), from screen column start_x. Used by Top to Bottom
    // * update mode.
    // * Each derived class must implement this function.
#if defined(USE_UPDATE_TOP_BOTTOM)
    virtual void DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x =  0);
#endif

    // *************************************************************************
    // ***   DrawInBufH   ******************************************************
    // *************************************************************************
    // * DrawInBufH: Draw In Buffer along Height. The buffer is one screen
    // * column (x = column), from screen line start_y. Used by Left to Right
    // * update mode.
    // * Each derived class must implement this function.
#if defined(USE_UPDATE_LEFT_RIGHT)
    virtual void DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y =  0);
#endif

    // *************************************************************************
    // ***   Action   **********************************************************
    // *************************************************************************
    virtual void Action(ActionType action, int32_t tx, int32_t ty, int32_t tpx, int32_t tpy);

    // *************************************************************************
    // ***   Invalidate Area   *************************************************
    // *************************************************************************
    virtual void InvalidateArea(int16_t start_x, int16_t start_y, int16_t end_x, int16_t end_y);

    // *************************************************************************
    // ***   IsShow   **********************************************************
    // *************************************************************************
    virtual bool IsShow(void);

  private:
    // *************************************************************************
    // ***   Object parameters   ***********************************************
    // *************************************************************************    // Pointer to first object in list
    VisObject* object_first = nullptr;
    // Pointer to last object in list
    VisObject* object_last = nullptr;
    // Display driver instance
    DisplayDrv* display_drv = nullptr;

    // VisObject is friend for access display_drv
    friend class VisObject;
};

#endif
