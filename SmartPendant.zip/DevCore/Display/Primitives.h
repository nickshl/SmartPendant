// *****************************************************************************
// @file Primitives.h
// @author Nicolai Shlapunov
//
// @details DevCore: Primitives Visual Object Classes(Box, Line, Circle), header
//
// @section COPYRIGHT
//
//  Copyright (c) 2016-2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

#ifndef Primitives_h
#define Primitives_h

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "DevCfg.h"
#include "Display/VisObject.h"

// *****************************************************************************
// ***   Box Class   ***********************************************************
// *****************************************************************************
class Box : public VisObject
{
  public:
    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    Box() {};

    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    Box(int32_t x, int32_t y, int32_t w, int32_t h, color_t c, bool is_fill = true);

    // *************************************************************************
    // ***   SetParams   *******************************************************
    // *************************************************************************
    void SetParams(int32_t x, int32_t y, int32_t w, int32_t h, color_t c, bool is_fill = true);

    // *************************************************************************
    // ***   SetBorderWidth   **************************************************
    // *************************************************************************
    void SetBorderWidth(int32_t width);

    // *************************************************************************
    // ***   GetBorderWidth   **************************************************
    // *************************************************************************
    int32_t GetBorderWidth() {return border_width;}

    // *************************************************************************
    // ***   SetFill   *********************************************************
    // *************************************************************************
    void SetFill(bool f);

    // *************************************************************************
    // ***   GetFill   *********************************************************
    // *************************************************************************
    bool GetFill() {return fill;}

    // *************************************************************************
    // ***   SetColor   ********************************************************
    // *************************************************************************
    void SetColor(color_t c);

    // *************************************************************************
    // ***   GetColor   ********************************************************
    // *************************************************************************
    color_t GetColor() {return color;}

    // *************************************************************************
    // ***   SetBackgroundColor   **********************************************
    // *************************************************************************
    void SetBackgroundColor(color_t bgc);

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
    virtual void DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x = 0);
#endif

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
    virtual void DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y = 0);
#endif

  private:
    // Box color
    color_t color = COLOR_BLACK;
    // Box color
    color_t bg_color = COLOR_BLACK;
    // Is box fill ?
    bool fill = false;
    // Border width
    int32_t border_width = 0;
};

// *****************************************************************************
// ***   ShadowBox Class   *****************************************************
// *****************************************************************************
#if defined(COLOR_24BIT) || defined(COLOR_16BIT) // Shadow box available only for 24 bit or 16 bit color
class ShadowBox : public VisObject
{
  public:
    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    ShadowBox() {};

    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    ShadowBox(int32_t x, int32_t y, int32_t w, int32_t h);

    // *************************************************************************
    // ***   SetParams   *******************************************************
    // *************************************************************************
    void SetParams(int32_t x, int32_t y, int32_t w, int32_t h);

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
    virtual void DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x = 0);
#endif

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
    virtual void DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y = 0);
#endif

  private:
};
#endif

// *****************************************************************************
// ***   Line Class   **********************************************************
// *****************************************************************************
class Line : public VisObject
{
  public:
    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    Line() {};

    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    Line(int32_t x1, int32_t y1, int32_t x2, int32_t y2, color_t c);

    // *************************************************************************
    // ***   SetParams   *******************************************************
    // *************************************************************************
    void SetParams(int32_t x1, int32_t y1, int32_t x2, int32_t y2, color_t c);

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
    virtual void DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x = 0);
#endif

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
    virtual void DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y = 0);
#endif

  private:
    // Line color
    color_t color = COLOR_BLACK;
};

// *****************************************************************************
// ***   Circle Class   ********************************************************
// *****************************************************************************
class Circle : public VisObject
{
  public:
    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    Circle() {};

    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    Circle(int32_t x, int32_t y, int32_t r, color_t c, bool is_fill = false, bool is_even = false);

    // *************************************************************************
    // ***   SetParams   **************************************II***************
    // *************************************************************************
    void SetParams(int32_t x, int32_t y, int32_t r, color_t c, bool is_fill = false, bool is_even = false);

    // *************************************************************************
    // ***   SetColor   ********************************************************
    // *************************************************************************
    void SetColor(color_t c);

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
    virtual void DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x = 0);
#endif

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
    virtual void DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y = 0);
#endif

  private:
    // Circle color
    color_t color = COLOR_BLACK;
    // Circle radius
    int16_t radius = 0;
    // If circle is even - decrease radius by half a pixel(or diameter by 1 pixel)
    bool even = false;
    // Is box fill ?
    bool fill = false;

    // *************************************************************************
    // ***   Place line or two dots in buffer   ********************************
    // *************************************************************************
    void UpdateBuffer(color_t* buf, int32_t n, int32_t xl, int32_t xr);

    // *************************************************************************
    // ***   Put one line of circle in buffer   ********************************
    // *************************************************************************
    // * Used by DrawInBufW() and, with x and y swapped, by DrawInBufH()
    void DrawCircleLine(color_t* buf, int32_t n, int32_t line, int32_t start_x);
};

// *****************************************************************************
// ***   Triangle Class   ******************************************************
// *****************************************************************************
class Triangle : public VisObject
{
  public:
    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    Triangle() {};

    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    Triangle(int32_t x1, int32_t y1, int32_t x2, int32_t y2, int32_t x3, int32_t y3, color_t c, bool is_fill = false);

    // *************************************************************************
    // ***   SetParams   *******************************************************
    // *************************************************************************
    void SetParams(int32_t x1, int32_t y1, int32_t x2, int32_t y2, int32_t x3, int32_t y3, color_t c, bool is_fill = false);

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
    virtual void DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x = 0);
#endif

    // *************************************************************************
    // ***   Put line in buffer   **********************************************
    // *************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
    virtual void DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y = 0);
#endif

  private:
    // Struct for store lines
    struct Line
    {
      int32_t x1 = 0;
      int32_t y1 = 0;
      int32_t x2 = 0;
      int32_t y2 = 0;
    };
    // Lines points
    Line lines[3] = {0};
    // Triangle color
    color_t color = COLOR_BLACK;
    // Is triangle fill ?
    bool fill = false;
};

#endif
