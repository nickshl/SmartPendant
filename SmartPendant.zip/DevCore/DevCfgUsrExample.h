//******************************************************************************
//  @file DefCfgUsr.h
//  @author Nicolai Shlapunov
//
//  @details DevCore: Config file, header
//
//  This file contains example of user configuration for DevCore library.
//  Move this file to your project and rename it to DefCfgUsr.h
//  Modify configuration as needed.
//
//******************************************************************************

#ifndef DevCfgUsr_h
#define DevCfgUsr_h

// *****************************************************************************
// ***   Include for hardware   ************************************************
// *****************************************************************************
#include "stm32f4xx.h"

// *****************************************************************************
// ***   RTOS Wrapper   ********************************************************
// *****************************************************************************
#define FREERTOS_WRAPPER

// *****************************************************************************
// ***   Tasks stack size and priorities configuration   ***********************
// *****************************************************************************

// *** Applications tasks stack sizes   ****************************************
#define APPLICATION_TASK_STACK_SIZE (1024u)
// *** Applications tasks priorities   *****************************************
#define APPLICATION_TASK_PRIORITY (RTOS_IDLE_TASK_PRIORITY + 3u)

// *****************************************************************************
// ***   Display Configuration   ***********************************************
// *****************************************************************************

// Max line in pixels for allocate buffer in Display Driver. Usually equal to
// maximum number of pixels in line. But sometimes can be greater than that.
// For example ILI9488 uses 18 bit color(3 bytes per pixel) and if 16 bit color
// is used(2 bytes per pixel) in order to prepare data display driver need 1.5
// times more memory
#define DISPLAY_MAX_BUF_LEN 320u

// Display update modes, at least one have to be defined. Top to Bottom draws
// the screen line by line (DrawInBufW() of every visual object). Left to Right
// draws it column by column (DrawInBufH()), which suits drawing like an
// oscilloscope trace: a column takes its data by index. Draw functions of a
// mode that isn't defined are not compiled, which saves flash. With both
// defined, DisplayDrv::SetUpdateMode() selects one at run time.
#define USE_UPDATE_TOP_BOTTOM
//#define USE_UPDATE_LEFT_RIGHT

// Color depth used by display
//#define COLOR_24BIT
//#define COLOR_16BIT
//#define COLOR_3BIT

// By uncommenting this line, display task will update only specific area that
// have to be updated
//#define UPDATE_AREA_ENABLED

// In some cases one area isn't enough. In case of changes in small areas far
// away on a large display, it makes sense to have multiple areas that can be
// updated this option defines how many such areas is present. In case of
// overflow, code will merge areas to update everything that have to be updated.
//#define MULTIPLE_UPDATE_AREAS 32

// Display FPS/Touch/Update Area debug options
//#define DISPLAY_DEBUG_INFO
//#define DISPLAY_DEBUG_AREA
//#define DISPLAY_DEBUG_TOUCH

// FPS text of DISPLAY_DEBUG_INFO: screen position of its top left corner,
// color and one of the built-in fonts. Defaults are the values below.
//#define DISPLAY_DEBUG_INFO_X     (0)
//#define DISPLAY_DEBUG_INFO_Y     (0)
//#define DISPLAY_DEBUG_INFO_COLOR COLOR_MAGENTA
//#define DISPLAY_DEBUG_INFO_FONT  Font_4x6

// *****************************************************************************
// ***   Break() macro   *******************************************************
// *****************************************************************************

// Break macro: in case something goes wrong(like error happen), DevCore uses
// Break() call. This macro should be defined either as break command for
// debugging purposes, or as an assert. In this example it defined as break
// command for ARM MCUs.
#define Break() asm volatile("bkpt #0")

#endif
