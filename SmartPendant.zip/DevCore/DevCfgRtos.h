// *****************************************************************************
// @file DevCfgRtosWrapper.h
// @author Nicolai Shlapunov
//
// @details DevCore: Rtos Wrapper include file, header
//
// @section COPYRIGHT
//
//  Copyright (c) 2016-2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

#ifndef DevCfgRtosWrapper_h
#define DevCfgRtosWrapper_h

// *****************************************************************************
// ***   User configuration include   ******************************************
// *****************************************************************************
#include "DevCfgUsr.h"

// *****************************************************************************
// ***   RTOS Wrapper Headers   ************************************************
// *****************************************************************************

// ***   FreeRTOS Headers   ****************************************************
#if defined(FREERTOS_WRAPPER)
  // Defines
  #define RTOS_MINIMAL_STACK_SIZE  configMINIMAL_STACK_SIZE
  #define RTOS_IDLE_TASK_PRIORITY  tskIDLE_PRIORITY
  #define RTOS_TIMER_TASK_PRIORITY configTIMER_TASK_PRIORITY
  #define RTOS_MAX_PRIORITIES      configMAX_PRIORITIES
  // Includes
  #include "FreeRtosWrapper/Rtos.h"
  #include "FreeRtosWrapper/RtosMutex.h"
  #include "FreeRtosWrapper/RtosQueue.h"
  #include "FreeRtosWrapper/RtosRecursiveMutex.h"
  #include "FreeRtosWrapper/RtosSemaphore.h"
  #include "FreeRtosWrapper/RtosTick.h"
  #include "FreeRtosWrapper/RtosTimer.h"
// ***   C++ standard library threads (Linux, Windows, macOS)   ****************
#elif defined(STD_RTOS_WRAPPER)
  // Defines: priorities and stack sizes are not used by this wrapper
  #define RTOS_MINIMAL_STACK_SIZE  (256u)
  #define RTOS_MAX_PRIORITIES      (8u)
  #define RTOS_IDLE_TASK_PRIORITY  (0u)
  #define RTOS_TIMER_TASK_PRIORITY (RTOS_MAX_PRIORITIES - 1u)
  // Includes
  #include "StdRtosWrapper/Rtos.h"
  #include "StdRtosWrapper/RtosMutex.h"
  #include "StdRtosWrapper/RtosQueue.h"
  #include "StdRtosWrapper/RtosRecursiveMutex.h"
  #include "StdRtosWrapper/RtosSemaphore.h"
  #include "StdRtosWrapper/RtosTick.h"
  #include "StdRtosWrapper/RtosTimer.h"
#else
  #error "No RTOS wrapper specified"
#endif

#endif
