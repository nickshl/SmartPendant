// *****************************************************************************
// @file UiCheckbox.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: UI Checkbox Visual Object Class, implementation
//
// @copyright Copyright (c) 2016, Devtronic & Nicolai Shlapunov
//            All rights reserved.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "UiCheckbox.h"

// *****************************************************************************
// ***   Fill part of the buffer   *********************************************
// *****************************************************************************
// Fills cells from..to (both included) of a buffer of n cells. Parts outside
// the buffer are skipped.
static inline void FillBuf(color_t* buf, int32_t n, int32_t from, int32_t to, color_t c)
{
  // Prevent write in memory before buffer
  if(from < 0) from = 0;
  // Prevent buffer overflow
  if(to >= n) to = n - 1;
  // Fill the cells
  for(int32_t i = from; i <= to; i++) buf[i] = c;
}

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
UiCheckbox::UiCheckbox(int32_t x, int32_t y, bool is_checked, bool is_active)
{
  x_start = x;
  y_start = y;
  x_end = x + 13 - 1;
  y_end = y + 13 - 1;
  width = 13;
  height = 13;
  active = is_active;
  checked = is_checked;
}

// *****************************************************************************
// ***   Set callback function   ***********************************************
// *****************************************************************************
void UiCheckbox::SetCallback(AppTask& task, CallbackPtr func, void* param)
{
  callback_task = &task;
  callback_func = func;
  callback_param = param;
}

// *****************************************************************************
// ***   SetChecked   **********************************************************
// *****************************************************************************
void UiCheckbox::SetChecked(bool is_checked)
{
  // Set flag to draw pressed button
  checked = is_checked;
  // Invalidate area
  InvalidateObjArea();
}

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
void UiCheckbox::DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x)
{
  // Draw only if needed
  if((line >= y_start) && (line <= y_end))
  {
    // Checkbox is a solid square for now
    FillBuf(buf, n, x_start - start_x, x_end - start_x, checked ? COLOR_YELLOW : COLOR_MAGENTA);
  }
}
#endif

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
void UiCheckbox::DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y)
{
  // Draw only if needed
  if((column >= x_start) && (column <= x_end))
  {
    // Checkbox is a solid square for now
    FillBuf(buf, n, y_start - start_y, y_end - start_y, checked ? COLOR_YELLOW : COLOR_MAGENTA);
  }
}
#endif

// *****************************************************************************
// ***   Action   **************************************************************
// *****************************************************************************
void UiCheckbox::Action(VisObject::ActionType action, int32_t tx, int32_t ty, int32_t tpx, int32_t tpy)
{
  // Switch for process action
  switch(action)
  {
    // Touch action
    case VisObject::ACT_TOUCH:
      // Change checked state
      checked = !checked;
      // Call callback after reset flag since another task can set it again
      if(callback_task != nullptr)
      {
        callback_task->Callback(callback_func, callback_param, this);
      }
      // Invalidate area
      InvalidateObjArea();
      break;

    // Untouch action 
    case VisObject::ACT_UNTOUCH:
      break;

    case VisObject::ACT_HOLD: // Intentional fall-trough
    case VisObject::ACT_MAX:
    default:
      break;
  }
}
