// *****************************************************************************
// @file UiScroll.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: UI Scroll Visual Object Class, implementation
//
// @copyright Copyright (c) 2016, Devtronic & Nicolai Shlapunov
//            All rights reserved.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "UiScroll.h"

// *****************************************************************************
// ***   Fill part of the buffer   *********************************************
// *****************************************************************************
// Fills cells from..to (both included) of a buffer of n cells. Parts outside
// the buffer are skipped.
static inline void FillBuf(color_t* buf, int32_t n, int32_t from, int32_t to, color_t c)
{
  // Prevent write in memory before buffer
  if(from < 0) from = 0;
  // Prevent buffer overflow
  if(to >= n) to = n - 1;
  // Fill the cells
  for(int32_t i = from; i <= to; i++) buf[i] = c;
}

// *****************************************************************************
// ***   Fill cells from..to limited by lo..hi   *******************************
// *****************************************************************************
static inline void FillBufIn(color_t* buf, int32_t n, int32_t from, int32_t to, int32_t lo, int32_t hi, color_t c)
{
  FillBuf(buf, n, (from < lo) ? lo : from, (to > hi) ? hi : to, c);
}

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
UiScroll::UiScroll(int32_t x, int32_t y, int32_t w, int32_t h, int32_t n, int32_t bar,
                   bool is_vertical, bool is_has_buttons, bool is_active)
{
  SetParams(x, y, w, h, n, bar, is_vertical, is_has_buttons, is_active);
}

// *****************************************************************************
// ***   SetParams   ***********************************************************
// *****************************************************************************
void UiScroll::SetParams(int32_t x, int32_t y, int32_t w, int32_t h, int32_t n, int32_t bar,
                         bool is_vertical, bool is_has_buttons, bool is_active)
{
  // General params
  x_start = x;
  y_start = y;
  x_end = x + w - 1;
  y_end = y + h - 1;
  width = w;
  height = h;
  active = is_active;
  // Private params
  cnt = 0;
  total_cnt = n;
  bar_cnt = bar;
  vertical = is_vertical;
  has_buttons = is_has_buttons;
  // Calculated data for drawing
  bar_shift = 1;
  total_len = (vertical ? height : width) - 2; // Total length for bar
  // Vertical with buttons
  if(has_buttons &&  vertical)
  {
    total_len -= width*2;
    bar_shift = width + 1;
  }
  // Horizontal with buttons
  if(has_buttons && !vertical)
  {
    total_len -= height*2;
    bar_shift = height + 1;
  }
  if(bar_cnt > total_cnt) bar_cnt = total_cnt; // Bar can't be greater total len
  // Bar length and length available for bar moving
  UpdateBar();
}

// *****************************************************************************
// ***   Private: UpdateBar   **************************************************
// *****************************************************************************
void UiScroll::UpdateBar(void)
{
  if(total_cnt > 0)
  {
    bar_len = (total_len * bar_cnt) / total_cnt; // Bar length
    if(bar_len == 0) bar_len = 1; // Bar height can't be less than 1
  }
  else
  {
    // Nothing to scroll: the bar takes all the length
    bar_len = total_len;
  }
  empty_len = total_len - bar_len; // Empty length available for bar moving
}

// *****************************************************************************
// ***   Set total number of lines   *******************************************
// *****************************************************************************
void UiScroll::SetTotal(int32_t val)
{
  // Total can't be negative
  if(val < 0) val = 0;
  // Update only if there change
  if(val != total_cnt)
  {
    // Lock object for changes
    LockVisObject();
    // Update total
    total_cnt = val;
    // Bar can't be greater than total
    if(bar_cnt > total_cnt) bar_cnt = total_cnt;
    // Position can't be past the last line
    if(cnt > total_cnt - 1) cnt = total_cnt - 1;
    if(cnt < 0) cnt = 0;
    // Bar length depends on the total
    UpdateBar();
    // Invalidate area
    InvalidateObjArea();
    // Unlock object after changes
    UnlockVisObject();
  }
}

// *****************************************************************************
// ***   Set bar width/height in scroll lines   ********************************
// *****************************************************************************
void UiScroll::SetBar(int32_t val)
{
  // Bar can't be negative or greater than total
  if(val < 0) val = 0;
  if(val > total_cnt) val = total_cnt;
  // Update only if there change
  if(val != bar_cnt)
  {
    // Lock object for changes
    LockVisObject();
    bar_cnt = val;
    // Bar length and length available for bar moving
    UpdateBar();
    // Invalidate area
    InvalidateObjArea();
    // Unlock object after changes
    UnlockVisObject();
  }
}

// *****************************************************************************
// ***   Set colors of the frame and the bar   *********************************
// *****************************************************************************
void UiScroll::SetColors(color_t frame, color_t bar)
{
  // Update only if there change
  if((frame != frame_color) || (bar != bar_color))
  {
    frame_color = frame;
    bar_color = bar;
    InvalidateObjArea();
  }
}

// *****************************************************************************
// ***   Return End Y coordinate   *********************************************
// *****************************************************************************
void UiScroll::SetScrollPos(int32_t pos)
{
  if(pos != cnt)
  {
    cnt = pos;
    InvalidateObjArea();
  }
}

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_TOP_BOTTOM)
void UiScroll::DrawInBufW(color_t* buf, int32_t n, int32_t line, int32_t start_x)
{
  // Frame color
  color_t color = frame_color;
  // Draw only if needed
  if((line >= y_start) && (line <= y_end))
  {
    // Object start and end in the buffer, not clipped. Everything below is
    // drawn inside them only; FillBuf() clips to the buffer.
    int32_t start = x_start - start_x;
    int32_t end = x_end - start_x;
    // Have sense draw only if part of the scroll is in the buffer (index 0 is in the buffer)
    if((end >= 0) && (start < n))
    {
      // Draw border of scroll: first and last lines, and the button lines of a
      // vertical scroll with buttons, are solid
      if(   (line == y_start) || (line == y_end)
         || (has_buttons && vertical && ((line == y_start + width) || (line == y_end - width + 1))) )
      {
        FillBuf(buf, n, start, end, color);
      }
      else
      {
        FillBuf(buf, n, start, start, color);
        FillBuf(buf, n, end, end, color);
        // Button columns of a horizontal scroll with buttons
        if(has_buttons && !vertical)
        {
          FillBufIn(buf, n, start + height, start + height, start, end, color);
          FillBufIn(buf, n, end - height, end - height, start, end, color);
        }
      }
      // Find start of bar position: initial shift plus position of the bar
      int32_t bar_start = bar_shift;
      // Add bar additional shift (no shift if there is nothing to scroll)
      if(total_cnt > 1) bar_start += (empty_len * cnt) / (total_cnt - 1);
      if(vertical)
      {
        // Draw bar line between the left and the right border
        if((line >= y_start + bar_start) && (line < y_start + bar_start + bar_len))
        {
          FillBuf(buf, n, start + 1, end - 1, bar_color);
        }
      }
      else
      {
        // Draw bar between the top and the bottom border, inside the scroll
        if((line != y_start) && (line != y_end))
        {
          FillBufIn(buf, n, start + bar_start, start + bar_start + bar_len - 1, start, end, bar_color);
        }
      }
    }
  }
}
#endif

// *****************************************************************************
// ***   Put line in buffer   **************************************************
// *****************************************************************************
#if defined(USE_UPDATE_LEFT_RIGHT)
void UiScroll::DrawInBufH(color_t* buf, int32_t n, int32_t column, int32_t start_y)
{
  // Frame color
  color_t color = frame_color;
  // Draw only if needed
  if((column >= x_start) && (column <= x_end))
  {
    // Object start and end in the buffer, not clipped. Everything below is
    // drawn inside them only; FillBuf() clips to the buffer.
    int32_t start = y_start - start_y;
    int32_t end = y_end - start_y;
    // Have sense draw only if part of the scroll is in the buffer (index 0 is in the buffer)
    if((end >= 0) && (start < n))
    {
      // Draw border of scroll: first and last columns, and the button columns
      // of a horizontal scroll with buttons, are solid. The same picture as
      // DrawInBufW() draws.
      if(   (column == x_start) || (column == x_end)
         || (has_buttons && !vertical && ((column == x_start + height) || (column == x_end - height))) )
      {
        FillBuf(buf, n, start, end, color);
      }
      else
      {
        FillBuf(buf, n, start, start, color);
        FillBuf(buf, n, end, end, color);
        // Button lines of a vertical scroll with buttons
        if(has_buttons && vertical)
        {
          FillBufIn(buf, n, start + width, start + width, start, end, color);
          FillBufIn(buf, n, end - width + 1, end - width + 1, start, end, color);
        }
      }
      // Find start of bar position: initial shift plus position of the bar
      int32_t bar_start = bar_shift;
      // Add bar additional shift (no shift if there is nothing to scroll)
      if(total_cnt > 1) bar_start += (empty_len * cnt) / (total_cnt - 1);
      if(vertical)
      {
        // Draw bar between the left and the right border
        if((column != x_start) && (column != x_end))
        {
          FillBufIn(buf, n, start + bar_start, start + bar_start + bar_len - 1, start, end, bar_color);
        }
      }
      else
      {
        // Draw bar column between the top and the bottom border
        if((column >= x_start + bar_start) && (column < x_start + bar_start + bar_len))
        {
          FillBuf(buf, n, start + 1, end - 1, bar_color);
        }
      }
    }
  }
}
#endif

// *****************************************************************************
// ***   Action   **************************************************************
// *****************************************************************************
void UiScroll::Action(VisObject::ActionType action, int32_t tx, int32_t ty, int32_t tpx, int32_t tpy)
{
  // Switch for process action
  switch(action)
  {
    // Touch action
    case VisObject::ACT_TOUCH:
      // Button touch processing
      if(has_buttons == true)
      {
        // If touched less than start pos plus width/height, we touch in square DEC btn
        if(   ( vertical && (ty < y_start + bar_shift))
           || (!vertical && (tx < x_start + bar_shift)) )
        {
          // Decrease counter
          cnt--;
          // If counter less than zero - correct it
          if(cnt < 0) cnt = 0;
        }
        // If touched greater than end pos minus width, we touch in square INC btn
        if(   ( vertical && (ty > y_end - bar_shift))
           || (!vertical && (tx > x_end - bar_shift)) )
        {
          // Increase counter
          cnt++;
          // If counter less than total count minus bar count - correct it
          if(cnt >= total_cnt) cnt = total_cnt-1;
          // Nothing to scroll: position stays 0
          if(cnt < 0) cnt = 0;
        }
      }
      // Touch directly to bar
      if(vertical)
      {
        // Check touch in bar area
        if((ty > y_start + bar_shift) && (ty < y_end - bar_shift))
        {
          // Find press coordinates from bar start position
          int32_t press = (ty - y_start - bar_shift);
          // Calculate new count value
          cnt = (press * total_cnt) / total_len;
        }
      }
      else
      {
        // Check touch in bar area
        if((tx > x_start + bar_shift) && (tx < x_end - bar_shift))
        {
          // Find press coordinates from bar start position
          int32_t press = (tx - x_start - bar_shift);
          // Calculate new count value
          cnt = (press * total_cnt) / total_len;
        }
      }
      break;

    // Untouch action 
    case VisObject::ACT_UNTOUCH:
      break;

    case VisObject::ACT_HOLD: // Intentional fall-trough
    case VisObject::ACT_MAX:
    default:
      break;
  }
}
