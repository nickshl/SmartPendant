// *****************************************************************************
// @file TestDisplay.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: DisplayDrv test on a virtual display (PC test)
//
// @section COPYRIGHT
//
//  Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// Compiled only by the PC tests (Tests/CMakeLists.txt), never in firmware
#if defined(DEVCORE_TESTS)

// Runs the real DisplayDrv (its task, update areas, rotations and update
// modes) on the StdRtosWrapper, drawing into a VirtualDisplay, and checks every
// frame against an independent picture of the same objects: the root list
// drawn line by line with DrawInBufW (or column by column with DrawInBufH),
// outside DisplayDrv. An AppTask with a timer moves an object, as an
// application does. Every frame is saved as a PNG file.
//   TestDisplay <output folder>

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "Display/DisplayDrv.h"
#include "Display/Fonts/Font_6x8.h"
#include "Display/Fonts/Font_8x12.h"
#include "VirtualDisplay.h"
#include "UiEngine/UiButton.h"
#include "UiEngine/UiCheckbox.h"
#include "UiEngine/UiScroll.h"

#include <cstdio>
#include <string>
#include <vector>
#include <atomic>
#include <filesystem>

static std::string out_dir = ".";
static int failures = 0, checks = 0;
static VirtualDisplay vd(240, 320);
static const color_t UNTOUCHED = (color_t)0x1234u;   // panel fill before a frame: shows what the frame didn't draw

// *****************************************************************************
// ***   Animator   ************************************************************
// *****************************************************************************
// An application task with a timer
class Animator : public AppTask
{
  public:
    static Animator& GetInstance() {static Animator a; return a;}
    void Attach(Circle* c) {circle = c;}
    std::atomic<int> steps_done{0};
    std::atomic<int> steps_wanted{0};
  protected:
    virtual Result TimerExpired(uint32_t missed_cnt)
    {
      (void)missed_cnt;
      if((circle != nullptr) && (steps_done < steps_wanted))
      {
        // Move the circle 3 pixels right and redraw what changed
        circle->Move(3, 0, true);
        steps_done++;
        DisplayDrv::GetInstance().UpdateDisplay();
      }
      return Result::RESULT_OK;
    }
  private:
    Circle* circle = nullptr;
    Animator() : AppTask(RTOS_MINIMAL_STACK_SIZE, RTOS_IDLE_TASK_PRIORITY + 1u, "Animator", 0u, 0u, nullptr, 20u) {}
};

// *****************************************************************************
// ***   Reference   ***********************************************************
// *****************************************************************************
// Independent picture: the root list drawn line by line with DrawInBufW, as
// DevCore's objects draw themselves
static void Reference(std::vector<color_t>& ref, int32_t w, int32_t h, color_t bg)
{
  DisplayDrv& d = DisplayDrv::GetInstance();
  ref.assign((size_t)w * h, bg);
#if defined(USE_UPDATE_TOP_BOTTOM)
  d.LockDisplayLine();
  for(int32_t y = 0; y < h; y++) d.GetVisList()->DrawInBufW(&ref[(size_t)y * w], w, y, 0);
  d.UnlockDisplayLine();
#else
  // Only Left to Right compiled: columns instead
  std::vector<color_t> col(h);
  d.LockDisplayLine();
  for(int32_t x = 0; x < w; x++) { for(auto& c : col) c = bg; d.GetVisList()->DrawInBufH(col.data(), h, x, 0); for(int32_t y = 0; y < h; y++) ref[(size_t)y * w + x] = col[y]; }
  d.UnlockDisplayLine();
#endif
}

// *****************************************************************************
// ***   Update   **************************************************************
// *****************************************************************************
// Asks DisplayDrv to draw what was invalidated, as an application does after changes, and remembers how many
// transfers the display had, so Check() can wait for this frame
static uint32_t transfers_before = 0u;
static void Update()
{
  transfers_before = vd.GetTransfers();
  DisplayDrv::GetInstance().UpdateDisplay();
}

// *****************************************************************************
// ***   Check   ***************************************************************
// *****************************************************************************
// Waits for the frame, compares it with the reference and saves it
static void Check(const char* title, IDisplay::Rotation view, const char* png)
{
  // Wait until the frame was drawn (at most 5 s), then until nothing is written any more
  uint32_t t0 = RtosTick::GetTimeMs();
  while((vd.GetTransfers() == transfers_before) && (RtosTick::GetTimeMs() - t0 < 5000u)) RtosTick::DelayMs(2u);
  vd.WaitIdle();
  DisplayDrv& d = DisplayDrv::GetInstance();
  d.LockDisplay();
  std::vector<color_t> pic, ref; int32_t w, h;
  vd.GetPicture(pic, w, h, view);
  bool size_ok = (w == d.GetScreenW()) && (h == d.GetScreenH());
  Reference(ref, w, h, COLOR_BLACK);
  d.UnlockDisplay();
  long diff = 0, untouched = 0; int fx = -1, fy = -1, x0 = w, y0 = h, x1 = -1, y1 = -1;
  for(int32_t i = 0; i < w * h; i++) if(pic[i] != ref[i])
  {
    if(diff++ == 0) { fx = i % w; fy = i / w; }
    if(pic[i] == UNTOUCHED) untouched++;
    int x = i % w, y = i / w; if(x < x0) x0 = x; if(y < y0) y0 = y; if(x > x1) x1 = x; if(y > y1) y1 = y;
  }
  if(diff && getenv("VERBOSE")) printf("     differing pixels within (%d,%d)-(%d,%d)\n", x0, y0, x1, y1);
  checks++;
  // Driver errors (window outside the panel) since the previous check
  static uint32_t errors_seen = 0u; uint32_t new_errors = vd.GetErrors() - errors_seen; errors_seen = vd.GetErrors();
  bool ok = size_ok && (diff == 0) && (new_errors == 0u);
  if(!ok) failures++;
  std::string file = out_dir + "/" + png + ".png";
  vd.Save(file, view);
  printf("%s %-78s %ldx%ld, %ld px differ (%ld not drawn), %u window errors%s  -> %s\n", ok ? "ok  " : "FAIL", title, (long)w, (long)h, diff, untouched, (unsigned)new_errors,
         (diff ? (" first at (" + std::to_string(fx) + "," + std::to_string(fy) + ")").c_str() : ""), file.c_str());
  fflush(stdout);
}

// *****************************************************************************
// ***   FullFrame   ***********************************************************
// *****************************************************************************
static void FullFrame()
{
  vd.Clear(UNTOUCHED);
  DisplayDrv::GetInstance().InvalidateDisplay();
  Update();
}

// *****************************************************************************
// ***   main   ****************************************************************
// *****************************************************************************
int main(int argc, char** argv)
{
  if(argc > 1) out_dir = argv[1];
  std::error_code ec;
  std::filesystem::create_directories(out_dir, ec);
  DisplayDrv& display = DisplayDrv::GetInstance();
  display.InitTask(vd);

  // Visual objects: static locals, created after DisplayDrv (README, rules 1 and 2)
  static Box background(0, 0, 240, 320, COLOR_VERYDARKBLUE, true);
  static Box frame(4, 4, 232, 40, COLOR_YELLOW, false); frame.SetBorderWidth(2);
  static String title("DevCore on a PC", 12, 16, COLOR_WHITE, Font_8x12::GetInstance());
  static StringAligned label("Right", StringAligned::RIGHT, 10, 52, 220, COLOR_BLACK, COLOR_LIGHTGREY, Font_6x8::GetInstance());
  static MultiLineString mls("Line one\nsecond\n3", 10, 66, COLOR_CYAN, COLOR_DARKGREY, Font_6x8::GetInstance());
  static Line diag(0, 319, 239, 100, COLOR_GREEN);
  static Triangle tri(150, 70, 230, 90, 170, 140, COLOR_MAGENTA, true);
  static Circle ball(30, 150, 12, COLOR_RED, true, false);
  static ShadowBox shadow(100, 120, 60, 40);
  static color_t pix[16 * 8];
  for(int i = 0; i < 16 * 8; i++) pix[i] = (color_t)(0x00010203u * (i * 2 + 1));
  static ImageBitmap img(20, 190, 16, 8, pix);
  static UiButton button("Press", 20, 240, 90, 30, true);
  static UiCheckbox check(130, 248, true, true);
  static UiScroll scroll(220, 120, 12, 190, 20, 4, true, true, true);
  static VisList panel; panel.SetParams(120, 180, 90, 50);
  static Box inner(-10, -10, 60, 30, COLOR_LIGHTRED, true);
  VisObject* objs[] = { &background, &frame, &title, &label, &mls, &diag, &tri, &ball, &shadow, &img, &button, &check, &scroll, &panel };
  for(unsigned i = 0; i < sizeof(objs) / sizeof(objs[0]); i++) objs[i]->Show(i + 1);
  inner.SetList(panel); inner.Show(1);

  Animator::GetInstance().Attach(&ball);
  Animator::GetInstance().InitTask();

  Rtos::StartScheduler();
  // Wait for the first frame: then every task has passed Setup()
  Update();
  { uint32_t t0 = RtosTick::GetTimeMs(); while((vd.GetTransfers() == transfers_before) && (RtosTick::GetTimeMs() - t0 < 5000u)) RtosTick::DelayMs(2u); }
  vd.WaitIdle();

#if defined(USE_UPDATE_TOP_BOTTOM) && defined(USE_UPDATE_LEFT_RIGHT)
  const DisplayDrv::UpdateMode modes[] = { DisplayDrv::UPDATE_TOP_BOTTOM, DisplayDrv::UPDATE_LEFT_RIGHT };
  const char* mode_names[] = { "top-bottom", "left-right" };
  const char* mode_files[] = { "tb", "lr" };
  const int mode_cnt = 2;
#elif defined(USE_UPDATE_LEFT_RIGHT)
  const char* mode_names[] = { "left-right only" };
  const char* mode_files[] = { "lr" };
  const int mode_cnt = 1;
#else
  const char* mode_names[] = { "top-bottom only" };
  const char* mode_files[] = { "tb" };
  const int mode_cnt = 1;
#endif
  const IDisplay::Rotation rots[] = { IDisplay::ROTATION_TOP, IDisplay::ROTATION_LEFT, IDisplay::ROTATION_BOTTOM, IDisplay::ROTATION_RIGHT };
  const char* rot_names[] = { "TOP", "LEFT", "BOTTOM", "RIGHT" };

  for(int m = 0; m < mode_cnt; m++)
  {
#if defined(USE_UPDATE_TOP_BOTTOM) && defined(USE_UPDATE_LEFT_RIGHT)
    display.SetUpdateMode(modes[m]);
#endif
    for(int r = 0; r < 4; r++)
    {
      display.SetRotation(rots[r]);
      std::string tag = std::string(mode_names[m]) + ", rotation " + rot_names[r];
      std::string file = std::string(mode_files[m]) + "_" + rot_names[r];
      // Whole screen
      FullFrame();
      Check((tag + ": full frame").c_str(), rots[r], (file + "_full").c_str());
      // Changes redrawn through update areas only (no Clear: what isn't redrawn keeps the old frame)
      label.SetString("Changed");
      title.Move(14 + r, 18, false);
      inner.Move(5 + r * 3, 2, false);
      scroll.SetScrollPos(3 + r * 4);
      check.SetChecked(r % 2);
      img.Move(20 + r * 7, 190 + r, false);
      Update();
      Check((tag + ": after changes, update areas only").c_str(), rots[r], (file + "_areas").c_str());
      // SetTotal() and SetBar() change only the bar (the position stays): they
      // must redraw it themselves
      scroll.SetTotal(20 + (r + 1) * 10);
      scroll.SetBar(4 + r);
      Update();
      Check((tag + ": after UiScroll SetTotal() and SetBar()").c_str(), rots[r], (file + "_scroll").c_str());
      label.SetString("Right");
    }
  }

  // StringAligned constructed with a background: its width and background are the ones given
  display.SetRotation(IDisplay::ROTATION_TOP);
  FullFrame();
  Check("StringAligned with background constructor: frame", IDisplay::ROTATION_TOP, "label");
  {
    checks++;
    color_t bg_px = vd.GetPixel(12, 54, IDisplay::ROTATION_TOP);
    bool ok = (label.GetWidth() == 220) && (bg_px == (color_t)COLOR_LIGHTGREY);
    if(!ok) failures++;
    printf("%s %-78s width %ld, pixel (12,54) %04X\n", ok ? "ok  " : "FAIL", "StringAligned(str, align, x, y, w, tc, bgc, font): width 220, grey background",
           (long)label.GetWidth(), (unsigned)bg_px);
  }

  // Application task: the timer moves the ball 10 times
  display.SetRotation(IDisplay::ROTATION_TOP);
#if defined(USE_UPDATE_TOP_BOTTOM) && defined(USE_UPDATE_LEFT_RIGHT)
  display.SetUpdateMode(DisplayDrv::UPDATE_LEFT_RIGHT);
#endif
  FullFrame();
  vd.WaitIdle();
  transfers_before = vd.GetTransfers();
  Animator::GetInstance().steps_wanted = 10;
  uint32_t t0 = RtosTick::GetTimeMs();
  while((Animator::GetInstance().steps_done < 10) && (RtosTick::GetTimeMs() - t0 < 3000u)) RtosTick::DelayMs(5u);
  checks++;
  bool moved = (Animator::GetInstance().steps_done == 10) && (ball.GetStartX() == 18 + 30);
  if(!moved) failures++;
  printf("%s %-78s %d steps in %u ms, ball x_start %ld\n", moved ? "ok  " : "FAIL", "AppTask timer: 10 steps of 20 ms move the ball 30 px",
         Animator::GetInstance().steps_done.load(), (unsigned)(RtosTick::GetTimeMs() - t0), (long)ball.GetStartX());
  Check("after the AppTask moved the ball (update areas)", IDisplay::ROTATION_TOP, "task_ball");

  printf("\n%d of %d checks passed\n%s\n", checks - failures, checks, failures ? "FAILED" : "ALL OK");
  fflush(stdout);
  // Tasks run forever: leave without destructors
  _Exit(failures ? 1 : 0);
}

#endif
