// *****************************************************************************
// @file TestModes.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: Update mode options test (PC test)
//
// @section COPYRIGHT
//
//  Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// Compiled only by the PC tests (Tests/CMakeLists.txt), never in firmware
#if defined(DEVCORE_TESTS)

// USE_UPDATE_TOP_BOTTOM compiles DrawInBufW of every visual object,
// USE_UPDATE_LEFT_RIGHT compiles DrawInBufH. Built three times: with both
// modes, with only Top to Bottom, with only Left to Right.
//  - At compile time: a single mode build checks that every visual object
//    class has no draw function of the other mode.
//  - At run time: one scene with every visual object class (Display and
//    UiEngine, nested lists) is drawn through the functions the build has,
//    line by line (W) or column by column (H), full size and through a window,
//    as one hash per line or column. The build with both modes writes the
//    hashes to a file ("TestModes write <file>"); a single mode build must
//    give exactly the hashes of its mode ("TestModes compare <file>").

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "Display/DisplayDrv.h"
#include "Display/Primitives.h"
#include "Display/Strng.h"
#include "Display/StringAligned.h"
#include "Display/MultiLineString.h"
#include "Display/Image.h"
#include "Display/TiledMap.h"
#include "UiEngine/UiButton.h"
#include "UiEngine/UiCheckbox.h"
#include "UiEngine/UiScroll.h"

#include <cstdio>
#include <cstring>
#include <vector>
#include <string>

// *****************************************************************************
// ***   Compile time check   **************************************************
// *****************************************************************************
template<typename T> constexpr bool HasDrawInBufW = requires(T& o, color_t* b) {o.DrawInBufW(b, 0, 0, 0);};
template<typename T> constexpr bool HasDrawInBufH = requires(T& o, color_t* b) {o.DrawInBufH(b, 0, 0, 0);};

// True if none of the classes has the function
template<typename... T> constexpr bool NoneHasW = (!HasDrawInBufW<T> && ...);
template<typename... T> constexpr bool NoneHasH = (!HasDrawInBufH<T> && ...);

#define ALL_VISUAL_OBJECTS VisObject, VisList, Box, ShadowBox, Line, Circle, Triangle, String, StringAligned, \
                           MultiLineString, Image, ImagePalette, ImageBitmap, ImageBinary, TiledMap, \
                           UiButton, UiCheckbox, UiScroll

#if !defined(USE_UPDATE_TOP_BOTTOM)
static_assert(NoneHasW<ALL_VISUAL_OBJECTS>, "DrawInBufW exists without USE_UPDATE_TOP_BOTTOM");
#endif
#if !defined(USE_UPDATE_LEFT_RIGHT)
static_assert(NoneHasH<ALL_VISUAL_OBJECTS>, "DrawInBufH exists without USE_UPDATE_LEFT_RIGHT");
#endif

// *****************************************************************************
// ***   Fnv   *****************************************************************
// *****************************************************************************
// Hash of a buffer
static uint32_t Fnv(const std::vector<color_t>& v)
{
  uint32_t h = 2166136261u;
  for(color_t c : v)
  {
    for(unsigned b = 0u; b < sizeof(color_t); b++) {h ^= (uint8_t)(c >> (8u * b)); h *= 16777619u;}
  }
  return h;
}

// *****************************************************************************
// ***   main   ****************************************************************
// *****************************************************************************
int main(int argc, char** argv)
{
  if((argc < 3) || (strcmp(argv[1], "write") && strcmp(argv[1], "compare")))
  {
    printf("Usage: TestModes write|compare <file>\n");
    return 2;
  }
  bool write = (strcmp(argv[1], "write") == 0);
#if !defined(USE_UPDATE_TOP_BOTTOM) || !defined(USE_UPDATE_LEFT_RIGHT)
  if(write) {printf("Only the build with both modes writes the file\n"); return 2;}
#endif

  // DisplayDrv first: it sets the default list for every visual object
  DisplayDrv::GetInstance();
  const int W = 200, H = 150;
  static color_t pix[12 * 6];
  static uint8_t idx[12 * 6];
  static color_t pal[256];
  static uint8_t bits[2 * 6];
  for(int i = 0; i < 72; i++) {pix[i] = (color_t)(0x00010203u * (i + 1)); idx[i] = (uint8_t)(i * 7);}
  for(int i = 0; i < 256; i++) pal[i] = (color_t)(0x00030201u * (i + 1));
  for(int i = 0; i < 12; i++) bits[i] = (uint8_t)(0xA5u ^ (i * 29));
  static uint8_t t0[12];
  for(int i = 0; i < 12; i++) t0[i] = (uint8_t)i;
  static ImageDesc tile;
  tile.width = 4; tile.height = 3; tile.bits_per_pixel = 8; tile.imgp = t0; tile.palette = pal;
  static uint8_t map[6] = {0, 1, 0, 0, 0, 1};

  // The scene
  VisList root;
  root.SetParams(0, 0, W, H);
  VisList inner;
  inner.SetParams(120, 70, 60, 50);
  Box b1(5, 5, 30, 20, 0xF81F, true);
  b1.SetBackgroundColor(0x07E0);
  b1.SetBorderWidth(2);
  Box b2(40, 5, 20, 20, 0xFFE0, false);
  b2.SetBorderWidth(3);
  ShadowBox sh(10, 10, 60, 30);
  Line l1(0, 149, 199, 0, 0xFFFF);
  Circle c1(90, 30, 17, 0x001F, true, false), c2(150, 25, 12, 0xF800, false, true);
  Triangle tr(5, 60, 70, 45, 40, 110, 0x07FF, true);
  String s1("Hello", 80, 60, 0xFFFF, 0x0010, Font_8x12::GetInstance());
  StringAligned sa("Mid", StringAligned::CENTER, 5, 115, 60, 0x0000, 0xFFFF, Font_6x8::GetInstance());
  MultiLineString ml("One\nLonger\nx", 70, 80, 0xFFE0, 0x8000, Font_6x8::GetInstance());
  ml.SetSpacing(2);
  ml.SetAlignment(MultiLineString::RIGHT);
  ImageDesc d;
  d.width = 12; d.height = 6; d.bits_per_pixel = sizeof(color_t) * 8; d.imgb = pix; d.transparent_color = (int32_t)pix[3];
  Image im(150, 50, d);
  im.SetHorizontalFlip(true);
  ImagePalette ip(170, 50, 12, 6, idx, pal);
  ImageBitmap ib(150, 58, 12, 6, pix);
  ImageBinary ibn(170, 58, 12, 6, bits);
  ibn.SetColor(0xFFFF);
  ibn.SetBackgroundColor(0x0000);
  TiledMap tm(100, 120, 30, 25, map, 3, 2, 0xFF, &tile, 1, 0x1234);
  tm.ScrollView(2, 1);
  Circle ci(10, 10, 15, 0xAAAA, true, false);
  Line li(-5, 0, 70, 49, 0x5555);
  String si("In list", -6, 30, 0xFFFF, Font_6x8::GetInstance());
  UiButton bt("OK", 70, 125, 40, 20, true);
  UiCheckbox cb(115, 128, true, true);
  UiScroll sc(190, 5, 8, 100, 10, 3, true, true, true);
  sc.SetScrollPos(4);
  VisObject* top[] = {&b1, &b2, &sh, &l1, &c1, &c2, &tr, &s1, &sa, &ml, &im, &ip, &ib, &ibn, &tm, &bt, &cb, &sc, &inner};
  for(unsigned i = 0u; i < sizeof(top) / sizeof(top[0]); i++) {top[i]->SetList(root); top[i]->Show(i + 1);}
  VisObject* kids[] = {&ci, &li, &si};
  for(unsigned i = 0u; i < 3u; i++) {kids[i]->SetList(inner); kids[i]->Show(i + 1);}

  // Hashes of every line and column the build can draw
  std::vector<std::string> out;
  char s[64];
  // Windows {start, n}: n 0 = full size
  const int win[][2] = {{0, 0}, {37, 50}};
#if defined(USE_UPDATE_TOP_BOTTOM)
  for(auto& w : win) for(int y = 0; y < H; y++)
  {
    int n = w[1] ? w[1] : W;
    std::vector<color_t> buf(n, 0x0841);
    root.DrawInBufW(buf.data(), n, y, w[0]);
    snprintf(s, sizeof(s), "W %d %d %d %08X", w[0], n, y, (unsigned)Fnv(buf));
    out.push_back(s);
  }
#endif
#if defined(USE_UPDATE_LEFT_RIGHT)
  for(auto& w : win) for(int x = 0; x < W; x++)
  {
    int n = w[1] ? w[1] : H;
    std::vector<color_t> buf(n, 0x0841);
    root.DrawInBufH(buf.data(), n, x, w[0]);
    snprintf(s, sizeof(s), "H %d %d %d %08X", w[0], n, x, (unsigned)Fnv(buf));
    out.push_back(s);
  }
#endif

  if(write)
  {
    FILE* f = fopen(argv[2], "w");
    if(f == nullptr) {printf("Can't write %s\n", argv[2]); return 1;}
    for(auto& l : out) fprintf(f, "%s\n", l.c_str());
    fclose(f);
    printf("%u lines and columns written to %s\nALL OK\n", (unsigned)out.size(), argv[2]);
    return 0;
  }

  // Compare: the lines of this build's mode from the file of the build with both
#if defined(USE_UPDATE_TOP_BOTTOM)
  const char mode = 'W';
  const char* name = "USE_UPDATE_TOP_BOTTOM";
#else
  const char mode = 'H';
  const char* name = "USE_UPDATE_LEFT_RIGHT";
#endif
  FILE* f = fopen(argv[2], "r");
  if(f == nullptr) {printf("Can't read %s (written by the build with both modes)\n", argv[2]); return 1;}
  std::vector<std::string> ref;
  char line[128];
  while(fgets(line, sizeof(line), f) != nullptr)
  {
    line[strcspn(line, "\r\n")] = '\0';
    if(line[0] == mode) ref.push_back(line);
  }
  fclose(f);
  bool ok = (ref == out) && !out.empty();
  printf("%s only: %u %s, %s the build with both modes\n", name, (unsigned)out.size(), (mode == 'W') ? "lines" : "columns",
         ok ? "identical to" : "DIFFERENT from");
  printf("%s only: no %s in any visual object class (checked at compile time)\n", name, (mode == 'W') ? "DrawInBufH" : "DrawInBufW");
  printf(ok ? "ALL OK\n" : "FAILED\n");
  return ok ? 0 : 1;
}

#endif
