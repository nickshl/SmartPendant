// *****************************************************************************
// @file VirtualDisplay.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: Display in memory for the PC tests, implementation
//
// @section COPYRIGHT
//
//  Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// Compiled only by the PC tests (Tests/CMakeLists.txt), never in firmware
#if defined(DEVCORE_TESTS)

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "VirtualDisplay.h"

#include <cstdio>
#include <cstring>
#include <thread>
#include <chrono>

// *****************************************************************************
// ***   Constructor   *********************************************************
// *****************************************************************************
VirtualDisplay::VirtualDisplay(int32_t w, int32_t h) : IDisplay(w, h, sizeof(color_t)), panel((size_t)w * h, 0)
{
}

// *****************************************************************************
// ***   Private: Size   *******************************************************
// *****************************************************************************
void VirtualDisplay::Size(Rotation r, int32_t& w, int32_t& h)
{
  bool swap = (r == ROTATION_LEFT) || (r == ROTATION_RIGHT);
  w = swap ? init_height : init_width;
  h = swap ? init_width : init_height;
}

// *****************************************************************************
// ***   Private: PanelIdx   ***************************************************
// *****************************************************************************
// Relative to ROTATION_TOP the ILI9341 table turns the picture in 90 degree
// steps: LEFT (x, y) is TOP (y, H-1-x), BOTTOM is TOP (W-1-x, H-1-y), RIGHT is
// TOP (W-1-y, x), where W x H is the TOP size.
int32_t VirtualDisplay::PanelIdx(int32_t x, int32_t y, Rotation r)
{
  int32_t w, h;
  Size(r, w, h);
  if((x < 0) || (y < 0) || (x >= w) || (y >= h)) return -1;
  const int32_t W = init_width, H = init_height;
  int32_t X = x, Y = y;
  switch(r)
  {
    case ROTATION_LEFT:   X = y;         Y = H - 1 - x; break;
    case ROTATION_BOTTOM: X = W - 1 - x; Y = H - 1 - y; break;
    case ROTATION_RIGHT:  X = W - 1 - y; Y = x;         break;
    default: break;
  }
  return Y * W + X;
}

// *****************************************************************************
// ***   Public: SetRotation   *************************************************
// *****************************************************************************
Result VirtualDisplay::SetRotation(Rotation r)
{
  std::lock_guard<std::recursive_mutex> lock(mutex);
  rotation = r;
  Size(r, width, height);
  return Result::RESULT_OK;
}

// *****************************************************************************
// ***   Public: SetAddrWindow   ***********************************************
// *****************************************************************************
Result VirtualDisplay::SetAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)
{
  std::lock_guard<std::recursive_mutex> lock(mutex);
  // A window outside the panel is a driver error worth knowing about
  if((x1 < x0) || (y1 < y0) || (x1 >= width) || (y1 >= height))
  {
    errors++;
    fprintf(stderr, "VirtualDisplay: window (%u,%u)-(%u,%u) outside %ldx%ld (rotation %d)\n",
            x0, y0, x1, y1, (long)width, (long)height, (int)rotation);
  }
  wx0 = x0; wy0 = y0; wx1 = x1; wy1 = y1; cx = x0; cy = y0;
  return Result::RESULT_OK;
}

// *****************************************************************************
// ***   Private: Put   ********************************************************
// *****************************************************************************
void VirtualDisplay::Put(color_t c)
{
  int32_t idx = PanelIdx(cx, cy, rotation);
  if(idx >= 0) panel[idx] = c;
  // Column first, then the next line of the window, wrapping as a controller does
  if(++cx > wx1)
  {
    cx = wx0;
    if(++cy > wy1) cy = wy0;
  }
  pixels_written++;
}

// *****************************************************************************
// ***   Public: WriteDataStream   *********************************************
// *****************************************************************************
Result VirtualDisplay::WriteDataStream(uint8_t* data, uint32_t n)
{
  std::lock_guard<std::recursive_mutex> lock(mutex);
  for(uint32_t i = 0u; i + sizeof(color_t) <= n; i += sizeof(color_t))
  {
    color_t c;
    memcpy(&c, data + i, sizeof(color_t));
    Put(c);
  }
  last_write_ms = (uint32_t)RtosTick::GetTimeMs();
  return Result::RESULT_OK;
}

// *****************************************************************************
// ***   Public: StopTransfer   ************************************************
// *****************************************************************************
Result VirtualDisplay::StopTransfer(void)
{
  transfers++;
  return Result::RESULT_OK;
}

// *****************************************************************************
// ***   Public: PushColor   ***************************************************
// *****************************************************************************
Result VirtualDisplay::PushColor(color_t color)
{
  std::lock_guard<std::recursive_mutex> lock(mutex);
  Put(color);
  last_write_ms = (uint32_t)RtosTick::GetTimeMs();
  return Result::RESULT_OK;
}

// *****************************************************************************
// ***   Public: DrawPixel   ***************************************************
// *****************************************************************************
Result VirtualDisplay::DrawPixel(int16_t x, int16_t y, color_t color)
{
  std::lock_guard<std::recursive_mutex> lock(mutex);
  int32_t idx = PanelIdx(x, y, rotation);
  if(idx >= 0) panel[idx] = color;
  return Result::RESULT_OK;
}

// *****************************************************************************
// ***   Public: FillRect   ****************************************************
// *****************************************************************************
Result VirtualDisplay::FillRect(int16_t x, int16_t y, int16_t w, int16_t h, color_t color)
{
  std::lock_guard<std::recursive_mutex> lock(mutex);
  for(int32_t j = y; j < y + h; j++)
  {
    for(int32_t i = x; i < x + w; i++)
    {
      int32_t idx = PanelIdx(i, j, rotation);
      if(idx >= 0) panel[idx] = color;
    }
  }
  return Result::RESULT_OK;
}

// *****************************************************************************
// ***   Public: Clear   *******************************************************
// *****************************************************************************
void VirtualDisplay::Clear(color_t c)
{
  std::lock_guard<std::recursive_mutex> lock(mutex);
  for(auto& p : panel) p = c;
}

// *****************************************************************************
// ***   Public: GetPixel   ****************************************************
// *****************************************************************************
color_t VirtualDisplay::GetPixel(int32_t x, int32_t y, Rotation view)
{
  std::lock_guard<std::recursive_mutex> lock(mutex);
  int32_t idx = PanelIdx(x, y, view);
  return (idx >= 0) ? panel[idx] : 0;
}

// *****************************************************************************
// ***   Public: GetPicture   **************************************************
// *****************************************************************************
void VirtualDisplay::GetPicture(std::vector<color_t>& pic, int32_t& w, int32_t& h, Rotation view)
{
  std::lock_guard<std::recursive_mutex> lock(mutex);
  Size(view, w, h);
  pic.resize((size_t)w * h);
  for(int32_t y = 0; y < h; y++)
  {
    for(int32_t x = 0; x < w; x++) pic[(size_t)y * w + x] = panel[PanelIdx(x, y, view)];
  }
}

// *****************************************************************************
// ***   Public: WaitIdle   ****************************************************
// *****************************************************************************
void VirtualDisplay::WaitIdle(uint32_t quiet_ms, uint32_t timeout_ms)
{
  uint32_t start = RtosTick::GetTimeMs();
  while(RtosTick::GetTimeMs() - start < timeout_ms)
  {
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    uint32_t now = RtosTick::GetTimeMs();
    if((now - start >= quiet_ms) && (now - last_write_ms.load() >= quiet_ms)) break;
  }
}

// *****************************************************************************
// ***   Public: ToRgb   *******************************************************
// *****************************************************************************
void VirtualDisplay::ToRgb(color_t c, uint8_t& r, uint8_t& g, uint8_t& b)
{
#if defined(COLOR_24BIT)
  // 0x00BBGGRR
  r = c & 0xFF; g = (c >> 8) & 0xFF; b = (c >> 16) & 0xFF;
#elif defined(COLOR_16BIT)
  // RGB565 with the two bytes swapped
  uint16_t p = (uint16_t)(((c & 0xFF) << 8) | ((c >> 8) & 0xFF));
  uint8_t r5 = p >> 11, g6 = (p >> 5) & 0x3F, b5 = p & 0x1F;
  r = (r5 << 3) | (r5 >> 2); g = (g6 << 2) | (g6 >> 4); b = (b5 << 3) | (b5 >> 2);
#else
  // 3-bit color: bit 2 red, bit 1 green, bit 0 blue
  r = (c & 4) ? 255 : 0; g = (c & 2) ? 255 : 0; b = (c & 1) ? 255 : 0;
#endif
}

// *****************************************************************************
// ***   PNG writer: no compression, no library   ******************************
// *****************************************************************************
static uint32_t PngCrc32(const uint8_t* p, size_t n)
{
  static uint32_t table[256];
  static bool init = false;
  if(!init)
  {
    for(uint32_t i = 0u; i < 256u; i++)
    {
      uint32_t c = i;
      for(int k = 0; k < 8; k++) c = (c & 1u) ? 0xEDB88320u ^ (c >> 1) : c >> 1;
      table[i] = c;
    }
    init = true;
  }
  uint32_t crc = 0xFFFFFFFFu;
  for(size_t i = 0u; i < n; i++) crc = table[(crc ^ p[i]) & 0xFFu] ^ (crc >> 8);
  return ~crc;
}

static void PngBe32(std::vector<uint8_t>& v, uint32_t x)
{
  v.push_back((uint8_t)(x >> 24)); v.push_back((uint8_t)(x >> 16)); v.push_back((uint8_t)(x >> 8)); v.push_back((uint8_t)x);
}

static void PngChunk(std::vector<uint8_t>& out, const char* type, const std::vector<uint8_t>& data)
{
  PngBe32(out, (uint32_t)data.size());
  std::vector<uint8_t> td(type, type + 4);
  td.insert(td.end(), data.begin(), data.end());
  out.insert(out.end(), td.begin(), td.end());
  PngBe32(out, PngCrc32(td.data(), td.size()));
}

// *****************************************************************************
// ***   Public: Save   ********************************************************
// *****************************************************************************
bool VirtualDisplay::Save(const std::string& file, Rotation view)
{
  std::vector<color_t> pic;
  int32_t w, h;
  GetPicture(pic, w, h, view);
  // Raw image: RGB, 8 bits per component, each line starts with filter type 0
  std::vector<uint8_t> raw;
  for(int32_t y = 0; y < h; y++)
  {
    raw.push_back(0u);
    for(int32_t x = 0; x < w; x++)
    {
      uint8_t r, g, b;
      ToRgb(pic[(size_t)y * w + x], r, g, b);
      if(inverted) {r = ~r; g = ~g; b = ~b;}
      raw.push_back(r); raw.push_back(g); raw.push_back(b);
    }
  }
  // zlib stream of stored blocks
  std::vector<uint8_t> z = {0x78, 0x01};
  for(size_t pos = 0u; pos < raw.size(); )
  {
    size_t len = raw.size() - pos;
    if(len > 65535u) len = 65535u;
    bool last = (pos + len == raw.size());
    z.push_back(last ? 1u : 0u);
    z.push_back((uint8_t)(len & 0xFFu)); z.push_back((uint8_t)(len >> 8));
    z.push_back((uint8_t)(~len & 0xFFu)); z.push_back((uint8_t)((~len >> 8) & 0xFFu));
    z.insert(z.end(), raw.begin() + pos, raw.begin() + pos + len);
    pos += len;
  }
  uint32_t a = 1u, b = 0u;
  for(uint8_t c : raw) {a = (a + c) % 65521u; b = (b + a) % 65521u;}
  PngBe32(z, (b << 16) | a);
  // File: signature, header, data, end
  std::vector<uint8_t> out = {0x89, 'P', 'N', 'G', '\r', '\n', 0x1A, '\n'};
  std::vector<uint8_t> ihdr;
  PngBe32(ihdr, (uint32_t)w); PngBe32(ihdr, (uint32_t)h);
  ihdr.push_back(8u); ihdr.push_back(2u); ihdr.push_back(0u); ihdr.push_back(0u); ihdr.push_back(0u);
  PngChunk(out, "IHDR", ihdr);
  PngChunk(out, "IDAT", z);
  PngChunk(out, "IEND", {});
  FILE* f = fopen(file.c_str(), "wb");
  if(f == nullptr) return false;
  bool ok = (fwrite(out.data(), 1u, out.size(), f) == out.size());
  fclose(f);
  return ok;
}

#endif
