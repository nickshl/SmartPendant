// *****************************************************************************
// @file TestDraw.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: Drawing test of every visual object (PC test)
//
// @section COPYRIGHT
//
//  Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// Compiled only by the PC tests (Tests/CMakeLists.txt), never in firmware
#if defined(DEVCORE_TESTS)

// Checks how every visual object draws itself, without DisplayDrv's task:
//  - Line, Triangle and VisList clipping against references written here;
//    a filled Circle against its own outline;
//  - every object (Display and UiEngine): the picture DrawInBufW draws line
//    by line, then DrawInBufW through windows (update areas, list edges) and
//    DrawInBufH, full height and through windows, must give the same rows and
//    columns, without writing outside the buffer. Where the picture is simple
//    enough, it is also compared with a reference written here.
// Needs both update modes. Run without parameters for all parts, or with the
// name of one part. VERBOSE=1 in the environment prints details of mismatches.

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "Display/DisplayDrv.h"
#include "Display/Primitives.h"
#include "Display/Strng.h"
#include "Display/StringAligned.h"
#include "Display/MultiLineString.h"
#include "Display/Image.h"
#include "Display/TiledMap.h"
#include "Display/VisList.h"
#include "UiEngine/UiButton.h"
#include "UiEngine/UiCheckbox.h"
#include "UiEngine/UiScroll.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <set>
#include <string>
#include <algorithm>
#include <functional>

#if !defined(USE_UPDATE_TOP_BOTTOM) || !defined(USE_UPDATE_LEFT_RIGHT)
  #error "TestDraw needs both update modes"
#endif

// *****************************************************************************
// ***   Test data   ***********************************************************
// *****************************************************************************
// Background, foreground and second colors
static const color_t BG = (color_t)0x00111111u, FG = (color_t)0x00FFFFFFu, BK = (color_t)0x000000FFu;
static const color_t C1 = (color_t)0x00FFFFFFu, C2 = (color_t)0x00A05030u, C3 = (color_t)0x0030C0F0u;
// Guard cells on both sides of every buffer: must stay untouched
static const int GUARD = 40;

// *****************************************************************************
// ***   Rnd   *****************************************************************
// *****************************************************************************
static int Rnd(int a, int b)
{
  return a + rand() % (b - a + 1);
}

// *****************************************************************************
// ***   Draw   ****************************************************************
// *****************************************************************************
// Draws one line of an object into a guarded buffer filled with BG. Returns
// false if anything was written outside [0, n).
static bool Draw(VisObject& o, std::vector<color_t>& out, int n, int line, int start_x)
{
  std::vector<color_t> buf(n + 2 * GUARD, BG);
  o.DrawInBufW(buf.data() + GUARD, n, line, start_x);
  bool ok = true;
  for(int i = 0; i < GUARD; i++) if((buf[i] != BG) || (buf[GUARD + n + i] != BG)) ok = false;
  out.assign(buf.begin() + GUARD, buf.begin() + GUARD + n);
  return ok;
}

// *****************************************************************************
// ***   RefLine   *************************************************************
// *****************************************************************************
// Reference Bresenham line, end points included
static void RefLine(int x0, int y0, int x1, int y1, std::set<std::pair<int, int>>& px)
{
  int dx = abs(x1 - x0), dy = abs(y1 - y0), sx = (x0 < x1) ? 1 : -1, sy = (y0 < y1) ? 1 : -1, err = dx - dy;
  for(;;)
  {
    px.insert({x0, y0});
    if((x0 == x1) && (y0 == y1)) break;
    int e2 = 2 * err;
    if(e2 > -dy) {err -= dy; x0 += sx;}
    if(e2 <  dx) {err += dx; y0 += sy;}
  }
}

// *****************************************************************************
// ***   TestLine   ************************************************************
// *****************************************************************************
// Every line in a 14 x 14 square, through five windows, against the reference
static int TestLine()
{
  const int S = 14;
  long lines = 0, bad = 0, guard = 0;
  int shown = 0;
  static Line l(0, 0, 0, 0, FG);
  // Windows {start_x, n}: full view, shifted, narrow (as in a list or an update area)
  const int win[][2] = {{0, S}, {3, S}, {5, 4}, {-6, S + 6}, {S - 1, 1}};
  for(int x0 = 0; x0 < S; x0++) for(int y0 = 0; y0 < S; y0++) for(int x1 = 0; x1 < S; x1++) for(int y1 = 0; y1 < S; y1++)
  {
    l.SetParams(x0, y0, x1, y1, FG);
    lines++;
    std::set<std::pair<int, int>> ref;
    RefLine(x0, y0, x1, y1, ref);
    bool line_bad = false;
    for(auto& w : win)
    {
      for(int y = -1; y <= S; y++)
      {
        std::vector<color_t> row;
        if(!Draw(l, row, w[1], y, w[0])) {guard++; line_bad = true;}
        for(int i = 0; i < w[1]; i++) if((row[i] == FG) != (ref.count({w[0] + i, y}) != 0)) line_bad = true;
      }
    }
    if(line_bad) {bad++; if(shown++ < 3) printf("   mismatch: Line (%d,%d)-(%d,%d)\n", x0, y0, x1, y1);}
  }
  printf("Line          %6ld lines x 5 windows vs reference: %ld wrong, %ld out-of-buffer writes\n", lines, bad, guard);
  return (bad || guard);
}

// *****************************************************************************
// ***   TestTriangle   ********************************************************
// *****************************************************************************
// Reference: the three sides as complete lines 1-2, 1-3, 2-3 (each from its
// first vertex, end points included). Outline is those pixels. Filled is, on
// every row, everything from the leftmost to the rightmost of them.
static int TestTriangle()
{
  long tris = 0, bad = 0, guard = 0;
  int shown = 0;
  static Triangle t;
  srand(4321);
  const int special[][6] = {{10, 10, 40, 10, 25, 30}, {10, 30, 40, 30, 25, 10}, {10, 10, 10, 40, 40, 25}, {10, 10, 50, 12, 30, 14},
                            {10, 10, 30, 30, 50, 50}, {20, 20, 20, 20, 40, 40}, {25, 25, 25, 25, 25, 25}, {10, 10, 60, 10, 35, 11},
                            {10, 5, 60, 5, 35, 40}, {-20, 10, 30, 5, 10, 45}, {40, -15, 80, 20, 50, 30}, {30, 20, 90, 25, 60, 70}};
  const int NS = sizeof(special) / sizeof(special[0]);
  // Windows {start_x, n}: whole screen, area inside a big triangle, shifted view, one column
  const int win[][2] = {{0, 64}, {30, 10}, {17, 30}, {-8, 40}, {35, 1}};
  for(int k = 0; k < NS + 600; k++) for(int f = 0; f < 2; f++)
  {
    int v[6];
    for(int i = 0; i < 6; i++) v[i] = (k < NS) ? special[k][i] : Rnd(-6, 66);
    t.SetParams(v[0], v[1], v[2], v[3], v[4], v[5], FG, f);
    tris++;
    std::set<std::pair<int, int>> px;
    RefLine(v[0], v[1], v[2], v[3], px); RefLine(v[0], v[1], v[4], v[5], px); RefLine(v[2], v[3], v[4], v[5], px);
    bool tri_bad = false;
    for(auto& w : win)
    {
      for(int y = -8; y < 72; y++)
      {
        std::vector<color_t> row;
        if(!Draw(t, row, w[1], y, w[0])) {guard++; tri_bad = true;}
        int lo = 1 << 30, hi = -(1 << 30);
        for(auto& q : px) if(q.second == y) {lo = std::min(lo, q.first); hi = std::max(hi, q.first);}
        for(int i = 0; i < w[1]; i++)
        {
          int sx = w[0] + i;
          bool exp = f ? ((sx >= lo) && (sx <= hi)) : (px.count({sx, y}) != 0);
          if((row[i] == FG) != exp) tri_bad = true;
        }
      }
    }
    if(tri_bad) {bad++; if(shown++ < 3) printf("   mismatch: (%d,%d)-(%d,%d)-(%d,%d) %s\n", v[0], v[1], v[2], v[3], v[4], v[5], f ? "filled" : "outline");}
  }
  printf("Triangle      %6ld triangles (filled and outline) x 5 windows vs reference: %ld wrong, %ld out-of-buffer writes\n", tris, bad, guard);
  return (bad || guard);
}

// *****************************************************************************
// ***   TestCircle   **********************************************************
// *****************************************************************************
// A filled circle is its outline plus what is inside: on every row it runs from
// the leftmost to the rightmost outline dot, for every radius, odd and even.
// Radius 0 is one dot in the center, whatever the flags.
static int TestCircle()
{
  long cases = 0, bad = 0;
  int shown = 0;
  Circle c;
  const int W = 40, CX = 20, CY = 20;
  for(int r = 0; r <= 15; r++) for(int even = 0; even < 2; even++)
  {
    std::vector<std::vector<color_t>> pic[2];
    for(int f = 0; f < 2; f++)
    {
      c.SetParams(CX, CY, r, FG, f, even);
      for(int y = 0; y < W; y++) {std::vector<color_t> row; Draw(c, row, W, y, 0); pic[f].push_back(row);}
    }
    bool case_bad = false;
    cases++;
    for(int y = 0; y < W; y++)
    {
      int lo = W, hi = -1;
      for(int x = 0; x < W; x++) if(pic[0][y][x] == FG) {lo = std::min(lo, x); hi = std::max(hi, x);}
      for(int x = 0; x < W; x++) if((pic[1][y][x] == FG) != ((x >= lo) && (x <= hi))) case_bad = true;
      if(r == 0) for(int x = 0; x < W; x++) if((pic[0][y][x] == FG) != ((x == CX) && (y == CY))) case_bad = true;
    }
    if(case_bad) {bad++; if(shown++ < 4) printf("   mismatch: r = %d, %s\n", r, even ? "even" : "odd");}
  }
  printf("Circle        %6ld circles (r 0..15, odd and even): %ld where the filled one is not the outline plus its inside\n", cases, bad);
  return (bad != 0);
}

// *****************************************************************************
// ***   TestVisList   *********************************************************
// *****************************************************************************
// Random lists, some partly off the screen, some nested in a second list. The
// children must appear exactly as drawn alone, and only inside the list.
static int TestVisList()
{
  const int W = 96, H = 40;
  long scenes = 0, bad = 0, guard = 0, px_out = 0;
  int shown = 0;
  srand(12345);
  for(int sc = 0; sc < 400; sc++)
  {
    int lx = Rnd(-10, 60), ly = Rnd(-5, 20), lw = Rnd(1, 50), lh = Rnd(1, 30);
    bool nested = (sc % 3 == 0);
    int ox = nested ? Rnd(-8, 30) : 0, oy = nested ? Rnd(-4, 10) : 0, ow = Rnd(5, 70), oh = Rnd(5, 35);
    VisList outer, list;
    outer.SetParams(ox, oy, ow, oh);
    list.SetParams(lx, ly, lw, lh);
    // Children placed so that many cross the list borders
    Circle b1, b2;
    Line l1, l2;
    String s1;
    {int r = Rnd(1, 9); b1.SetParams(Rnd(-8, lw + 4), Rnd(-6, lh + 4), r, (color_t)0x00AA0000u, true, false);}
    {int r = Rnd(1, 9); b2.SetParams(Rnd(-8, lw + 4), Rnd(-6, lh + 4), r, (color_t)0x0000AA00u, true, (Rnd(0, 1) == 1) && (r > 1));}
    l1.SetParams(Rnd(-10, lw + 10), Rnd(-5, lh + 5), Rnd(-10, lw + 10), Rnd(-5, lh + 5), (color_t)0x000000AAu);
    l2.SetParams(Rnd(-10, lw + 10), Rnd(-5, lh + 5), Rnd(-10, lw + 10), Rnd(-5, lh + 5), (color_t)0x0000AAAAu);
    s1.SetParams("Clip me", Rnd(-20, lw), Rnd(-6, lh), (color_t)0x00FFFF00u, (color_t)0x00550055u, Font_6x8::GetInstance());
    VisObject* kids[] = {&b1, &b2, &l1, &l2, &s1};
    for(int i = 0; i < 5; i++) {kids[i]->SetList(list); kids[i]->Show(i + 1);}
    if(nested) {list.SetList(outer); list.Show(1);}
    VisObject& top = nested ? (VisObject&)outer : (VisObject&)list;
    // Screen rectangle the children may appear in
    int ax0 = lx + ox, ay0 = ly + oy, ax1 = ax0 + lw - 1, ay1 = ay0 + lh - 1;
    if(nested) {ax0 = std::max(ax0, ox); ay0 = std::max(ay0, oy); ax1 = std::min(ax1, ox + ow - 1); ay1 = std::min(ay1, oy + oh - 1);}
    // Windows {start_x, n}: full screen and an update area
    const int win[][2] = {{0, W}, {17, 30}};
    bool scene_bad = false;
    scenes++;
    for(auto& w : win)
    {
      for(int y = 0; y < H; y++)
      {
        std::vector<color_t> row;
        if(!Draw(top, row, w[1], y, w[0])) {guard++; scene_bad = true;}
        // Reference: children drawn alone in list coordinates, shifted by 64 so nothing meets index 0
        std::vector<color_t> ref(400, BG);
        for(auto k : kids) k->DrawInBufW(ref.data(), 400, y - (ly + oy), -64);
        for(int i = 0; i < w[1]; i++)
        {
          int sx = w[0] + i;
          bool inside = (sx >= ax0) && (sx <= ax1) && (y >= ay0) && (y <= ay1);
          color_t exp = inside ? ref[sx - (lx + ox) + 64] : BG;
          if(row[i] != exp)
          {
            scene_bad = true;
            if(!inside) px_out++;
            if(getenv("VERBOSE")) printf("      scene %d window (%d,%d) screen (%d,%d): expected %06X got %06X\n", sc, w[0], w[1], sx, y, (unsigned)exp, (unsigned)row[i]);
          }
        }
      }
    }
    if(scene_bad) {bad++; if(shown++ < 3) printf("   mismatch: scene %d list (%d,%d %dx%d)%s\n", sc, lx, ly, lw, lh, nested ? " nested" : "");}
    for(auto k : kids) k->Hide();
    if(nested) list.Hide();
  }
  printf("VisList       %6ld random scenes x 2 windows vs reference: %ld wrong (%ld pixels outside the list), %ld out-of-buffer writes\n", scenes, bad, px_out, guard);
  return (bad || guard);
}

// *****************************************************************************
// ***   DrawInBufH against DrawInBufW   ***************************************
// *****************************************************************************
// Every object is drawn line by line with DrawInBufW into a picture, on a
// background where every pixel has its own color, so transparency, shadow and
// "nothing drawn" all show. Then DrawInBufW through windows (start, 1 / 2 / 5 /
// 48 cells) must give the same lines as the picture, and DrawInBufH, full
// height and through windows, the same columns. Guard cells on both sides of
// every buffer must stay untouched.

// *****************************************************************************
// ***   Pat   *****************************************************************
// *****************************************************************************
// Background color of screen pixel (x, y)
static color_t Pat(int x, int y)
{
  uint32_t v = (uint32_t)(x * 73 + y * 151 + 1000003) * 2654435761u;
#if defined(COLOR_24BIT)
  return (color_t)((v >> 8) & 0x00FFFFFFu);
#else
  return (color_t)(v >> 16);
#endif
}

// *****************************************************************************
// ***   DrawWp   **************************************************************
// *****************************************************************************
// Screen line through DrawInBufW on the Pat() background
static bool DrawWp(VisObject& o, std::vector<color_t>& out, int n, int line, int start_x)
{
  std::vector<color_t> buf(n + 2 * GUARD);
  for(int i = 0; i < n + 2 * GUARD; i++) buf[i] = Pat(start_x - GUARD + i, line);
  o.DrawInBufW(buf.data() + GUARD, n, line, start_x);
  bool ok = true;
  for(int i = 0; i < GUARD; i++) if((buf[i] != Pat(start_x - GUARD + i, line)) || (buf[GUARD + n + i] != Pat(start_x + n + i, line))) ok = false;
  out.assign(buf.begin() + GUARD, buf.begin() + GUARD + n);
  return ok;
}

// *****************************************************************************
// ***   DrawHp   **************************************************************
// *****************************************************************************
// Screen column through DrawInBufH on the Pat() background
static bool DrawHp(VisObject& o, std::vector<color_t>& out, int n, int column, int start_y)
{
  std::vector<color_t> buf(n + 2 * GUARD);
  for(int i = 0; i < n + 2 * GUARD; i++) buf[i] = Pat(column, start_y - GUARD + i);
  o.DrawInBufH(buf.data() + GUARD, n, column, start_y);
  bool ok = true;
  for(int i = 0; i < GUARD; i++) if((buf[i] != Pat(column, start_y - GUARD + i)) || (buf[GUARD + n + i] != Pat(column, start_y + n + i))) ok = false;
  out.assign(buf.begin() + GUARD, buf.begin() + GUARD + n);
  return ok;
}

// *****************************************************************************
// ***   Picture   *************************************************************
// *****************************************************************************
// Picture of the region [x0..x1] x [y0..y1], drawn by DrawInBufW with 64 cells
// of room on both sides
struct Pic
{
  int x0, y0, x1, y1, w;
  std::vector<color_t> px;
  bool guard_ok = true;
  color_t At(int x, int y) const {return ((x < x0) || (x > x1) || (y < y0) || (y > y1)) ? Pat(x, y) : px[(y - y0) * w + (x - x0)];}
};

static Pic Picture(VisObject& o, int x0, int y0, int x1, int y1)
{
  Pic p;
  p.x0 = x0; p.y0 = y0; p.x1 = x1; p.y1 = y1; p.w = x1 - x0 + 1;
  for(int y = y0; y <= y1; y++)
  {
    std::vector<color_t> row;
    if(!DrawWp(o, row, p.w + 128, y, x0 - 64)) p.guard_ok = false;
    // Nothing may be drawn outside the region
    for(int i = 0; i < 64; i++) if((row[i] != Pat(x0 - 64 + i, y)) || (row[64 + p.w + i] != Pat(x1 + 1 + i, y))) p.guard_ok = false;
    p.px.insert(p.px.end(), row.begin() + 64, row.begin() + 64 + p.w);
  }
  return p;
}

// *****************************************************************************
// ***   Starts   **************************************************************
// *****************************************************************************
// Window starts for a range: all of them for a short range, else both ends and
// a few in the middle
static std::vector<int> Starts(int lo, int hi)
{
  std::vector<int> s;
  if(hi - lo <= 40)
  {
    for(int i = lo - 6; i <= hi + 3; i++) s.push_back(i);
    return s;
  }
  for(int i = lo - 6; i <= lo + 6; i++) s.push_back(i);
  for(int k = 1; k < 10; k++) s.push_back(lo + (hi - lo) * k / 10);
  for(int i = hi - 6; i <= hi + 3; i++) s.push_back(i);
  return s;
}

// *****************************************************************************
// ***   HvCheck   *************************************************************
// *****************************************************************************
// Statistics of one part
struct HV
{
  long objs = 0, wrows = 0, hcols = 0, wbad = 0, hbad = 0, guard = 0, refbad = 0, objbad = 0;
  std::string first;
};

// Compares windows of DrawInBufW and DrawInBufH with the picture of the region
// [x0..x1] x [y0..y1] (plus a margin); ref, if given, is a reference picture
static void HvCheck(VisObject& o, const char* what, int x0, int y0, int x1, int y1, HV& st, std::function<color_t(int, int)> ref = nullptr)
{
  const int M = 3;
  x0 -= M; y0 -= M; x1 += M; y1 += M;
  Pic p = Picture(o, x0, y0, x1, y1);
  bool bad = !p.guard_ok;
  if(!p.guard_ok) st.guard++;
  st.objs++;
  if(ref)
  {
    for(int y = y0; y <= y1; y++) for(int x = x0; x <= x1; x++) if(p.At(x, y) != ref(x, y))
    {
      if(!bad && getenv("VERBOSE")) printf("      %s: reference differs at (%d,%d): %08X vs %08X\n", what, x, y, (unsigned)p.At(x, y), (unsigned)ref(x, y));
      st.refbad++; bad = true; y = y1; break;
    }
  }
  const int sizes[] = {1, 2, 5, 48};
  std::vector<int> sx = Starts(x0, x1), sy = Starts(y0, y1);
  std::vector<color_t> b;
  for(int y = y0; y <= y1; y++) for(int s : sx) for(int n : sizes)
  {
    st.wrows++;
    if(!DrawWp(o, b, n, y, s)) {st.guard++; bad = true;}
    for(int i = 0; i < n; i++) if(b[i] != p.At(s + i, y)) {st.wbad++; bad = true; break;}
  }
  for(int x = x0; x <= x1; x++)
  {
    st.hcols++;
    if(!DrawHp(o, b, y1 - y0 + 1, x, y0)) {st.guard++; bad = true;}
    for(int i = 0; i <= y1 - y0; i++) if(b[i] != p.At(x, y0 + i))
    {
      if(!bad && getenv("VERBOSE")) printf("      %s: column %d y %d: H %08X, W %08X\n", what, x, y0 + i, (unsigned)b[i], (unsigned)p.At(x, y0 + i));
      st.hbad++; bad = true; break;
    }
    for(int s : sy) for(int n : sizes)
    {
      st.hcols++;
      if(!DrawHp(o, b, n, x, s)) {st.guard++; bad = true;}
      for(int i = 0; i < n; i++) if(b[i] != p.At(x, s + i)) {st.hbad++; bad = true; break;}
    }
  }
  if(bad) {st.objbad++; if(st.first.empty()) st.first = what;}
}

// *****************************************************************************
// ***   HvReport   ************************************************************
// *****************************************************************************
static int HvReport(const char* name, const HV& st, bool has_ref)
{
  std::string ref = has_ref ? ("vs reference " + std::to_string(st.refbad) + " wrong | ") : "";
  printf("%-15s %5ld objects: W windows %7ld rows %ld wrong | H %8ld columns %ld wrong | %s%ld out-of-buffer\n",
         name, st.objs, st.wrows, st.wbad, st.hcols, st.hbad, ref.c_str(), st.guard);
  if(st.objbad) printf("   first mismatch: %s (VERBOSE=1 for details)\n", st.first.c_str());
  return (st.objbad != 0);
}

// *****************************************************************************
// ***   HvBox   ***************************************************************
// *****************************************************************************
static int HvBox()
{
  HV st;
  Box b;
  char what[120];
  for(int w : {1, 2, 3, 5, 9}) for(int h : {1, 2, 3, 6}) for(int fill = 0; fill < 2; fill++) for(int bw = 0; bw <= 6; bw++)
  {
    b.SetParams(10, 5, w, h, C1, fill);
    b.SetBorderWidth(bw);
    b.SetBackgroundColor(C2);
    snprintf(what, sizeof(what), "Box %dx%d fill %d border %d", w, h, fill, bw);
    // A pixel is border when it is within border_width of any edge of the box
    HvCheck(b, what, 10, 5, 10 + w - 1, 5 + h - 1, st, [&](int x, int y) -> color_t {
      if((x < 10) || (x > 10 + w - 1) || (y < 5) || (y > 5 + h - 1)) return Pat(x, y);
      int d = std::min(std::min(x - 10, 10 + w - 1 - x), std::min(y - 5, 5 + h - 1 - y));
      if(d < bw) return C1;
      return fill ? C2 : Pat(x, y);});
  }
  return HvReport("Box", st, true);
}

// *****************************************************************************
// ***   HvShadow   ************************************************************
// *****************************************************************************
// ShadowBox halves R, G and B of every pixel under it
static color_t ShadowRef(color_t c)
{
#if defined(COLOR_24BIT)
  return (color_t)((((c >> 16) & 0xFFu) / 2u) << 16 | (((c >> 8) & 0xFFu) / 2u) << 8 | ((c & 0xFFu) / 2u) | (c & 0xFF000000u));
#else
  // RGB565 with the two bytes swapped
  uint16_t v = (uint16_t)((c >> 8) | (c << 8));
  int r = (v >> 11) & 31, g = (v >> 5) & 63, bl = v & 31;
  v = (uint16_t)(((r / 2) << 11) | ((g / 2) << 5) | (bl / 2));
  return (color_t)((v >> 8) | (v << 8));
#endif
}

static int HvShadow()
{
  HV st;
  ShadowBox sb;
  char what[80];
  for(int w : {1, 2, 6, 13}) for(int h : {1, 3, 8})
  {
    sb.SetParams(10, 5, w, h);
    snprintf(what, sizeof(what), "ShadowBox %dx%d", w, h);
    HvCheck(sb, what, 10, 5, 10 + w - 1, 5 + h - 1, st, [&](int x, int y) {
      return ((x >= 10) && (x < 10 + w) && (y >= 5) && (y < 5 + h)) ? ShadowRef(Pat(x, y)) : Pat(x, y);});
  }
  return HvReport("ShadowBox", st, true);
}

// *****************************************************************************
// ***   HvLine   **************************************************************
// *****************************************************************************
static int HvLine()
{
  HV st;
  Line l;
  char what[80];
  const int S = 9;
  for(int x0 = 0; x0 < S; x0++) for(int y0 = 0; y0 < S; y0++) for(int x1 = 0; x1 < S; x1++) for(int y1 = 0; y1 < S; y1 += 2)
  {
    l.SetParams(x0, y0, x1, y1, C1);
    snprintf(what, sizeof(what), "Line (%d,%d)-(%d,%d)", x0, y0, x1, y1);
    HvCheck(l, what, std::min(x0, x1), std::min(y0, y1), std::max(x0, x1), std::max(y0, y1), st);
  }
  srand(777);
  for(int k = 0; k < 300; k++)
  {
    int a = Rnd(-20, 120), b = Rnd(-20, 90), c = Rnd(-20, 120), d = Rnd(-20, 90);
    l.SetParams(a, b, c, d, C1);
    snprintf(what, sizeof(what), "Line (%d,%d)-(%d,%d)", a, b, c, d);
    HvCheck(l, what, std::min(a, c), std::min(b, d), std::max(a, c), std::max(b, d), st);
  }
  return HvReport("Line", st, false);
}

// *****************************************************************************
// ***   HvCircle   ************************************************************
// *****************************************************************************
static int HvCircle()
{
  HV st;
  Circle c;
  char what[80];
  for(int r = 0; r <= 150; r += (r < 40 ? 1 : 7)) for(int fill = 0; fill < 2; fill++) for(int even = 0; even < 2; even++)
  {
    // Some circles partly before the screen start
    int cx = (r % 3 == 0) ? 5 : 40, cy = (r % 2 == 0) ? -3 : 30;
    c.SetParams(cx, cy, r, C1, fill, even);
    snprintf(what, sizeof(what), "Circle r %d fill %d even %d", r, fill, even);
    HvCheck(c, what, cx - r, cy - r, cx + r, cy + r, st);
  }
  return HvReport("Circle", st, false);
}

// *****************************************************************************
// ***   HvTriangle   **********************************************************
// *****************************************************************************
static int HvTriangle()
{
  HV st;
  Triangle t;
  char what[120];
  const int special[][6] = {{10, 10, 40, 10, 25, 30}, {10, 30, 40, 30, 25, 10}, {10, 10, 10, 40, 40, 25}, {10, 10, 50, 12, 30, 14},
                            {10, 10, 30, 30, 50, 50}, {20, 20, 20, 20, 40, 40}, {25, 25, 25, 25, 25, 25}, {10, 10, 60, 10, 35, 11},
                            {10, 5, 60, 5, 35, 40}, {-20, 10, 30, 5, 10, 45}, {40, -15, 80, 20, 50, 30}, {30, 20, 90, 25, 60, 70},
                            {10, 10, 11, 60, 12, 20}, {5, 5, 5, 50, 6, 27}};
  const int NS = sizeof(special) / sizeof(special[0]);
  srand(4242);
  for(int k = 0; k < NS + 300; k++) for(int f = 0; f < 2; f++)
  {
    int v[6];
    for(int i = 0; i < 6; i++) v[i] = (k < NS) ? special[k][i] : Rnd(-10, 70);
    t.SetParams(v[0], v[1], v[2], v[3], v[4], v[5], C1, f);
    snprintf(what, sizeof(what), "Triangle (%d,%d)-(%d,%d)-(%d,%d) %s", v[0], v[1], v[2], v[3], v[4], v[5], f ? "filled" : "outline");
    HvCheck(t, what, std::min({v[0], v[2], v[4]}), std::min({v[1], v[3], v[5]}), std::max({v[0], v[2], v[4]}), std::max({v[1], v[3], v[5]}), st);
  }
  return HvReport("Triangle", st, false);
}

// *****************************************************************************
// ***   Text helpers   ********************************************************
// *****************************************************************************
static Font* hv_fonts[] = {&Font_4x6::GetInstance(), &Font_8x12::GetInstance(), &Font_10x18::GetInstance()};

// Dot of a character glyph
static bool GlyphDot(Font* f, uint8_t ch, int col, int row)
{
  int bpr = f->GetBytesPerChar() / f->GetCharH();
  return (f->GetCharGataPtr(ch)[row * bpr + col / 8] >> (col % 8)) & 1;
}

// *****************************************************************************
// ***   HvString   ************************************************************
// *****************************************************************************
static int HvString()
{
  HV st;
  String s;
  char what[160];
  const char* texts[] = {"Ab", "Hello, world", "\xC0\xE1\xB0", "i"};
  for(Font* f : hv_fonts) for(const char* t : texts) for(int scale = 1; scale <= 3; scale++) for(int bg = 0; bg < 2; bg++)
  {
    if(bg) s.SetParams(t, 6, 4, C1, C2, *f);
    else   s.SetParams(t, 6, 4, C1, *f);
    s.SetScale(1); s.SetScale(scale);
    int fw = f->GetCharW(), fh = f->GetCharH(), W = (int)strlen(t) * fw * scale, H = fh * scale;
    snprintf(what, sizeof(what), "String font %dx%d scale %d bg %d \"%s\"", fw, fh, scale, bg, t);
    HvCheck(s, what, 6, 4, 6 + W - 1, 4 + H - 1, st, [&](int x, int y) -> color_t {
      if((x < 6) || (x >= 6 + W) || (y < 4) || (y >= 4 + H)) return Pat(x, y);
      int ci = (x - 6) / (fw * scale), col = ((x - 6) / scale) % fw, row = (y - 4) / scale;
      return GlyphDot(f, (uint8_t)t[ci], col, row) ? C1 : (bg ? C2 : Pat(x, y));});
  }
  return HvReport("String", st, true);
}

// *****************************************************************************
// ***   HvStringAligned   *****************************************************
// *****************************************************************************
static int HvStringAligned()
{
  HV st;
  StringAligned s;
  char what[200];
  const char* texts[] = {"Ab", "Hello, world", "W", ""};
  const StringAligned::alignment_t al[] = {StringAligned::LEFT, StringAligned::CENTER, StringAligned::RIGHT};
  for(Font* f : hv_fonts) for(const char* t : texts) for(int scale = 1; scale <= 2; scale++) for(int bg = 0; bg < 2; bg++) for(auto a : al)
    for(int w : {1, 7, 20, 41, 130})
  {
    const int X = 6, Y = 4;
    if(bg) s.SetParams(t, a, X, Y, w, C1, C2, *f);
    else   s.SetParams(t, a, X, Y, w, C1, *f);
    s.SetScale(1); s.SetScale(scale);
    int fw = f->GetCharW(), fh = f->GetCharH(), len = (int)strlen(t) * fw * scale, H = fh * scale;
    snprintf(what, sizeof(what), "StringAligned font %dx%d scale %d bg %d align %d width %d \"%s\"", fw, fh, scale, bg, (int)a, w, t);
    // Background over the whole object; text placed by alignment, cut by the object
    int tx = X + ((a == StringAligned::CENTER) ? (w - len) / 2 : (a == StringAligned::RIGHT) ? w - len : 0);
    HvCheck(s, what, X, Y, X + w - 1, Y + H - 1, st, [&](int x, int y) -> color_t {
      if((x < X) || (x >= X + w) || (y < Y) || (y >= Y + H)) return Pat(x, y);
      if((x >= tx) && (x < tx + len))
      {
        int ci = (x - tx) / (fw * scale), col = ((x - tx) / scale) % fw, row = (y - Y) / scale;
        if(GlyphDot(f, (uint8_t)t[ci], col, row)) return C1;
      }
      return bg ? C2 : Pat(x, y);});
  }
  return HvReport("StringAligned", st, true);
}

// *****************************************************************************
// ***   HvMultiLineString   ***************************************************
// *****************************************************************************
static int HvMultiLineString()
{
  HV st;
  static MultiLineString m("", 0, 0, C1, Font_4x6::GetInstance());
  char what[200];
  const char* texts[] = {"One\nLonger line\nab", "a\n\nb", "single", "ab\n", "", "\nx", "WW\nW\nWWW\nW"};
  const MultiLineString::alignment_t al[] = {MultiLineString::LEFT, MultiLineString::CENTER, MultiLineString::RIGHT};
  for(Font* f : hv_fonts) for(const char* t : texts) for(int scale = 1; scale <= 2; scale++) for(int sp : {0, 1, 4}) for(auto a : al) for(int bg = 0; bg < 2; bg++)
  {
    const int X = 7, Y = 3;
    if(bg) m.SetParams(t, X, Y, C1, C2, *f);
    else   m.SetParams(t, X, Y, C1, *f);
    // Reset first: setters ignore unchanged values
    m.SetScale(1); m.SetSpacing(0); m.SetScale(scale); m.SetSpacing(sp); m.SetAlignment(a); m.SetString(t, true);
    std::vector<std::string> ln(1);
    for(const char* p = t; *p; p++) {if(*p == '\n') ln.push_back(""); else ln.back() += *p;}
    int fw = f->GetCharW(), fh = f->GetCharH(), lh = fh * scale + sp;
    size_t longest = 0u;
    for(auto& s : ln) longest = std::max(longest, s.size());
    int W = (int)longest * fw * scale, H = lh * (int)ln.size() - sp;
    snprintf(what, sizeof(what), "MultiLineString font %dx%d scale %d spacing %d align %d bg %d \"%s\"", fw, fh, scale, sp, (int)a, bg, t);
    // Background fills the bounding box, spacing rows included
    HvCheck(m, what, X, Y, X + std::max(W, 1) - 1, Y + H - 1, st, [&](int x, int y) -> color_t {
      if((x < X) || (x >= X + W) || (y < Y) || (y >= Y + H)) return Pat(x, y);
      int tl = (y - Y) / lh, fl = (y - Y - tl * lh) / scale, len = (int)ln[tl].size() * fw * scale;
      int x0 = X + ((a == MultiLineString::CENTER) ? (W - len) / 2 : (a == MultiLineString::RIGHT) ? W - len : 0);
      if((fl < fh) && (x >= x0) && (x < x0 + len))
      {
        int ci = (x - x0) / (fw * scale), col = ((x - x0) / scale) % fw;
        if(GlyphDot(f, (uint8_t)ln[tl][ci], col, fl)) return C1;
      }
      return bg ? C2 : Pat(x, y);});
  }
  return HvReport("MultiLineString", st, true);
}

// *****************************************************************************
// ***   HvImages   ************************************************************
// *****************************************************************************
static int HvImages()
{
  int r = 0;
  static color_t pix[17 * 6];
  static uint8_t idx[17 * 6];
  static color_t pal[256];
  static uint8_t bits[3 * 6];
  for(int i = 0; i < 17 * 6; i++) {pix[i] = (color_t)(0x00010203u * (i + 1) + 0x00400000u); idx[i] = (uint8_t)(i * 7 + 1);}
  for(int i = 0; i < 256; i++) pal[i] = (color_t)(0x00030201u * (i + 1));
  for(int i = 0; i < 3 * 6; i++) bits[i] = (uint8_t)((0xA5u >> (i % 3)) | (i * 37));
  char what[120];
  // Image: bitmap or palette, with transparency, mirrored
  {
    HV st;
    static Image im(0, 0, ImageDesc());
    for(int w : {1, 2, 5, 17}) for(int usepal = 0; usepal < 2; usepal++) for(int tr = 0; tr < 2; tr++) for(int mir = 0; mir < 2; mir++)
    {
      ImageDesc d;
      d.width = w; d.height = 6; d.bits_per_pixel = usepal ? 8 : sizeof(color_t) * 8;
      if(usepal) {d.imgp = idx; d.palette = pal;}
      else       d.imgb = pix;
      auto src = [&](int c, int rr) -> color_t {return usepal ? pal[idx[rr * w + c]] : pix[rr * w + c];};
      d.transparent_color = tr ? (int32_t)src((w > 1) ? 1 : 0, 2) : -1;
      im.SetImage(d); im.Move(10, 5); im.SetHorizontalFlip(mir);
      snprintf(what, sizeof(what), "Image width %d palette %d transparent %d mirror %d", w, usepal, tr, mir);
      // Pixel (x, y) shows image column x - 10, or w - 1 - (x - 10) when mirrored
      HvCheck(im, what, 10, 5, 10 + w - 1, 10, st, [&](int x, int y) -> color_t {
        if((x < 10) || (x >= 10 + w) || (y < 5) || (y >= 11)) return Pat(x, y);
        int c = mir ? w - 1 - (x - 10) : x - 10;
        color_t v = src(c, y - 5);
        return ((int32_t)v == d.transparent_color) ? Pat(x, y) : v;});
    }
    r |= HvReport("Image", st, true);
  }
  // ImagePalette
  {
    HV st;
    ImagePalette im;
    for(int w : {1, 2, 9, 17})
    {
      im.SetImage(idx, w, 6, pal); im.Move(10, 5);
      snprintf(what, sizeof(what), "ImagePalette width %d", w);
      HvCheck(im, what, 10, 5, 10 + w - 1, 10, st);
    }
    r |= HvReport("ImagePalette", st, false);
  }
  // ImageBitmap
  {
    HV st;
    ImageBitmap im;
    for(int w : {1, 2, 9, 17})
    {
      im.SetImage(pix, w, 6); im.Move(10, 5);
      snprintf(what, sizeof(what), "ImageBitmap width %d", w);
      HvCheck(im, what, 10, 5, 10 + w - 1, 10, st);
    }
    r |= HvReport("ImageBitmap", st, false);
  }
  // ImageBinary: transparent color that is neither, the color, the background
  {
    HV st;
    ImageBinary im;
    for(int w : {1, 3, 8, 11, 17}) for(int tr = 0; tr < 3; tr++)
    {
      color_t tc = (tr == 0) ? C3 : (tr == 1) ? C1 : C2;
      im.SetImage(bits, w, 6); im.Move(10, 5); im.SetColor(C1); im.SetBackgroundColor(C2); im.SetTransparentColor(tc);
      snprintf(what, sizeof(what), "ImageBinary width %d transparent %d", w, tr);
      int bpr = (w + 7) / 8;
      HvCheck(im, what, 10, 5, 10 + w - 1, 10, st, [&](int x, int y) -> color_t {
        if((x < 10) || (x >= 10 + w) || (y < 5) || (y >= 11)) return Pat(x, y);
        int c = x - 10;
        color_t v = ((bits[(y - 5) * bpr + c / 8] >> (c % 8)) & 1) ? C1 : C2;
        return (v == tc) ? Pat(x, y) : v;});
    }
    r |= HvReport("ImageBinary", st, true);
  }
  return r;
}

// *****************************************************************************
// ***   HvTiledMap   **********************************************************
// *****************************************************************************
static int HvTiledMap()
{
  HV st;
  char what[120];
  // Two 4x3 tiles; tile 1 has a transparent color
  static uint8_t t0[12], t1[12];
  static color_t tp[16];
  for(int i = 0; i < 12; i++) {t0[i] = (uint8_t)(i % 16); t1[i] = (uint8_t)((i * 5) % 16);}
  for(int i = 0; i < 16; i++) tp[i] = (color_t)(0x00102030u * (i + 1));
  static ImageDesc tiles[2];
  tiles[0].width = 4; tiles[0].height = 3; tiles[0].bits_per_pixel = 8; tiles[0].imgp = t0; tiles[0].palette = tp; tiles[0].transparent_color = -1;
  tiles[1] = tiles[0]; tiles[1].imgp = t1; tiles[1].transparent_color = (int32_t)tp[5];
  // 5 x 4 map: tiles 0 and 1, empty ones (2, 7); bit 7 is masked out
  static uint8_t map[20] = {0, 1, 2, 0x80, 1,  1, 0, 0x81, 7, 0,  2, 2, 1, 0, 0x80,  0, 1, 0, 1, 2};
  for(int bgc = 0; bgc < 2; bgc++) for(int w : {3, 9, 20, 27}) for(int h : {2, 7, 12, 16}) for(int px : {0, 1, 5, 18}) for(int py : {0, 2, 9})
  {
    TiledMap tm(8, 6, w, h, map, 5, 4, 0x7F, tiles, 2, bgc ? (int32_t)C2 : -1);
    tm.ScrollView(px, py);
    snprintf(what, sizeof(what), "TiledMap %dx%d at map (%d,%d) background %d", w, h, px, py, bgc);
    // Screen pixel (8, 6) shows map pixel (px, py); outside the map only the background
    HvCheck(tm, what, 8, 6, 8 + w - 1, 6 + h - 1, st, [&](int x, int y) -> color_t {
      if((x < 8) || (x >= 8 + w) || (y < 6) || (y >= 6 + h)) return Pat(x, y);
      color_t v = bgc ? C2 : Pat(x, y);
      int mx = px + x - 8, my = py + y - 6;
      if((mx >= 20) || (my >= 12)) return v;
      int tv = map[(my / 3) * 5 + mx / 4] & 0x7F;
      if(tv >= 2) return v;
      color_t c = tp[tiles[tv].imgp[(my % 3) * 4 + mx % 4]];
      return ((int32_t)c == tiles[tv].transparent_color) ? v : c;});
  }
  return HvReport("TiledMap", st, true);
}

// *****************************************************************************
// ***   HvVisList   ***********************************************************
// *****************************************************************************
static int HvVisList()
{
  HV st;
  char what[80];
  srand(99);
  for(int sc = 0; sc < 150; sc++)
  {
    int lx = Rnd(-10, 60), ly = Rnd(-5, 20), lw = Rnd(1, 50), lh = Rnd(1, 30);
    bool nested = (sc % 3 == 0);
    int ox = nested ? Rnd(-8, 30) : 0, oy = nested ? Rnd(-4, 10) : 0, ow = Rnd(5, 70), oh = Rnd(5, 35);
    VisList outer, list;
    outer.SetParams(ox, oy, ow, oh);
    list.SetParams(lx, ly, lw, lh);
    Circle b1;
    Line l1;
    String s1;
    Box bx;
    Triangle tr;
    {int r = Rnd(1, 9); b1.SetParams(Rnd(-8, lw + 4), Rnd(-6, lh + 4), r, C1, true, false);}
    l1.SetParams(Rnd(-10, lw + 10), Rnd(-5, lh + 5), Rnd(-10, lw + 10), Rnd(-5, lh + 5), C3);
    s1.SetParams("Clip me", Rnd(-20, lw), Rnd(-6, lh), C1, C2, Font_6x8::GetInstance());
    bx.SetParams(Rnd(-8, lw), Rnd(-6, lh), Rnd(1, 20), Rnd(1, 15), C2, false);
    bx.SetBorderWidth(Rnd(1, 3));
    tr.SetParams(Rnd(-10, lw + 10), Rnd(-5, lh + 5), Rnd(-10, lw + 10), Rnd(-5, lh + 5), Rnd(-10, lw + 10), Rnd(-5, lh + 5), C3, true);
    VisObject* kids[] = {&b1, &l1, &s1, &bx, &tr};
    for(int i = 0; i < 5; i++) {kids[i]->SetList(list); kids[i]->Show(i + 1);}
    if(nested) {list.SetList(outer); list.Show(1);}
    VisObject& top = nested ? (VisObject&)outer : (VisObject&)list;
    snprintf(what, sizeof(what), "VisList scene %d%s", sc, nested ? " nested" : "");
    int ax0 = lx + ox, ay0 = ly + oy;
    HvCheck(top, what, std::min(ax0, ox), std::min(ay0, oy), std::max(ax0 + lw, ox + ow), std::max(ay0 + lh, oy + oh), st);
    for(auto k : kids) k->Hide();
    if(nested) list.Hide();
  }
  return HvReport("VisList", st, false);
}

// *****************************************************************************
// ***   HvUiEngine   **********************************************************
// *****************************************************************************
// Buttons 1..77 x 1..20, active or not, pressed or not; both checkbox states;
// scrolls vertical and horizontal, with and without buttons, total 1..100,
// bar sizes and positions
static int HvUiEngine()
{
  HV st;
  char what[120];
  for(int w : {1, 2, 3, 4, 5, 40, 77}) for(int h : {1, 2, 3, 4, 20}) for(int act = 0; act < 2; act++) for(int pr = 0; pr < 2; pr++)
  {
    UiButton b("OK", 30, 25, w, h, act);
    b.SetPressed(pr);
    snprintf(what, sizeof(what), "UiButton %dx%d active %d pressed %d", w, h, act, pr);
    // The text of a small button sticks out of it
    HvCheck(b, what, 0, 25 - 8, 30 + std::max(w, 30) + 30, 25 + std::max(h, 14) + 8, st);
  }
  for(int ch = 0; ch < 2; ch++)
  {
    UiCheckbox c(30, 25, ch, true);
    snprintf(what, sizeof(what), "UiCheckbox checked %d", ch);
    HvCheck(c, what, 30, 25, 42, 37, st);
  }
  for(int vert = 0; vert < 2; vert++) for(int btn = 0; btn < 2; btn++) for(int len : {20, 60, 150}) for(int thick : {5, 12})
    for(int tot : {0, 1, 2, 10, 100}) for(int bar : {0, 1, 3, 10})
  {
    int w = vert ? thick : len, h = vert ? len : thick;
    UiScroll sc(30, 25, w, h, tot, bar, vert, btn, true);
    for(int pos : {0, 1, tot / 2, tot - 1})
    {
      if(pos < 0) continue;
      sc.SetScrollPos(pos);
      snprintf(what, sizeof(what), "UiScroll %dx%d vertical %d buttons %d total %d bar %d pos %d", w, h, vert, btn, tot, bar, pos);
      HvCheck(sc, what, 30, 25, 30 + w - 1, 25 + h - 1, st);
    }
  }
  int r = HvReport("UiEngine", st, false);
  // A scroll changed by SetTotal() and SetBar() must draw as one made with
  // the same values by the constructor, and SetTotal() must keep the position
  // inside the new total
  long cases = 0, bad = 0;
  for(int vert = 0; vert < 2; vert++) for(int tot0 : {0, 5, 50}) for(int tot : {0, 1, 3, 40}) for(int bar : {0, 2, 30}) for(int pos : {0, 4, 49})
  {
    int w = vert ? 10 : 90, h = vert ? 90 : 10;
    UiScroll a(30, 25, w, h, tot0, 10, vert, true, true);
    // A valid position for the first total
    int pos0 = std::max(0, std::min(pos, tot0 - 1));
    a.SetScrollPos(pos0);
    a.SetTotal(tot);
    a.SetBar(bar);
    int exp_pos = std::max(0, std::min(pos0, tot - 1));
    UiScroll b(30, 25, w, h, tot, std::min(bar, tot), vert, true, true);
    b.SetScrollPos(exp_pos);
    cases++;
    bool same = (a.GetScrollPos() == exp_pos);
    for(int y = 20; y < 125 && same; y++)
    {
      std::vector<color_t> ra, rb;
      Draw(a, ra, 140, y, 0);
      Draw(b, rb, 140, y, 0);
      if(ra != rb) same = false;
    }
    if(!same) {bad++; if(bad <= 3) printf("   mismatch: UiScroll total %d -> %d, bar %d, pos %d, vertical %d\n", tot0, tot, bar, pos, vert);}
  }
  printf("UiScroll SetTotal/SetBar %ld cases vs the same scroll made by the constructor: %ld wrong\n", cases, bad);
  return r || (bad != 0);
}

// *****************************************************************************
// ***   main   ****************************************************************
// *****************************************************************************
int main(int argc, char** argv)
{
  // DisplayDrv first: it sets the default list for every visual object
  DisplayDrv::GetInstance();
  struct {const char* name; int (*fn)();} parts[] =
  {
    {"line", TestLine}, {"triangle", TestTriangle}, {"circle", TestCircle}, {"vislist", TestVisList},
    {"hv_box", HvBox}, {"hv_shadow", HvShadow}, {"hv_line", HvLine}, {"hv_circle", HvCircle}, {"hv_triangle", HvTriangle},
    {"hv_string", HvString}, {"hv_aligned", HvStringAligned}, {"hv_mls", HvMultiLineString}, {"hv_images", HvImages},
    {"hv_tiledmap", HvTiledMap}, {"hv_vislist", HvVisList}, {"hv_uiengine", HvUiEngine}
  };
  const char* only = (argc > 1) ? argv[1] : "";
  int r = 0, run = 0;
  for(auto& p : parts)
  {
    if(*only && strcmp(only, p.name)) continue;
    r |= p.fn();
    run++;
    fflush(stdout);
  }
  if(run == 0)
  {
    printf("Unknown part \"%s\". Parts:", only);
    for(auto& p : parts) printf(" %s", p.name);
    printf("\n");
    return 2;
  }
  printf(r ? "FAILED\n" : "ALL OK\n");
  return r;
}

#endif
