// *****************************************************************************
// @file VirtualDisplay.h
// @author Nicolai Shlapunov
//
// @details DevCore: Display in memory for the PC tests, header
//
// @section COPYRIGHT
//
//  Copyright (c) 2026, Devtronic & Nicolai Shlapunov
//  All rights reserved.
//
// @section LICENSE
//
//  SPDX-License-Identifier: BSD-3-Clause
//
//  Software License Agreement (BSD 3-Clause License)
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//  3. Neither the name of Devtronic nor the names of its contributors may be
//     used to endorse or promote products derived from this software without
//     specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
//  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
//  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
//  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
//  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
//  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
//  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
//  POSSIBILITY OF SUCH DAMAGE.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************
#ifndef VirtualDisplay_h
#define VirtualDisplay_h

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "DevCfg.h"
#include "Interfaces/IDisplay.h"

#include <vector>
#include <mutex>
#include <atomic>
#include <string>

// *****************************************************************************
// ***   VirtualDisplay   ******************************************************
// *****************************************************************************
// An IDisplay that keeps the picture of the panel in memory and saves it as a
// PNG file, so DisplayDrv can run on a PC.
// Rotations follow ILI9341::SetRotation(): relative to ROTATION_TOP, its MADCTL
// table turns the picture in 90 degree steps, and this display does the same.
// A pixel drawn at (x, y) in rotation R lands where the panel shows it, and
// Save(file, view) writes the panel as seen in rotation "view". So a frame
// drawn in Left to Right update mode (display turned one step back) and the
// same frame drawn in Top to Bottom mode give the same picture for the same
// view. This is a model of the ILI9341 table, not of a particular chip.
class VirtualDisplay : public IDisplay
{
  public:
    // *************************************************************************
    // ***   Constructor   *****************************************************
    // *************************************************************************
    // * Panel size in ROTATION_TOP
    VirtualDisplay(int32_t w, int32_t h);

    // *************************************************************************
    // ***   IDisplay   ********************************************************
    // *************************************************************************
    virtual Result Init(void) {return Result::RESULT_OK;}
    virtual Result WriteDataStream(uint8_t* data, uint32_t n);
    virtual bool IsTransferComplete(void) {return true;}
    virtual Result StopTransfer(void);
    virtual Result SetAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);
    virtual Result SetRotation(Rotation r);
    virtual Result PushColor(color_t color);
    virtual Result DrawPixel(int16_t x, int16_t y, color_t color);
    virtual Result FillRect(int16_t x, int16_t y, int16_t w, int16_t h, color_t color);
    virtual Result InvertDisplay(bool invert) {inverted = invert; return Result::RESULT_OK;}

    // *************************************************************************
    // ***   GetPixel   ********************************************************
    // *************************************************************************
    // * Pixel of the panel as seen in rotation "view"
    color_t GetPixel(int32_t x, int32_t y, Rotation view = ROTATION_TOP);

    // *************************************************************************
    // ***   GetPicture   ******************************************************
    // *************************************************************************
    // * Panel as seen in rotation "view": width, height and pixels line by line
    void GetPicture(std::vector<color_t>& pic, int32_t& w, int32_t& h, Rotation view = ROTATION_TOP);

    // *************************************************************************
    // ***   Save   ************************************************************
    // *************************************************************************
    // * Saves the panel as seen in rotation "view" as a PNG file
    bool Save(const std::string& file, Rotation view = ROTATION_TOP);

    // *************************************************************************
    // ***   Clear   ***********************************************************
    // *************************************************************************
    // * Fills the whole panel, to see what a frame leaves untouched
    void Clear(color_t c);

    // *************************************************************************
    // ***   WaitIdle   ********************************************************
    // *************************************************************************
    // * Waits until nothing was written for quiet_ms, at most timeout_ms
    void WaitIdle(uint32_t quiet_ms = 80u, uint32_t timeout_ms = 3000u);

    // *************************************************************************
    // ***   Counters   ********************************************************
    // *************************************************************************
    uint32_t GetPixelsWritten(void) {return pixels_written;}
    uint32_t GetTransfers(void) {return transfers;}
    // * Address windows outside the panel: a driver error
    uint32_t GetErrors(void) {return errors;}

    // *************************************************************************
    // ***   ToRgb   ***********************************************************
    // *************************************************************************
    // * Color as R, G, B (DevCore color format of this build)
    static void ToRgb(color_t c, uint8_t& r, uint8_t& g, uint8_t& b);

  private:
    // Panel in ROTATION_TOP coordinates
    std::vector<color_t> panel;
    // Address window and write position, in the current rotation
    int32_t wx0 = 0, wy0 = 0, wx1 = 0, wy1 = 0, cx = 0, cy = 0;
    // Inverted colors
    bool inverted = false;
    // Mutex for the panel
    std::recursive_mutex mutex;
    // Counters and time of the last write
    std::atomic<uint32_t> pixels_written{0u}, transfers{0u}, errors{0u}, last_write_ms{0u};

    // *************************************************************************
    // ***   PanelIdx   ********************************************************
    // *************************************************************************
    // * Logical (x, y) of rotation r to panel index; -1 if outside
    int32_t PanelIdx(int32_t x, int32_t y, Rotation r);

    // *************************************************************************
    // ***   Size   ************************************************************
    // *************************************************************************
    // * Logical size of rotation r
    void Size(Rotation r, int32_t& w, int32_t& h);

    // *************************************************************************
    // ***   Put   *************************************************************
    // *************************************************************************
    // * Writes one pixel at the write position and advances it
    void Put(color_t c);
};

#endif
