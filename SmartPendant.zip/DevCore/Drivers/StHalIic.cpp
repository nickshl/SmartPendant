// *****************************************************************************
// @file StHalIic.cpp
// @author Nicolai Shlapunov
//
// @details DevCore: STM32 HAL I2C driver, implementation
//
// @copyright Copyright (c) 2018, Devtronic & Nicolai Shlapunov
//            All rights reserved.
//
// @section SUPPORT
//
//  Devtronic invests time and resources providing this open source code,
//  please support Devtronic and open-source hardware/software by
//  donations and/or purchasing products from Devtronic.
//
// *****************************************************************************

// *****************************************************************************
// ***   Includes   ************************************************************
// *****************************************************************************
#include "StHalIic.h"

// *****************************************************************************
// ***   This driver can be compiled only if I2C configured in CubeMX   ********
// *****************************************************************************
#ifdef HAL_I2C_MODULE_ENABLED

// *****************************************************************************
// ***   Public: Enable   ******************************************************
// *****************************************************************************
Result StHalIic::Enable()
{
  // Set PE bit
  __HAL_I2C_ENABLE(&hi2c);
  // No errors to return
  return Result::RESULT_OK;
}

// *****************************************************************************
// ***   Public: Disable   *****************************************************
// *****************************************************************************
Result StHalIic::Disable()
{
  // Clear PE bit
  __HAL_I2C_DISABLE(&hi2c);
  // No errors to return
  return Result::RESULT_OK;
}

// *****************************************************************************
// ***   Public: Reset   *******************************************************
// *****************************************************************************
Result StHalIic::Reset()
{
  // Clear PE bit
  CLEAR_BIT(hi2c.Instance->CR1, I2C_CR1_PE);
  // PE must be kept low during at least 3 APB clock cycles in order to
  // perform the software reset. Wait until it actually cleared.
  while(READ_BIT(hi2c.Instance->CR1, I2C_CR1_PE));
  // Set Software reset bit
  SET_BIT(hi2c.Instance->CR1, I2C_CR1_SWRST);
  // Clear Software reset bit
  CLEAR_BIT(hi2c.Instance->CR1, I2C_CR1_SWRST);

  // TODO: we need to make some clock pulses on the SCL line here. Sometimes
  // In some cases when slave missed clock pulse by some reason it may stuck in
  // acknowledge state and pull SDA line low. MCU will see that and consider
  // line busy. It can be fixed by producing another pulse on SCL line which
  // should force slave to release SDA line.
  // However, it not easy(universal) to do since hi2c does not contains GPIO
  // info for I2C pins.

  // Reinit H2C(PE bit will be set by this function)
  HAL_I2C_Init(&hi2c);
  // No errors to return
  return Result::RESULT_OK;
}

// *************************************************************************
// ***   Public: IsDeviceReady   *******************************************
// *************************************************************************
Result StHalIic::IsDeviceReady(uint16_t addr, uint8_t retries)
{
  Result result;
  // Shift address one bit left - HAL blow away LSB, not MSB.
  addr <<= 1u;
  // Check device status
  HAL_StatusTypeDef hal_result = HAL_I2C_IsDeviceReady(&hi2c, addr, retries, i2c_tx_timeout_ms);
  // Convert operation result to Result
  result = ConvertResult(hal_result);
  // Return result
  return result;
}

// *****************************************************************************
// ***   Public: Transfer   ****************************************************
// *****************************************************************************
Result StHalIic::Transfer(uint16_t addr, uint8_t* tx_buf_ptr, uint32_t tx_size, uint8_t* rx_buf_ptr, uint32_t rx_size)
{
  Result result = Result::ERR_NULL_PTR;

  // Special hack for use HAL_I2C_Mem_Read() function for send Repeated Start if
  // tx_size is 1 or 2 bytes.
  if((tx_buf_ptr != nullptr) && (rx_buf_ptr != nullptr) && ((tx_size == 1u) || (tx_size == 2u)))
  {
    // Variable for store result from the HAL
    HAL_StatusTypeDef hal_result = HAL_OK;

    // Build memory address
    uint16_t mem_addr = (uint16_t)tx_buf_ptr[0u] | ((tx_size == 2u) ? ((uint16_t)tx_buf_ptr[1u] << 8u) : 0);

    // Shift address one bit left - HAL blow away LSB, not MSB.
    addr <<= 1u;

    // Transmit data
    hal_result = HAL_I2C_Mem_Read(&hi2c, addr, mem_addr, (tx_size == 1u) ? I2C_MEMADD_SIZE_8BIT : I2C_MEMADD_SIZE_16BIT, rx_buf_ptr, rx_size, i2c_tx_timeout_ms);

    // Convert operation result to Result
    result = ConvertResult(hal_result);
  }
  else
  {
    if(tx_buf_ptr != nullptr)
    {
      // Transmit data
      result = Write(addr, tx_buf_ptr, tx_size);
    }

    if((rx_buf_ptr != nullptr) && result.IsGood())
    {
      // Clear RX buffer
      for(uint32_t i = 0u; i < rx_size; i++)
      {
        rx_buf_ptr[i] = 0u;
      }
      // Receive data
      result = Read(addr, rx_buf_ptr, rx_size);
    }
  }

  return result;
}

// *****************************************************************************
// ***   Public: Write   *******************************************************
// *****************************************************************************
Result StHalIic::Write(uint16_t addr, uint8_t* tx_buf_ptr, uint32_t tx_size)
{
  Result result = Result::ERR_NULL_PTR;

  if(tx_buf_ptr != nullptr)
  {
    // Variable for store result from the HAL
    HAL_StatusTypeDef hal_result = HAL_OK;

    // Shift address one bit left - HAL blow away LSB, not MSB.
    addr <<= 1u;

    // Transmit data
    hal_result = HAL_I2C_Master_Transmit(&hi2c, addr, tx_buf_ptr, tx_size, i2c_tx_timeout_ms);

    // Convert operation result to Result
    result = ConvertResult(hal_result);
  }

  return result;
}

// *****************************************************************************
// ***   Public: Read   ********************************************************
// *****************************************************************************
Result StHalIic::Read(uint16_t addr, uint8_t* rx_buf_ptr, uint32_t rx_size)
{
  Result result = Result::ERR_NULL_PTR;

  if(rx_buf_ptr != nullptr)
  {
    // Variable for store result from the HAL
    HAL_StatusTypeDef hal_result = HAL_OK;

    // Shift address one bit left - HAL blow away LSB, not MSB.
    addr <<= 1u;

    // Transmit data
    hal_result = HAL_I2C_Master_Receive(&hi2c, addr, rx_buf_ptr, rx_size, i2c_tx_timeout_ms);

    // Convert operation result to Result
    result = ConvertResult(hal_result);
  }

  return result;
}

// *****************************************************************************
// ***   Public: WriteAsync   **************************************************
// *****************************************************************************
Result StHalIic::WriteAsync(uint16_t addr, uint8_t* tx_buf_ptr, uint32_t tx_size)
{
  Result result = Result::ERR_NOT_IMPLEMENTED;

  // Check DMA handler - if it is nullptr this function not implemented in hardware
  if(hi2c.hdmatx != nullptr)
  {
    // Shift address one bit left - HAL blow away LSB, not MSB.
    addr <<= 1u;
    // Receive data using DMA
    HAL_StatusTypeDef hal_result = HAL_I2C_Master_Transmit_DMA(&hi2c, addr, tx_buf_ptr, tx_size);
    // Convert operation result to Result
    result = ConvertResult(hal_result);
  }

  return result;
}

// *****************************************************************************
// ***   Public: ReadAsync   ***************************************************
// *****************************************************************************
Result StHalIic::ReadAsync(uint16_t addr, uint8_t* rx_buf_ptr, uint32_t rx_size)
{
  Result result = Result::ERR_NOT_IMPLEMENTED;

  // Check DMA handler - if it is nullptr this function not implemented in hardware
  if(hi2c.hdmarx != nullptr)
  {
    // Shift address one bit left - HAL blow away LSB, not MSB.
    addr <<= 1u;
    // Receive data using DMA
    HAL_StatusTypeDef hal_result = HAL_I2C_Master_Receive_DMA(&hi2c, addr, rx_buf_ptr, rx_size);
    // Convert operation result to Result
    result = ConvertResult(hal_result);
  }

  return result;
}

// *****************************************************************************
// ***   Public: Transfer   ****************************************************
// *****************************************************************************
bool StHalIic::IsBusy(void)
{
   return (hi2c.State != HAL_I2C_STATE_READY);
}

// *****************************************************************************
// ***   Private: ConvertResult   **********************************************
// *****************************************************************************
Result StHalIic::ConvertResult(HAL_StatusTypeDef hal_result)
{
  Result result = Result::RESULT_OK;

  // Convert operation result to Result
  switch(hal_result)
  {
    case HAL_OK:
      result = Result::RESULT_OK;
      break;

    case HAL_ERROR:
      result = Result::ERR_I2C_GENERAL;
      break;

    case HAL_BUSY:
      result = Result::ERR_I2C_BUSY;
      break;

    case HAL_TIMEOUT:
      result = Result::ERR_I2C_TIMEOUT;
      break;

    default:
      result = Result::ERR_I2C_UNKNOWN;
      break;
  }

  // Return result
  return result;
}

#endif
